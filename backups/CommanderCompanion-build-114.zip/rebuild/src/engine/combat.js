import { withOverlay } from './overlay.js';
import { evaluateLosses } from './rules.js';
import { clearCastState, applyEffects } from './effects.js';
import { regenerates } from './effects-catalog.js';
import { damageAmount, lifeGainAmount, graveyardDestination } from './replacements.js';
import { shieldFitsB111 } from './effects-b111.js';
const numStat = v => { const m = String(v ?? '').match(/-?\d+/); return m ? Number(m[0]) : 0; };
function tempEffects(card, kind) { return (card?.temporaryEffects || []).filter(e => e?.kind === kind && e?.enabled !== false); }
function temporaryPt(card, key) { return tempEffects(card, 'pt').reduce((n, e) => n + Number(e?.[key] || 0), 0); }
function controllerOf(game, card) { return game?.players?.find(p => p.playerId === card?.controllerId) || game?.players?.find(p => (p.deck?.battlefield || []).some(c => c.instanceId === card?.instanceId)) || null; }
function definition(game, card) { if (!card) return undefined; const base = game?.cardDefinitions?.[card.definitionId]; const i = Number.isInteger(card.activeFaceIndex) ? card.activeFaceIndex : null; const face = i === null ? null : base?.cardFaces?.[i]; return withOverlay(card, face ? { ...base, ...face } : base); }
function typeHas(def, word) { return new RegExp(`\\b${String(word).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(def?.typeLine || ''); }
function subtypeMatch(def, phrase) {
  const s = String(phrase || '').trim();
  if (!s)
    return true;
  if (/artifact creatures?/i.test(s))
    return typeHas(def, 'Artifact') && typeHas(def, 'Creature');
  if (/token creatures?/i.test(s))
    return typeHas(def, 'Creature');
  if (/^creatures?$/i.test(s))
    return typeHas(def, 'Creature');
  const clean = s.replace(/^(?:other\s+)?/i, '').replace(/\s+creatures?$/i, '').trim();
  if (clean && /^[A-Z]/.test(clean) && typeHas(def, 'Creature') && (/\bChangeling\b/.test(String(def?.oracleText || '')) || (def?.keywords || []).some(k => /^changeling$/i.test(k)))) return true;   // Changeling
  return typeHas(def, 'Creature') && (!clean || new RegExp(`\\b${clean.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(def?.typeLine || ''));
}
/** Permanents a player controls, and their emblems ({ text }), with the rules text of each. */
function staticSources(game, controllerId) {
  const out = [];
  for (const p of game.players || []) {
    for (const source of p.deck?.battlefield || []) if (source.controllerId === controllerId) out.push({ source, text: String(definition(game, source)?.oracleText || '') });
    if (p.playerId === controllerId) for (const e of p.emblems || []) out.push({ source: { instanceId: e.id }, text: String(e.text || '') });
  }
  return out;
}
function continuousPtBonus(game, card) {
  if (!game || !card)
    return { power: 0, toughness: 0 };
  const targetController = card.controllerId;
  let power = 0, toughness = 0;
  for (const { source, text } of staticSources(game, targetController))
    {
      for (const line of text.split('\n')) {
        let m = line.match(/^(Other\s+)?(.*?creatures?) you control get ([+-]\d+)\/([+-]\d+)(?: and (?:have|gain) [A-Za-z ,-]+)?(?:\.|$)/i);
        if (!m)
          continue;
        if (m[1] && source.instanceId === card.instanceId)
          continue;
        if (!subtypeMatch(definition(game, card), m[2]))
          continue;
        power += Number(m[3]);
        toughness += Number(m[4]);
      }
    }
  return { power, toughness };
}
function selfScalingPt(game, card, def) {
  const text = String(def?.oracleText || '');
  let power = 0, toughness = 0, m;
  // Common Commander patterns: "gets +1/+1 for each ... you control".
  for (const row of text.matchAll(/gets ([+-]\d+)\/([+-]\d+) for each (creature|artifact|enchantment|land|permanent) you control/ig)) {
    const p = controllerOf(game, card);
    if (!p)
      continue;
    const n = (p.deck?.battlefield || []).filter(c => { const d = definition(game, c); return row[3].toLowerCase() === 'permanent' || typeHas(d, row[3]); }).length;
    power += Number(row[1]) * n;
    toughness += Number(row[2]) * n;
  }
  // "This creature's power and toughness are each equal to the number of lands you control." (Druid Class's land, build 79)
  if ((m = text.match(/(?:This creature's|its) power and toughness are each equal to the number of (lands|creatures|artifacts|enchantments|permanents) you control/i))) {
    const p = controllerOf(game, card), w = m[1].toLowerCase().replace(/s$/, '');
    const n = (p?.deck?.battlefield || []).filter(c => w === 'permanent' || typeHas(definition(game, c), w)).length;
    power += n; toughness += n;
  }
  // Domain: "~'s power and toughness are each equal to the number of basic land types among lands you control" (Territorial Kavu; twice that: Territorial Maro; only power: Fblthp; only toughness: Aven Trailblazer)
  if ((m = text.match(/(?:^|\n)(?:Domain — )?[^.\n]*?\b(power and toughness are each|power is|toughness is) equal to (twice )?the number of basic land types among lands you control/i))) {
    const p = controllerOf(game, card), kinds = new Set();
    for (const c of p?.deck?.battlefield || []) { const d = definition(game, c); if (/\bLand\b/.test(d?.typeLine || '')) for (const t of ['Plains', 'Island', 'Swamp', 'Mountain', 'Forest']) if (new RegExp(`\\b${t}\\b`).test(d.typeLine)) kinds.add(t); }
    const n = kinds.size * (m[2] ? 2 : 1);
    if (!/toughness is/i.test(m[1])) power += n;
    if (!/power is/i.test(m[1])) toughness += n;
  }
  if ((m = text.match(/gets ([+-]\d+)\/([+-]\d+) for each card in your graveyard/i))) {
    const p = controllerOf(game, card);
    const n = p?.deck?.graveyard?.length || 0;
    power += Number(m[1]) * n;
    toughness += Number(m[2]) * n;
  }
  return { power, toughness };
}
/** Threshold, Delirium, Metalcraft, Hellbent: "This creature gets +3/+3 (and has X) as long as …" / "… has deathtouch as long as …". */
function controllerCond(game, card, text) {
  const p = (game?.players || []).find(q => q.playerId === card?.controllerId);
  if (!p) return false;
  const counts = { one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10 };
  let m;
  if ((m = text.match(/^there are (\w+) or more cards in your graveyard$/i))) return (p.deck?.graveyard || []).length >= (counts[m[1].toLowerCase()] ?? Number(m[1]));
  if ((m = text.match(/^there are (\w+) or more card types among cards in your graveyard$/i))) return new Set((p.deck?.graveyard || []).flatMap(c => (String(definition(game, c)?.typeLine || '').split('—')[0].match(/Artifact|Battle|Creature|Enchantment|Instant|Kindred|Land|Planeswalker|Sorcery/g) || []))).size >= (counts[m[1].toLowerCase()] ?? Number(m[1]));
  if ((m = text.match(/^you control (\w+) or more (artifacts|creatures|enchantments|lands)$/i))) return (p.deck?.battlefield || []).filter(c => new RegExp(`\\b${m[2].replace(/s$/, '')}\\b`, 'i').test(definition(game, c)?.typeLine || '')).length >= (counts[m[1].toLowerCase()] ?? Number(m[1]));
  if (/^you have no cards in hand$/i.test(text)) return !(p.deck?.hand || []).length;
  if (/^you have the city'?s blessing$/i.test(text)) return !!p.citysBlessing;   // Ascend
  return false;
}
function conditionalSelf(game, card, def) {
  const out = { power: 0, toughness: 0, keywords: [] };
  if (!game || !card) return out;
  const name = String(def?.name || '').split(',')[0].replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  for (const line of String(def?.oracleText || '').split('\n')) {
    const m = line.replace(/\([^()]*\)/g, '').trim().match(new RegExp(`^(?:[A-Z][a-z]+(?: [a-z]+)? — )?(?:This creature|~${name ? `|${name}` : ''}) (?:gets ([+-]\\d+)\\/([+-]\\d+)(?: and has ([a-z ,]+?))?|has ([a-z ,]+?)) as long as (.+?)\\.?$`, 'i'));
    if (!m || !controllerCond(game, card, m[5])) continue;
    out.power += Number(m[1] || 0); out.toughness += Number(m[2] || 0);
    out.keywords.push(...String(m[3] || m[4] || '').split(/,\s*(?:and\s+)?|\s+and\s+/).map(x => x.trim().toLowerCase()).filter(Boolean));
  }
  return out;
}
/** "Gain control of … for as long as ~ remains tapped / you control ~" (build 110): control goes back when the condition stops. */
let RESTORING = false;   // effectivePower below calls back into pruneWhileTapped
function restoreControlWhile(game) {
  if (!game?.controlWhile?.length || RESTORING) return;
  RESTORING = true;
  try { restoreControlWhileInner(game); } finally { RESTORING = false; }
}
function restoreControlWhileInner(game) {
  const bf = () => (game.players || []).flatMap(p => (p.deck?.battlefield || []).map(c => ({ c, p })));
  const keep = [];
  for (const r of game.controlWhile) {
    const all = bf(), src = all.find(x => x.c.instanceId === r.sourceId), tgt = all.find(x => x.c.instanceId === r.targetId);
    if (!tgt) continue;
    let holds = r.mode === 'enchanted' ? all.some(x => x.c.attachedTo === tgt.c.instanceId && /\bAura\b/.test(definition(game, x.c)?.typeLine || '')) : src && (r.mode === 'battlefield' ? true : r.mode === 'tapped' ? !!src.c.tapped : r.mode === 'control-tapped' ? !!src.c.tapped && (src.c.controllerId || src.p.playerId) === r.controllerId : (src.c.controllerId || src.p.playerId) === r.controllerId);
    // Old Man of the Sea: "... and that creature's power remains less than or equal to this creature's power"
    if (holds && r.powerLimit) holds = effectivePower(tgt.c, definition(game, tgt.c), game) <= effectivePower(src.c, definition(game, src.c), game);
    if (holds) { keep.push(r); continue; }
    const to = game.players.find(p => p.playerId === r.previousControllerId);
    if (to && tgt.p.playerId !== to.playerId) {
      tgt.p.deck.battlefield.splice(tgt.p.deck.battlefield.indexOf(tgt.c), 1);
      tgt.c.controllerId = to.playerId; to.deck.battlefield.push(tgt.c);
    }
  }
  game.controlWhile = keep;
}
/** "… for as long as ~ remains tapped" (build 110): effects registered in game.whileTapped end when their source untaps or leaves. */
export function pruneWhileTapped(game) {
  restoreControlWhile(game);
  const regs = game?.whileTapped;
  if (!regs?.length) return;
  const keep = [];
  for (const r of regs) {
    const src = (game.players || []).flatMap(p => p.deck?.battlefield || []).find(c => c.instanceId === r.sourceId);
    if (src?.tapped) { keep.push(r); continue; }
    for (const p of game.players || []) for (const c of p.deck?.battlefield || []) if ((c.temporaryEffects || []).some(e => e?.whileTappedOf === r.sourceId)) c.temporaryEffects = c.temporaryEffects.filter(e => e?.whileTappedOf !== r.sourceId);
  }
  game.whileTapped = keep;
}
function rawPower(card, def, game) {
  pruneWhileTapped(game);
  const anthem = continuousPtBonus(game, card), self = selfScalingPt(game, card, def);
  return numStat(def?.power) + Number(card?.counters?.['+1/+1'] || 0) - Number(card?.counters?.['-1/-1'] || 0) + temporaryPt(card, 'power') + anthem.power + self.power + conditionalSelf(game, card, def).power;
}
function rawToughness(card, def, game) {
  pruneWhileTapped(game);
  const anthem = continuousPtBonus(game, card), self = selfScalingPt(game, card, def);
  return numStat(def?.toughness) + Number(card?.counters?.['+1/+1'] || 0) - Number(card?.counters?.['-1/-1'] || 0) + temporaryPt(card, 'toughness') + anthem.toughness + self.toughness + conditionalSelf(game, card, def).toughness;
}
// "Switch target creature's power and toughness until end of turn": applied after every other change (an odd number of switches swaps).
const switched = card => (card?.temporaryEffects || []).filter(e => e?.kind === 'switch-pt').length % 2 === 1;
export function effectivePower(card, def, game = null) {
  return Math.max(0, switched(card) ? rawToughness(card, def, game) : rawPower(card, def, game));
}
export function effectiveToughness(card, def, game = null) {
  return switched(card) ? rawPower(card, def, game) : rawToughness(card, def, game);
}
/** "Your life total can't change" (Teferi's Protection until your next turn, Flare of Fortitude this turn). */
export function lifeFixed(game, p) { return !!p?.lifeLocked && (p.lifeLockedTurn == null || p.lifeLockedTurn === game?.turnNumber); }
const COLOUR_KEYWORDS = /^Each creature you control has [a-z ]+ if it'?s (?:white|blue|black|red|green)\b/i;
export function cardHasKeyword(card, def, name, game = null) {
  pruneWhileTapped(game);
  const n = String(name || ''), low = n.toLowerCase();
  // "loses hexproof and indestructible until end of turn" (Shadowspear) wins over every source of the keyword.
  if ((card?.temporaryEffects || []).some(e => e?.kind === 'keyword' && e.enabled === false && String(e.keyword || '').toLowerCase() === low))
    return false;
  if ((def?.keywords || []).some(x => String(x).toLowerCase() === low))
    return true;
  // Keyword text on the card (lines that only grant it "as long as …" are checked by conditionalSelf below).
  if (new RegExp(`\\b${n.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&')}\\b`, 'i').test(String(def?.oracleText || '').split('\n').filter(l => !/\bas long as\b/i.test(l) && !COLOUR_KEYWORDS.test(l)).join('\n')))
    return true;
  if (tempEffects(card, 'keyword').some(e => e.enabled !== false && String(e.keyword || '').toLowerCase() === low))
    return true;
  if (game && card && /as long as/i.test(String(def?.oracleText || '')) && conditionalSelf(game, card, def).keywords.includes(low))
    return true;
  if (game && card) {
    const targetController = card.controllerId;
    for (const { source, text } of staticSources(game, targetController))
      {
        for (const line of text.split('\n')) {
          // Scion of Draco: "Each creature you control has vigilance if it's white, hexproof if it's blue, …" (per colour of the creature)
          if (COLOUR_KEYWORDS.test(line)) {
            for (const part of line.replace(/^Each creature you control has /i, '').replace(/\.$/, '').split(/,\s*(?:and\s+)?|\s+and\s+(?=[a-z ]+ if it)/i)) {
              const g = part.trim().match(/^([a-z ]+?) if it'?s (white|blue|black|red|green)$/i);
              if (g && g[1].toLowerCase() === low && (def?.colors || []).includes({ white: 'W', blue: 'U', black: 'B', red: 'R', green: 'G' }[g[2].toLowerCase()])) return true;
            }
            continue;
          }
          const m = line.match(/^(Other\s+)?(.*?creatures?) you control (?:get [+-]\d+\/[+-]\d+ and )?(?:have|gain) ([A-Za-z][A-Za-z ,-]+)(?:\.|$)/i);
          if (!m)
            continue;
          if (m[1] && source.instanceId === card.instanceId)
            continue;
          if (!subtypeMatch(def, m[2]))
            continue;
          const kws = m[3].split(/,\s*(?:and\s+)?|\s+and\s+/).map(x => x.trim().toLowerCase());
          if (kws.includes(low))
            return true;
        }
      }
  }
  return false;
}
const kw = (card, def, k, game) => cardHasKeyword(card, def, k, game);
function locatePlayer(game, id) { return game.players.find(p => p.playerId === id); }
function findPermanent(game, id) { for (const player of game.players || []) { const card = (player.deck?.battlefield || []).find(c => c.instanceId === id); if (card) return { player, card }; } return null; }
function locateCard(player, id) { return player?.deck?.battlefield?.find(c => c.instanceId === id) || null; }
function commanderFor(player, card) { return player?.commanders?.find(c => c.cardId === card?.definitionId && c.zone === 'battlefield') || null; }
function toxicValue(def) { const ms = [...String(def?.oracleText || '').matchAll(/\bToxic\s+(\d+)\b/ig)]; return ms.reduce((n, m) => n + Number(m[1] || 0), 0); }
function isIndestructible(card, def, game) { return kw(card, def, 'Indestructible', game); }
function isDeathtouch(card, def, game) { return kw(card, def, 'Deathtouch', game); }
function isLifelink(card, def, game) { return kw(card, def, 'Lifelink', game); }
function isInfect(card, def, game) { return kw(card, def, 'Infect', game); }
function isWither(card, def, game) { return kw(card, def, 'Wither', game); }
function isTrample(card, def, game) { return kw(card, def, 'Trample', game); }
function hasFirst(card, def, game) { return kw(card, def, 'First strike', game); }
function hasDouble(card, def, game) { return kw(card, def, 'Double strike', game); }
function dealsInStep(card, def, step, game) { return step === 'first' ? (hasFirst(card, def, game) || hasDouble(card, def, game)) : (!hasFirst(card, def, game) || hasDouble(card, def, game)); }
function lethalFor(blocker, bdef, source, sourceDef, game) { return isDeathtouch(source, sourceDef, game) ? 1 : Math.max(0, effectiveToughness(blocker, bdef, game) - Number(blocker?.damageMarked || 0)); }
function queueCreatureDamage(queue, sourcePlayer, source, sourceDef, targetPlayer, target, targetDef, amount) { if (amount > 0)
  queue.push({ kind: 'creature', sourcePlayer, source, sourceDef, targetPlayer, target, targetDef, amount }); }
function queuePlayerDamage(queue, sourcePlayer, source, sourceDef, targetPlayer, amount) { if (amount > 0)
  queue.push({ kind: 'player', sourcePlayer, source, sourceDef, targetPlayer, amount }); }
function smartAttackerAssignment({ power, blockers, game, source, sourceDef, trample }) {
  const out = [];
  let remaining = power;
  if (trample) {
    for (const b of blockers) {
      const bd = definition(game, b.card), need = Math.min(remaining, lethalFor(b.card, bd, source, sourceDef, game));
      out.push({ blockerId: b.card.instanceId, amount: need });
      remaining -= need;
    }
    return { blockers: out, target: Math.max(0, remaining) };
  }
  if (blockers.length) {
    for (const b of blockers) {
      if (remaining <= 0)
        break;
      const bd = definition(game, b.card), need = Math.min(remaining, Math.max(1, lethalFor(b.card, bd, source, sourceDef, game)));
      out.push({ blockerId: b.card.instanceId, amount: need });
      remaining -= need;
    }
    if (remaining > 0) {
      const last = out[out.length - 1];
      if (last)
        last.amount += remaining;
    }
  }
  return { blockers: out, target: 0 };
}
function emit(onEvent, e) { try {
  onEvent?.(e);
}
catch (err) {
  console.error('Combat event bridge failed', err);
} }
function combatDamageAfterPrevention(game, targetId, amount, sourceId = null) { let left = Math.max(0, Number(amount || 0)); if (game.unpreventableTurn === game.turnNumber) return left; const owner = game.players.find(p => (p.deck?.battlefield || []).some(c => c.instanceId === targetId)); const card = owner?.deck?.battlefield?.find(c => c.instanceId === targetId); if (left > 0 && Number(card?.counters?.shield || 0) > 0) {
  card.counters.shield = Math.max(0, Number(card.counters.shield) - 1);
  return 0;
} for (const shield of game.damagePrevention || []) {
  if (left <= 0)
    break;
  if ((!shield.anyTarget && shield.targetId !== targetId) || (shield.sourceId && shield.sourceId !== sourceId) || Number(shield.amount || 0) <= 0 || !shieldFitsB111(game, shield, targetId, sourceId))
    continue;
  const used = Math.min(left, Number(shield.amount || 0));
  shield.amount = shield.oneShot ? 0 : shield.amount - used;   // "the next time … prevent that damage" is used up by the first damage
  left -= used;
} game.damagePrevention = (game.damagePrevention || []).filter(s => Number(s.amount || 0) > 0); return left; }
function applyQueue(game, queue, events, onEvent) {
  // Per source, what it hit this step: "Whenever ~ deals combat damage" triggers once per step,
  // whether it attacked or blocked, and however many things it damaged.
  const dealt = new Map();
  for (const hit of queue) {
    const { sourcePlayer, source, sourceDef } = hit;
    // "This creature assigns no combat damage this turn." (Bone Dancer, Laccolith Whelp)
    if ((source?.temporaryEffects || []).some(e => e?.kind === 'no-combat-damage')) continue;
    const targetId = hit.kind === 'player' ? hit.targetPlayer.playerId : hit.target.instanceId;
    const boosted = damageAmount(game, { sourceControllerId: sourcePlayer.playerId, colors: sourceDef?.colors || [], targetPlayerId: hit.kind === 'player' ? targetId : null, targetControllerId: hit.kind === 'player' ? null : (hit.target.controllerId || null) }, Number(hit.amount || 0));
    const fog = (game.combatPrevention || []).some(x => x.turn === game.turnNumber && game.unpreventableTurn !== game.turnNumber && (x.scope === 'all' || (x.scope === 'you' && hit.kind === 'player' && x.playerId === targetId) || (x.scope === 'card' && (x.cardId === targetId || x.cardId === source?.instanceId)) || (x.scope === 'by-card' && x.cardId === source?.instanceId) || (x.scope === 'to-card' && x.cardId === targetId) || (x.scope === 'players' && hit.kind === 'player') || (x.scope === 'power-le' && Number(effectivePower(source, sourceDef, game)) <= Number(x.limit))));
    const original = boosted, amount = fog ? 0 : combatDamageAfterPrevention(game, targetId, original, source?.instanceId), prevented = original - amount;
    if (hit.kind === 'player') {
      const target = hit.targetPlayer;
      if (amount > 0 && isInfect(source, sourceDef, game)) {
        target.poison = Math.max(0, Number(target.poison || 0) + amount);
        events.push(`${target.displayName} gets ${amount} poison counter${amount === 1 ? '' : 's'} from ${sourceDef?.name || 'an attacker'}.`);
      }
      else if (amount > 0) {
        if (!lifeFixed(game, target)) target.life = Math.max(0, Number(target.life || 0) - amount);
        events.push(`${target.displayName} takes ${amount} combat damage from ${sourceDef?.name || 'an attacker'}.`);
      }
      if (prevented)
        events.push(`${prevented} combat damage to ${target.displayName} is prevented.`);
      // Inkshield: "For each 1 damage prevented this way, create a 2/1 … Inkling creature token with flying."
      const ink = fog && prevented > 0 && (game.combatPrevention || []).find(x => x.turn === game.turnNumber && x.scope === 'you' && x.playerId === targetId && x.tokenPerDamage);
      if (ink) { try { applyEffects(game, ink.playerId, [{ ...ink.tokenPerDamage, amount: prevented }], { sourceId: null }); events.push(`${target.displayName} creates ${prevented} token${prevented === 1 ? '' : 's'}.`); } catch { /* the tokens are made by hand */ } }
      const tox = amount > 0 ? toxicValue(sourceDef) : 0;
      if (tox > 0) {
        target.poison = Math.max(0, Number(target.poison || 0) + tox);
        events.push(`${target.displayName} gets ${tox} poison counter${tox === 1 ? '' : 's'} from toxic.`);
      }
      const cmd = commanderFor(sourcePlayer, source);
      if (amount > 0 && cmd && game.rulesConfig?.commanderDamage !== false && !isInfect(source, sourceDef, game)) {
        target.commanderDamage = target.commanderDamage || {};
        target.commanderDamage[cmd.id] = Number(target.commanderDamage[cmd.id] || 0) + amount;
        events.push(`${target.displayName} has taken ${target.commanderDamage[cmd.id]} commander damage from ${sourceDef?.name || 'that commander'}.`);
      }
      sourcePlayer.counters = sourcePlayer.counters || {};
      sourcePlayer.counters.damageDealt = Number(sourcePlayer.counters.damageDealt || 0) + amount;
      if (amount > 0 && isLifelink(source, sourceDef, game)) {
        const gained = lifeGainAmount(game, sourcePlayer.playerId, amount);
        sourcePlayer.life = Math.max(0, Number(sourcePlayer.life || 0) + gained);
        emit(onEvent, { type: 'life-gained', playerId: sourcePlayer.playerId, amount: gained, sourceId: source.instanceId, controllerId: sourcePlayer.playerId });
      }
      if (amount > 0)
        emit(onEvent, { type: 'combat-damage-player', sourceId: source.instanceId, definitionId: source.definitionId, controllerId: sourcePlayer.playerId, playerId: target.playerId, amount });
      if (amount > 0)
        noteDealt(dealt, hit, amount, 'player');
    }
    else {
      const target = hit.target, targetType = String(definition(game, target)?.typeLine || '');
      // Damage to a planeswalker removes loyalty, to a battle removes defense (rule 120.3c, 120.3h).
      const counter = /\bPlaneswalker\b/i.test(targetType) ? 'loyalty' : /\bBattle\b/i.test(targetType) ? 'defense' : null;
      if (amount > 0 && counter) {
        target.counters = target.counters || {};
        target.lastCounterBefore = Number(target.counters[counter] || 0);   // Rith: excess damage to a planeswalker
        target.counters[counter] = Math.max(0, Number(target.counters[counter] || 0) - amount);
        events.push(`${definition(game, target)?.name || 'It'} loses ${amount} ${counter} (${target.counters[counter]} left).`);
      }
      if (counter && !/\bCreature\b/i.test(targetType)) { /* not a creature: no damage marked */ }
      else if (amount > 0 && (isInfect(source, sourceDef, game) || isWither(source, sourceDef, game))) {
        target.counters = target.counters || {};
        target.counters['-1/-1'] = Number(target.counters['-1/-1'] || 0) + amount;
      }
      else if (amount > 0)
        target.damageMarked = Number(target.damageMarked || 0) + amount;
      if (amount > 0 && isDeathtouch(source, sourceDef, game))
        target.deathtouchDamage = true;
      if (prevented)
        events.push(`${prevented} combat damage to ${definition(game, target)?.name || 'a creature'} is prevented.`);
      if (amount > 0 && isLifelink(source, sourceDef, game)) {
        const gained = lifeGainAmount(game, sourcePlayer.playerId, amount);
        sourcePlayer.life = Math.max(0, Number(sourcePlayer.life || 0) + gained);
        emit(onEvent, { type: 'life-gained', playerId: sourcePlayer.playerId, amount: gained, sourceId: source.instanceId, controllerId: sourcePlayer.playerId });
      }
      if (amount > 0)
        emit(onEvent, { type: 'combat-damage-creature', sourceId: source.instanceId, definitionId: source.definitionId, controllerId: sourcePlayer.playerId, targetId: target.instanceId, amount });
      if (amount > 0)
        noteDealt(dealt, hit, amount, /Planeswalker/i.test(definition(game, target)?.typeLine || '') ? 'planeswalker' : /Battle/i.test(definition(game, target)?.typeLine || '') ? 'battle' : 'creature');
    }
  }
  for (const d of dealt.values())
    emit(onEvent, { type: 'combat-damage-dealt', sourceId: d.sourceId, definitionId: d.definitionId, controllerId: d.controllerId, amount: d.amount, to: [...d.to] });
}
function noteDealt(dealt, hit, amount, kind) {
  const id = hit.source.instanceId;
  const row = dealt.get(id) || { sourceId: id, definitionId: hit.source.definitionId, controllerId: hit.sourcePlayer.playerId, amount: 0, to: new Set() };
  row.amount += amount;
  row.to.add(kind);
  dealt.set(id, row);
}
function stateBasedDeaths(game, events, onEvent) {
  // Repeat because one death can change anthem effects and make another creature lethal.
  let changed = true, guard = 0;
  while (changed && guard++ < 20) {
    changed = false;
    for (const p of game.players) {
      const bf = p.deck?.battlefield || [];
      for (let i = bf.length - 1; i >= 0; i--) {
        const c = bf[i], d = definition(game, c);
        if (!/Creature/i.test(d?.typeLine || ''))
          continue;
        const t = effectiveToughness(c, d, game), lethal = t <= 0 || Number(c.damageMarked || 0) >= t || !!c.deathtouchDamage;
        if (!lethal)
          continue;
        if (t > 0 && (isIndestructible(c, d, game) || regenerates(game, c)))
          continue;
        bf.splice(i, 1);
        const exiledInstead = graveyardDestination(game, c) === 'exile';   // before its temporary effects are cleared (Unearth, Suplex)
        const last = { counters: { ...(c.counters || {}) }, castMode: c.castMode || null, auraControllers: game.players.flatMap(q => (q.deck?.battlefield || []).filter(a => a.attachedTo === c.instanceId && /\bAura\b/.test(game.cardDefinitions?.[a.definitionId]?.typeLine || '')).map(a => a.controllerId || q.playerId)) };
        c.zone = 'graveyard';
        c.tapped = false;
        c.damageMarked = 0;
        c.deathtouchDamage = false;
        c.counters = {};
        c.temporaryEffects = [];
        clearCastState(c, 'graveyard');
        const owner = game.players.find(x => x.playerId === c.ownerId) || p;
        const exiled = exiledInstead || graveyardDestination(game, c) === 'exile';
        if (exiled)
          c.zone = 'exile';
        if (!c.token)
          owner.deck[exiled ? 'exile' : 'graveyard'].push(c);
        events.push(`${d?.name || 'A creature'} dies${c.token ? ' and the token ceases to exist' : ` and is put into ${owner.displayName}'s graveyard`}.`);
        if (!exiled) emit(onEvent, { type: 'dies', sourceId: c.instanceId, definitionId: c.definitionId, controllerId: p.playerId, ownerId: c.ownerId, typeLine: d?.typeLine || '', token: !!c.token, last });
        emit(onEvent, { type: 'leaves-battlefield', sourceId: c.instanceId, definitionId: c.definitionId, controllerId: p.playerId, ownerId: c.ownerId, destination: 'graveyard', typeLine: d?.typeLine || '', token: !!c.token, last });
        changed = true;
      }
    }
  }
}
function resolveStep(game, cs, step, events, onEvent) {
  cs.damageSteps = Number(cs.damageSteps || 0) + 1;   // "one or more … deal combat damage" triggers once for each damage step
  const queue = [];
  for (const a of cs.attackers) {
    const attackerPlayer = locatePlayer(game, a.playerId), defender = locatePlayer(game, a.defenderId), attacker = locateCard(attackerPlayer, a.instanceId);
    if (!attacker || !defender)
      continue;
    const ad = definition(game, attacker);
    const assignments = cs.blocks?.[defender.playerId]?.assignments?.filter(x => x.attackerId === a.instanceId) || [];
    const blockerRows = assignments.map(x => ({ assignment: x, card: locateCard(defender, x.blockerId) })).filter(x => x.card);
    const blockedEver = assignments.length > 0 || a.blocked === true;
    // Attacking a planeswalker or battle: unblocked (and trample) damage goes to it. If it has left
    // the battlefield, that damage is not dealt (rule 506.4).
    const attacked = a.targetId ? findPermanent(game, a.targetId) : null;
    const hitDefender = (amount) => {
      if (!a.targetId) return queuePlayerDamage(queue, attackerPlayer, attacker, ad, defender, amount);
      if (attacked) queueCreatureDamage(queue, attackerPlayer, attacker, ad, attacked.player, attacked.card, definition(game, attacked.card), amount);
    };
    if (dealsInStep(attacker, ad, step, game)) {
      const power = effectivePower(attacker, ad, game);
      if (!blockedEver)
        hitDefender(power);
      else if (blockerRows.length) {
        const trample = isTrample(attacker, ad, game);
        const plan = (a.damageAssignments?.[step]) || smartAttackerAssignment({ power, blockers: blockerRows, game, source: attacker, sourceDef: ad, trample });
        let assigned = 0;
        for (const part of plan.blockers || []) {
          const row = blockerRows.find(x => x.card.instanceId === part.blockerId);
          if (!row)
            continue;
          const amt = Math.max(0, Math.min(power - assigned, Number(part.amount || 0)));
          assigned += amt;
          queueCreatureDamage(queue, attackerPlayer, attacker, ad, defender, row.card, definition(game, row.card), amt);
        }
        if (trample) {
          const spill = Math.max(0, Math.min(power - assigned, Number(plan.target ?? (power - assigned))));
          hitDefender(spill);
        }
      }
      else if (isTrample(attacker, ad, game))
        hitDefender(power);
    }
    for (const row of blockerRows) {
      const bd = definition(game, row.card);
      if (dealsInStep(row.card, bd, step, game))
        queueCreatureDamage(queue, defender, row.card, bd, attackerPlayer, attacker, ad, effectivePower(row.card, bd, game));
    }
  }
  applyQueue(game, queue, events, onEvent);
  stateBasedDeaths(game, events, onEvent);
}
export function resolveCombat(game, { attackerPlayerId = null, onEvent = null } = {}) {
  const cs = game.combatState;
  if (!cs || !Array.isArray(cs.attackers))
    throw new Error('No combat state is available.');
  const events = [];
  if (!cs.attackers.length) {
    cs.resolved = true;
    cs.waitingFor = null;
    return { events, damage: [] };
  }
  const ap = attackerPlayerId || cs.attackers[0]?.playerId;
  for (const a of cs.attackers) {
    const defender = locatePlayer(game, a.defenderId);
    const assignments = cs.blocks?.[a.defenderId]?.assignments?.filter(x => x.attackerId === a.instanceId) || [];
    const source = locateCard(locatePlayer(game, a.playerId), a.instanceId), sd = definition(game, source);
    for (const x of assignments) {
      const bc = locateCard(defender, x.blockerId), bd = definition(game, bc);
      if (bc)
        events.push(`${defender.displayName} blocks ${sd?.name || 'an attacker'} with ${bd?.name || 'a creature'}.`);
    }
  }
  resolveStep(game, cs, 'first', events, onEvent);
  resolveStep(game, cs, 'normal', events, onEvent);
  cs.damage = cs.damage || [];
  cs.damage.push({ resolvedAt: new Date().toISOString(), attackerPlayerId: ap });
  cs.waitingFor = null;
  cs.resolved = true;
  game.phase = 'end-combat';
  const losses = evaluateLosses(game);
  for (const x of losses.newly || []) {
    const q = game.players.find(p => p.playerId === x.playerId);
    events.push(`${q?.displayName || 'A player'} loses the game (${x.reason}).`);
  }
  return { events, damage: cs.damage, losses };
}
export function clearMarkedDamage(game) { for (const p of game.players || [])
  for (const c of p.deck?.battlefield || []) {
    c.damageMarked = 0;
    c.deathtouchDamage = false;
  } }

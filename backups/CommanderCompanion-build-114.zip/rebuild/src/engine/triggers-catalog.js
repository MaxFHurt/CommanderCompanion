import { effectivePower } from './combat.js';
// More trigger wordings (build 43), read before the older readers in triggers.js. Each returns true / false when the
// wording is understood for this event, or undefined to let the older readers decide.
export function catalogTriggerMatch(game, row, t, event, H) {
  let m;
  const me = row.player.playerId, self = row.card.instanceId;
  // The spell's own cast trigger is put on the stack by ops.js as the spell is cast (castTriggers); never from here.
  if (/^When you cast this spell\b/i.test(t)) return event.type === 'spell-cast' && event.sourceId === self && row.zone === 'stack';
  // Exploit: "When this creature exploits a creature, …"
  if ((m = t.match(/^When(?:ever)? (.+?) exploits a creature\b/i))) return event.type === 'exploited' && event.sourceId === self;
  // Mounts: "Whenever this creature attacks while saddled, …"
  if ((m = t.match(/^Whenever (.+?) attacks while saddled\b/i))) return event.type === 'attacks' && row.card.saddledTurn === game.turnNumber && H.subjectEvent(game, row, m[1], event);
  if ((m = t.match(/^Whenever (.+?) becomes saddled\b/i))) return event.type === 'saddled' && H.subjectEvent(game, row, m[1], event);
  // "Whenever a card is put into an opponent's graveyard from anywhere" (Bloodchief Ascension); "Whenever one or more land cards are put
  // into your graveyard from anywhere" (The Gitrog Monster: once for each batch).
  if ((m = t.match(/^Whenever (?:a|an) ([a-z]+ )?card is put into (an opponent'?s|your|a) graveyard from anywhere$/i))) {
    if (event.type !== 'put-into-graveyard') return false;
    if (/opponent/i.test(m[2]) ? event.ownerId === me : /your/i.test(m[2]) ? event.ownerId !== me : false) return false;
    return !m[1] || new RegExp(`\\b${m[1].trim()}\\b`, 'i').test(event.typeLine || '');
  }
  if ((m = t.match(/^Whenever one or more ([a-z]+ )?cards are put into (your|an opponent'?s) graveyard from anywhere$/i))) {
    if (event.type !== 'put-into-graveyard' || (/your/i.test(m[2]) ? event.ownerId !== me : event.ownerId === me)) return false;
    if (m[1] && !new RegExp(`\\b${m[1].trim()}\\b`, 'i').test(event.typeLine || '')) return false;
    if (event.resolutionId && row.card.lastGraveBatch === event.resolutionId) return false;
    if (event.resolutionId) row.card.lastGraveBatch = event.resolutionId;
    return true;
  }
  // Trouble in Pairs: "Whenever an opponent attacks you with two or more creatures, draws their second card each turn, or casts their second spell each turn"
  if (/^Whenever an opponent attacks you with two or more creatures, draws their second card each turn, or casts their second spell each turn$/i.test(t)) {
    const opp = (event.controllerId || event.playerId) && (event.controllerId || event.playerId) !== me;
    if (event.type === 'attackers-declared') return event.controllerId !== me && (event.attacks || []).filter(a => a.defenderId === me).length >= 2;
    if (event.type === 'draw') return event.playerId !== me && Number(event.drawNumberThisTurn || 0) === 2;
    if (event.type === 'spell-cast') { const p = (game.players || []).find(q => q.playerId === event.controllerId); return !!opp && event.controllerId !== me && Number(p?.counters?.spellsCastThisTurn ?? event.castNumberThisTurn ?? 0) === 2; }
    return false;
  }
  // Kutzil: "Whenever one or more creatures you control each with power greater than its base power deals combat damage to a player" (once per damage step)
  if (/^Whenever one or more creatures you control each with power greater than its base power deals? combat damage to a player\b/i.test(t)) {
    if (event.type !== 'combat-damage-player' || event.controllerId !== me) return false;
    const src = (game.players || []).flatMap(p => p.deck?.battlefield || []).find(c => c.instanceId === event.sourceId);
    const d = src && game.cardDefinitions?.[src.definitionId];
    if (!src || !d || !(effectivePower(src, d, game) > Number(d.power || 0))) return false;
    const stamp = `${game.turnNumber}:${game.phase}:${(game.combatState?.attackers || []).length}`;
    if (row.card.kutzilStamp === stamp) return false;
    row.card.kutzilStamp = stamp;
    return true;
  }
  // Olivia, Opulent Outlaw: "Whenever one or more outlaws you control deal combat damage to a player" (once for each player damaged in a damage step).
  // Outlaws are Assassins, Mercenaries, Pirates, Rogues and Warlocks.
  if ((m = t.match(/^Whenever one or more (outlaw)s you control deal combat damage to a player\b/i))) {
    if (event.type !== 'combat-damage-player' || event.controllerId !== me) return false;
    const src = (game.players || []).flatMap(p => p.deck?.battlefield || []).find(c => c.instanceId === event.sourceId);
    const d = src && game.cardDefinitions?.[src.definitionId], subs = ['Assassin', 'Mercenary', 'Pirate', 'Rogue', 'Warlock'];
    const line = String(d?.typeLine || ''), sub = line.split('—')[1] || '';
    if (!src || !d || !(subs.some(x => new RegExp(`\\b${x}\\b`, 'i').test(sub)) || (/\bchangeling\b/i.test(d.oracleText || '') && /\bCreature\b/.test(line)))) return false;
    const stamp = `${game.turnNumber}:${event.playerId}:${game.combatState?.damageSteps || 0}`;
    if (row.card.batchDamageStamp === stamp) return false;
    row.card.batchDamageStamp = stamp;
    return true;
  }
  // Mutate: "Whenever this creature mutates"
  if (/^Whenever (?:this creature|SELF|[A-Z][^,]*) mutates\b/i.test(t) && /mutates$/i.test(t)) return event.type === 'mutated' && event.sourceId === self;
  // Kardur: "Whenever an attacking creature dies"
  if (/^Whenever an attacking creature dies\b/i.test(t)) return event.type === 'dies' && (!!event.wasAttacking || (game.combatState?.attackers || []).some(a => a.instanceId === event.sourceId) || (event.attackers || []).includes(event.sourceId));
  switch (event.type) {
    case 'class-level':
      if ((m = t.match(/^When this Class becomes level (\d+)/i))) return event.sourceId === self && Number(event.level ?? event.to) === Number(m[1]);
      return undefined;
    case 'turned-face-up':
      if ((m = t.match(/^(?:When|Whenever) (.+?) (?:is|are) turned face up/i))) return H.subjectEvent(game, row, m[1], event);
      return undefined;
    case 'cycled':
      if (/cycle or discard|cycles or discards/i.test(t)) return false;   // read from the discard event instead
      if (/^When(?:ever)? you cycle (?:this card|~|this creature)/i.test(t) || (H.selfName(row) && new RegExp(`^When(?:ever)? you cycle ${H.selfName(row)}`, 'i').test(t))) return event.sourceId === self;
      if ((m = t.match(/^Whenever (you|a player|an opponent|another player) cycles? (?:a card|another card|one or more cards)/i))) return H.whoMatches(m[1], event.playerId, row) && (!/another card/i.test(t) || event.sourceId !== self);
      return undefined;
    case 'discard':
      if ((m = t.match(/^Whenever (you|a player|an opponent) cycles? or discards? (?:a card|another card|one or more cards)/i))) return H.whoMatches(m[1], event.playerId, row) && (!/another card/i.test(t) || event.sourceId !== self);
      if (/^When(?:ever)? you cycle or discard (?:this card|~)/i.test(t)) return event.sourceId === self;
      return undefined;
    case 'becomes-monstrous':
      if ((m = t.match(/^When(?:ever)? (.+?) becomes monstrous/i))) return H.subjectEvent(game, row, m[1], event);
      return undefined;
    case 'untapped':
      if ((m = t.match(/^Whenever (.+?) becomes untapped/i))) return H.subjectEvent(game, row, m[1], event);
      return undefined;
    case 'tapped':
      if ((m = t.match(/^When(?:ever)? (enchanted|equipped) (creature|land|permanent|artifact) (?:becomes tapped|is tapped(?! for mana))/i))) return event.sourceId === row.card.attachedTo;
      if ((m = t.match(/^Whenever (.+?) becomes tapped/i))) return H.subjectEvent(game, row, m[1], event);
      return undefined;
    case 'postcombat-main-start':
      if ((m = t.match(/^At the beginning of (your|each|each player's|each opponent's) (?:second main phase|postcombat main phase)|^At the beginning of each of your postcombat main phases/i))) {
        const whose = String(m[1] || 'your').toLowerCase();
        return whose === 'your' ? event.playerId === me : /opponent/.test(whose) ? event.playerId !== me : true;
      }
      return undefined;
    case 'proliferated':
      if (/^Whenever you proliferate/i.test(t)) return event.playerId === me;
      return undefined;
    case 'expend':
      if ((m = t.match(/^Whenever you expend (\d+)/i))) return event.playerId === me && Number(event.amount) === Number(m[1]);
      return undefined;
    case 'coin-flipped':
      if (/^Whenever you win (?:a|one or more) coin flips?/i.test(t)) return event.playerId === me && !!event.won;
      if (/^Whenever you lose (?:a|one or more) coin flips?/i.test(t)) return event.playerId === me && !event.won;
      if (/^Whenever (?:you flip one or more coins|you flip a coin)/i.test(t)) return event.playerId === me;
      return undefined;
    case 'die-rolled':
      if (/^Whenever you roll (?:one or more dice|a die)/i.test(t)) return event.playerId === me;
      if ((m = t.match(/^Whenever you roll (?:a|an) (\d+)/i))) return event.playerId === me && Number(event.result) === Number(m[1]);
      return undefined;
    case 'scry':
      if (/^Whenever you scry(?: or surveil)?\b/i.test(t)) return event.playerId === me;
      return undefined;
    case 'surveil':
      if (/^Whenever you (?:scry or )?surveil\b/i.test(t)) return event.playerId === me;
      return undefined;
    case 'ring-tempts':
      if (/^Whenever the Ring tempts you/i.test(t)) return event.playerId === me;
      return undefined;
    case 'crime':
      if (/^Whenever you commit a crime/i.test(t)) return event.playerId === me;
      if (/^Whenever an opponent commits a crime/i.test(t)) return event.playerId !== me;
      return undefined;
    case 'connives':
      if ((m = t.match(/^Whenever (.+?) connives/i))) return H.subjectEvent(game, row, m[1], event);
      return undefined;
    case 'forage':
      if (/^Whenever you forage\b/i.test(t)) return event.playerId === me;
      return undefined;
    case 'explores':
      if ((m = t.match(/^Whenever (.+?) explores/i))) return H.subjectEvent(game, row, m[1], event);
      return undefined;
    case 'becomes-target': {
      m = t.match(/^(?:When|Whenever) (.+?) becomes the target of (?:a|an) (spell or ability|spell|ability|Aura spell|instant or sorcery spell)(?: (you control|an opponent controls|your opponents control))?( for the first time each turn)?/i);
      if (!m) return undefined;
      const subject = /^enchanted creature$/i.test(m[1]) ? event.sourceId === row.card.attachedTo : H.subjectEvent(game, row, m[1], event);
      if (!subject) return subject;
      if (/^spell$/i.test(m[2]) && event.byKind !== 'spell') return false;
      if (/^ability$/i.test(m[2]) && event.byKind === 'spell') return false;
      if (m[3] && (/you control/i.test(m[3]) ? event.byPlayerId !== me : event.byPlayerId === me)) return false;
      if (m[4] && !event.firstThisTurn) return false;
      return true;
    }
    case 'attackers-declared':
      // Trouble in Pairs, Mangara: an opponent attacks you (and/or your planeswalkers) with two or more creatures.
      if ((m = t.match(/^Whenever an opponent attacks (?:you )?with (?:two or more )?creatures(?:, if two or more of those creatures are attacking you(?: and\/or planeswalkers you control)?)?/i)) && /two or more/i.test(t)) {
        if (event.controllerId === me) return false;
        const mine = new Set((game.players || []).find(p => p.playerId === me)?.deck?.battlefield?.map(c => c.instanceId) || []);
        const at = (event.attacks || []).filter(a => a.defenderId === me || (/planeswalkers you control/i.test(t) && a.targetId && mine.has(a.targetId))).length;
        return at >= 2;
      }
      // Duelist's Heritage, Argent Dais: "Whenever one or more (two or more) creatures attack" — any player's attack.
      if ((m = t.match(/^Whenever (one|two|three|four) or more creatures attack(?:,|$)/i))) return (event.attackers || []).length >= { one: 1, two: 2, three: 3, four: 4 }[m[1].toLowerCase()];
      if ((m = t.match(/^Whenever (.+?) and at least (one|two|three|four) other creatures attack/i))) {
        const n = { one: 1, two: 2, three: 3, four: 4 }[m[2].toLowerCase()];
        return (event.attackers || []).includes(self) && (event.attackers || []).length >= n + 1;
      }
      return undefined;
    case 'attacks':
      if ((m = t.match(/^Whenever (a creature|one or more creatures|a creature an opponent controls) attacks? you(?: or a planeswalker you control)?\b/i))) {
        const target = event.targetId && event.targetId !== event.sourceId ? (game.players || []).flatMap(p => p.deck?.battlefield || []).find(c => c.instanceId === event.targetId) : null;
        return event.defenderId === me && (!target || /planeswalker you control/i.test(t));
      }
      return undefined;
    case 'transformed':
      // Build 110: "Whenever this creature enters or transforms into Huntmaster of the Fells": the transform leg, only into that face.
      if ((m = t.match(/^When(?:ever)? (.+?) enters or transforms into (.+)$/i))) return H.subjectEvent(game, row, m[1], event) && String(event.faceName || '').toLowerCase() === m[2].trim().toLowerCase();
      if ((m = t.match(/^When(?:ever)? (.+?) transforms(?: into .+)?$/i))) return H.subjectEvent(game, row, m[1].replace(/ transforms into .+$/i, ''), event);
      return undefined;
    case 'crewed':
      if (/^Whenever (?:this creature|~) crews a Vehicle/i.test(t)) return (event.crewIds || []).includes(self);
      if ((m = t.match(/^Whenever (.+?) becomes crewed/i))) return H.subjectEvent(game, row, m[1], event);
      return undefined;
    case 'tapped-for-mana':
      if (/^Whenever you tap (?:this land|this creature|this artifact|~) for mana/i.test(t)) return event.sourceId === self;
      if ((m = t.match(/^Whenever (a player|you|an opponent) taps? (a land|a [A-Z][a-z]+|a creature|a permanent|an untapped creature) for mana/i))) {
        if (!H.whoMatches(m[1], event.controllerId, row)) return false;
        const what = m[2].toLowerCase().replace(/^an? /, '');
        return what === 'land' ? !!event.land : what === 'permanent' ? true : what === 'creature' ? !!event.creature : new RegExp(`\\b${m[2].replace(/^an? /i, '')}\\b`).test(event.typeLine || '');
      }
      return undefined;
    case 'blocks':
      if ((m = t.match(/^Whenever (.+?) becomes blocked\b/i)) && !/^this creature$|^~$/i.test(m[1])) return H.subjectEvent(game, row, m[1], event, event.attackerId);
      return undefined;
    case 'zone-change':
      if ((m = t.match(/^When(?:ever)? (.+?) is put into (?:a|your) graveyard from anywhere/i)) && event.to === 'graveyard') return H.subjectEvent(game, row, m[1], event);
      // "Whenever one or more (creature) cards leave your graveyard (during your turn)": once for each batch.
      if ((m = t.match(/^Whenever one or more ((?:[a-z]+ )?)cards? leaves? your graveyard( during your turn)?/i))) {
        if (event.from !== 'graveyard' || event.ownerId !== me) return false;
        if (m[2] && game.activePlayerId !== me) return false;
        if (m[1].trim() && !new RegExp(`\\b${m[1].trim()}\\b`, 'i').test(event.typeLine || '')) return false;
        if (event.resolutionId && row.card.lastLeaveBatch === event.resolutionId) return false;
        if (event.resolutionId) row.card.lastLeaveBatch = event.resolutionId;
        return true;
      }
      return undefined;
    case 'damage-player': case 'combat-damage-player': {
      if (/^Whenever you(?:'re| are) dealt damage/i.test(t)) return event.playerId === me;
      // Build 110: "Whenever an opponent is dealt noncombat damage" (Chandra's Spitfire), "Whenever a player is dealt damage".
      if ((m = t.match(/^Whenever (an opponent|a player|another player|each opponent) (?:is|are) dealt (noncombat )?damage$/i))) {
        if (event.type !== 'damage-player' && !(event.type === 'combat-damage-player' && !m[2])) return false;
        if (m[2] && event.combat) return false;
        return H.whoMatches(m[1], event.playerId, row);
      }
      if ((m = t.match(/^Whenever (a source|a creature|a source an opponent controls|a creature an opponent controls) deals (combat )?damage to you\b/i))) {
        if (m[2] && event.type !== 'combat-damage-player') return false;
        return event.playerId === me && (!/opponent controls/i.test(m[1]) || event.controllerId !== me);
      }
      if ((m = t.match(/^Whenever (.+?) deals noncombat damage to (an opponent|a player|one or more opponents)/i))) {
        if (event.type !== 'damage-player' || event.combat) return false;
        if (/opponent/i.test(m[2]) && event.playerId === me) return false;
        if (/^a source you control$/i.test(m[1])) return event.controllerId === me;   // Niv-Mizzet, Visionary; Chandra's Incinerator
        return H.subjectEvent(game, row, m[1], event);
      }
      if ((m = t.match(/^Whenever (.+?) deals damage(?:,|$)/i)) && event.type === 'damage-player' && !event.combat) return H.subjectEvent(game, row, m[1], event);
      return undefined;
    }
    case 'damage-permanent': case 'combat-damage-creature':
      if (/^Whenever a source deals damage to (?:this creature|~)/i.test(t)) return event.targetId === self;
      if ((m = t.match(/^Whenever (.+?) deals (combat )?damage to a creature/i))) { if (m[2] && event.type !== 'combat-damage-creature') return false; return H.subjectEvent(game, row, m[1], event); }
      if ((m = t.match(/^Whenever (.+?) is dealt combat damage/i))) return event.type === 'combat-damage-creature' && H.subjectEvent(game, row, m[1], event, event.targetId);
      if ((m = t.match(/^Whenever (.+?) deals damage(?:,|$)/i)) && event.type === 'damage-permanent') return H.subjectEvent(game, row, m[1], event);
      return undefined;
    case 'combat-damage-dealt':
      if ((m = t.match(/^Whenever (.+?) deals damage(?:,|$)/i))) return H.subjectEvent(game, row, m[1], event);
      if ((m = t.match(/^Whenever (enchanted|equipped) creature deals (?:combat )?damage(?:,|$)/i))) return event.sourceId === row.card.attachedTo;
      return undefined;
  }
  return undefined;
}

/** Extra probe settings for the audit: tried only when the usual probe never fires the trigger. */
export const PROBE_EXTRA_EVENTS = ['mutated', 'put-into-graveyard', 'expend', 'exploited', 'coin-flipped', 'saddled', 'proliferated', 'die-rolled', 'transformed', 'crewed', 'tapped-for-mana', 'class-level', 'turned-face-up', 'cycled', 'becomes-monstrous', 'untapped', 'postcombat-main-start', 'scry', 'surveil', 'ring-tempts', 'crime', 'explores', 'connives', 'forage', 'becomes-target', 'zone-change'];

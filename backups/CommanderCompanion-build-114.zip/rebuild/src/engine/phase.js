import { expirePlayPermissions } from './effects-catalog.js';
import { refreshManaSource, resyncManaSource } from './transactions.js';
export const TURN_STEPS = ['untap', 'upkeep', 'draw', 'precombat-main', 'combat', 'postcombat-main', 'end-step', 'cleanup'];
const LABELS = {
  untap: 'Untap', upkeep: 'Upkeep', draw: 'Draw', 'precombat-main': 'Main 1', combat: 'Combat', 'postcombat-main': 'Main 2', 'end-step': 'End Step', cleanup: 'Cleanup',
  'begin-combat': 'Combat', 'declare-attackers': 'Combat', 'declare-blockers': 'Combat', 'combat-damage': 'Combat', 'end-combat': 'Combat', beginning: 'Untap / Upkeep / Draw', ending: 'Ending'
};
export function phaseLabel(phase) { return LABELS[phase] || String(phase || '').replaceAll('-', ' '); }
export function nextPhase(game) {
  const phase = game.phase === 'beginning' ? 'untap' : game.phase === 'ending' ? 'end-step' : (['begin-combat', 'declare-attackers', 'declare-blockers', 'combat-damage', 'end-combat'].includes(game.phase) ? 'combat' : game.phase);
  const i = TURN_STEPS.indexOf(phase);
  return i < 0 ? TURN_STEPS[0] : TURN_STEPS[(i + 1) % TURN_STEPS.length];
}
function manaSourceUsable(game, card) {
  const def = game?.cardDefinitions?.[card?.definitionId];
  if (!/Creature/i.test(String(def?.typeLine || '')))
    return true;
  const haste = (def?.keywords || []).some(k => String(k).toLowerCase() === 'haste') || /\bHaste\b/i.test(String(def?.oracleText || '')) || (card?.temporaryEffects || []).some(e => e?.kind === 'keyword' && e?.enabled !== false && String(e.keyword || '').toLowerCase() === 'haste');
  if (haste)
    return true;
  return Number(card?.controlSinceTurn ?? card?.enteredTurn ?? -1) < Number(game?.turnNumber || 0);
}
export function resetTurnPlayer(player, game = null) {
  player.counters = player.counters || {};
  player.counters.landsPlayedThisTurn = 0;
  player.counters.extraLandPlaysThisTurn = 0;
  player.counters.cardsDrawnThisTurn = 0;
  player.confirmations = { draw: false, untap: false, attackers: false, blocks: false };
  const fixed = { W: 0, U: 0, B: 0, R: 0, G: 0, C: 0 }, registered = { W: 0, U: 0, B: 0, R: 0, G: 0, C: 0 };
  for (const c of player.deck?.battlefield || []) {
    if (!c.manaCapacityRegistered)
      continue;
    const opts = Array.isArray(c.manaCapacityOptions) ? c.manaCapacityOptions : (c.manaCapacityColor ? [c.manaCapacityColor] : []);
    if (opts.length === 1) {
      const amount = Math.max(1, Number(c.manaCapacityAmount || 1));
      registered[opts[0]] += amount;
      if (!c.tapped && manaSourceUsable(game, c))
        fixed[opts[0]] += amount;
    }
  }
  for (const color of ['W', 'U', 'B', 'R', 'G', 'C'])
    fixed[color] += Math.max(0, Number(player.mana?.total?.[color] || 0) - registered[color]);
  player.mana.available = fixed;
  player.mana.floating = { W: 0, U: 0, B: 0, R: 0, G: 0, C: 0 };
  player.mana.tags = [];
}
export function requiredGatesForPhase(game, phase, player) {
  const gates = {};
  if (phase === 'untap' && (player?.deck?.battlefield || []).some(c => c.tapped))
    gates.untap = { required: true, satisfied: !!player?.confirmations?.untap };
  if (phase === 'draw' && game.rulesConfig?.firstPlayerDraw !== false)
    gates.draw = { required: true, satisfied: !!player?.confirmations?.draw };
  if (['combat', 'begin-combat', 'declare-attackers'].includes(phase))
    gates.combat = { required: true, satisfied: !!player?.confirmations?.attackers };
  if (phase === 'cleanup' && (player?.deck?.hand?.length || 0) > 7)
    gates.discard = { required: true, satisfied: !!player?.confirmations?.discard };
  return gates;
}
export function configurePhaseGates(game, phase = game.phase) { const p = game.players?.find(x => x.playerId === game.activePlayerId) || game.players?.[0]; game.phaseGates = requiredGatesForPhase(game, phase, p); return game.phaseGates; }
function cleanupTemporaryEffects(game) {
  // "… becomes a copy of … until end of turn" (Shifting Woodland) ends.
  for (const p of game.players || []) for (const c of p.deck?.battlefield || []) if (c.copyUntilTurn !== undefined) { delete c.copyDef; delete c.copyUntilTurn; refreshManaSource(game, p, c); }
  // Restore temporary control changes before removing temporary effects.
  const moves = [];
  for (const p of game.players || [])
    for (const c of [...(p.deck?.battlefield || [])]) {
      const control = [...(c.temporaryEffects || [])].reverse().find(e => e?.kind === 'control' && e?.expires === 'cleanup' && e?.previousControllerId);
      if (control && control.previousControllerId !== p.playerId)
        moves.push({ card: c, from: p, toId: control.previousControllerId });
    }
  for (const m of moves) {
    const i = m.from.deck.battlefield.findIndex(c => c.instanceId === m.card.instanceId);
    if (i < 0)
      continue;
    const to = game.players.find(p => p.playerId === m.toId);
    if (!to)
      continue;
    m.from.deck.battlefield.splice(i, 1);
    m.card.controllerId = to.playerId;
    to.deck.battlefield.push(m.card);
  }
  for (const p of game.players || []) {
    p.temporaryPermissions = (p.temporaryPermissions || []).filter(e => e?.expires !== 'cleanup');
    for (const c of p.deck?.battlefield || []) {
      c.damageMarked = 0;
      c.deathtouchDamage = false;
      c.temporaryEffects = (c.temporaryEffects || []).filter(e => e?.expires !== 'cleanup');
      if (c.landTypeChanged && !c.temporaryEffects.some(e => e?.kind === 'land-type')) { delete c.landTypeChanged; resyncManaSource(game, p, c); }   // the land types change back: so does the mana
    }
  }
  game.damagePrevention = (game.damagePrevention || []).filter(e => e?.expires !== 'cleanup');
}
export function cleanupEndCombatEffects(game) { for (const p of game.players || []) {
  for (const c of p.deck?.battlefield || [])
    c.temporaryEffects = (c.temporaryEffects || []).filter(e => e?.expires !== 'end-combat');
  // Myriad tokens are exiled at end of combat (tokens cease to exist).
  if (p.deck?.battlefield) p.deck.battlefield = p.deck.battlefield.filter(c => !(c.token && c.exileEndCombat));
} }
export function advanceTurn(game) {
  cleanupTemporaryEffects(game);
  expirePlayPermissions(game);
  const i = game.players.findIndex(p => p.playerId === game.activePlayerId);
  let step = 1, next = null;
  game.extraTurnQueue = game.extraTurnQueue || [];
  while (game.extraTurnQueue.length && !next) {
    const id = game.extraTurnQueue.shift(), candidate = game.players.find(p => p.playerId === id);
    if (candidate && !candidate.eliminated)
      next = candidate;
  }
  if (!next) {
    next = game.players[(i + step) % game.players.length];
    while (next?.eliminated && step < game.players.length) {
      step++;
      next = game.players[(i + step) % game.players.length];
    }
    if (!next)
      next = game.players[(i + 1) % game.players.length];
    // "You skip your next turn." (build 102): that player's turn is passed over once per skip.
    for (let guard = 0; next && Number(next.skipTurns || 0) > 0 && guard < game.players.length * 4; guard++) {
      next.skipTurns--;
      step++;
      next = game.players[(i + step) % game.players.length];
      while (next?.eliminated && step < game.players.length * 4) { step++; next = game.players[(i + step) % game.players.length]; }
    }
    if ((i + step) >= game.players.length)
      game.roundNumber++;
  }
  game.turnNumber++;
  game.extraCombats = 0;
  game.extraBeforeMain2 = 0;
  // Day and night (game/daynight.js): the turn that ends decides — no spells by its active player makes day night, two or more make night day.
  if (game.dayNight) {
    const ended = (game.players || []).find(p => p.playerId === game.activePlayerId), n = Number(ended?.counters?.spellsCastThisTurn || 0);
    const to = game.dayNight === 'day' && n === 0 ? 'night' : game.dayNight === 'night' && n >= 2 ? 'day' : null;
    if (to) { game.dayNight = to; game.dayNightChanged = game.turnNumber + 1; }
  }
  // Werewolves: "if no spells were cast last turn" / "if a player cast two or more spells last turn".
  game.lastTurnSpells = { total: Number(game.spellsCastThisTurn || 0), most: Math.max(0, ...(game.players || []).map(p => Number(p.counters?.spellsCastThisTurn || 0))) };
  game.spellsCastThisTurn = 0;
  for (const p of game.players)
    if (p.counters) {
      p.counters.spellsCastThisTurn = 0;
      p.counters.castThisTurn = [];
    }
  game.activePlayerId = next.playerId;
  // "you gain protection from everything until your next turn" ends as that player's turn begins.
  if (next.protectionFromEverything) delete next.protectionFromEverything;
  if (next.lifeLocked) delete next.lifeLocked;
  // "Until your next turn" effects (goad, some dungeon rooms) end as that player's turn begins.
  if (game.goadEach) game.goadEach = game.goadEach.filter(g => g.by !== next.playerId);
  for (const p of game.players || [])
    for (const c of p.deck?.battlefield || [])
      if ((c.temporaryEffects || []).some(e => e?.expires === `turn-start:${next.playerId}`))
        c.temporaryEffects = c.temporaryEffects.filter(e => e?.expires !== `turn-start:${next.playerId}`);
  // Power Surge: "the number of untapped lands they controlled at the beginning of this turn" (before the untap step).
  next.turnStartUntappedLands = (next.deck?.battlefield || []).filter(c => !c.tapped && /\bLand\b/.test(game.cardDefinitions?.[c.definitionId]?.typeLine || '')).length;
  game.phase = 'untap';
  game.priorityState = null;
  game.stack = game.stack || [];
  game.pendingTriggers = game.pendingTriggers || [];
  game.combatState = { attackers: [], defenders: [], blocks: {}, damage: [], waitingFor: null, resolved: false };
  resetTurnPlayer(next, game);
  configurePhaseGates(game, 'untap');
  return next;
}
export function setGate(game, key, required = true) { game.phaseGates[key] = { required, satisfied: false }; }
export function satisfyGate(game, key) { if (game.phaseGates[key])
  game.phaseGates[key].satisfied = true; const p = game.players?.find(x => x.playerId === game.activePlayerId); if (p?.confirmations)
  p.confirmations[key] = true; return !phaseLocked(game); }
export function phaseLocked(game) { const p = game.players?.find(x => x.playerId === game.activePlayerId) || game.players?.[0]; const current = requiredGatesForPhase(game, game.phase, p); game.phaseGates = current; return Object.values(current).some(g => g.required && !g.satisfied); }
export function isCombatPhase(phase) { return ['combat', 'begin-combat', 'declare-attackers', 'declare-blockers', 'combat-damage', 'end-combat'].includes(phase); }

import { manaExtras, ANY_COLORS } from './mana-extras.js';
import { withOverlay } from './overlay.js';
import { isCardDefinitionComplete } from './schema.js';
const COLORS = ['W', 'U', 'B', 'R', 'G', 'C'];
export const DEFAULT_COMMANDER_RULES = Object.freeze({
  commanderDamage: true,
  commanderDamageThreshold: 21,
  poisonLoss: true,
  poisonThreshold: 10,
  startingLife: 40,
  commanderTax: true,
  bannedList: true,
  colorIdentity: true,
  singleton: true,
  wishes: false,
  mulligan: 'commander',
  ruleZeroOverrides: false,
  firstPlayerDraw: true,
  endTurnConfirm: true,
  allowExtraLand: false,
  // Skip steps where no player can act (every skip is logged).
  autoSkip: true,
  // Seconds a player has to respond before priority passes automatically. 0 turns the timer off.
  priorityTimer: 69,
  // When true the player picks the card they drew from a physical deck instead of drawing the top card.
  physicalDraw: false,
  // Multiplayer undo needs every player still in to agree, and only for this turn's plays. One shared device always may undo.
  undo: false
});
export function normalizeRulesConfig(config = {}) { return { ...DEFAULT_COMMANDER_RULES, ...(config || {}) }; }
export function evaluateLosses(game) {
  const rules = normalizeRulesConfig(game?.rulesConfig);
  const newly = [];
  for (const p of game?.players || []) {
    if (p.eliminated)
      continue;
    let reason = '';
    if (Number(p.life || 0) <= 0)
      reason = 'life';
    else if (rules.poisonLoss !== false && Number(p.poison || 0) >= Number(rules.poisonThreshold || 10))
      reason = 'poison';
    else if (rules.commanderDamage !== false && Object.values(p.commanderDamage || {}).some(v => Number(v) >= Number(rules.commanderDamageThreshold || 21)))
      reason = 'commander damage';
    else if (Number(p.counters?.failedDraws || 0) > 0)
      reason = 'drew from an empty library';
    else if (p.counters?.lostGame)
      reason = String(p.counters.lostGame);
    if (reason) {
      p.eliminated = true;
      p.eliminationReason = reason;
      newly.push({ playerId: p.playerId, reason });
    }
  }
  const alive = (game?.players || []).filter(p => !p.eliminated), total = (game?.players || []).length;
  if (total > 1 && alive.length === 1) {
    game.winner = alive[0].playerId;
    game.result = 'winner';
    game.status = 'complete';
    game.completionReason = game.completionReason || 'last-player-standing';
  }
  else if (total > 1 && alive.length === 0) {
    game.winner = null;
    game.result = 'draw';
    game.status = 'complete';
    game.completionReason = game.completionReason || 'all-players-eliminated';
  }
  return { newly, alive, winner: game?.winner || null, result: game?.result || null };
}
export function parseManaCost(cost = '') {
  const symbols = [...String(cost).matchAll(/\{([^}]+)\}/g)].map(x => String(x[1] || '').toUpperCase().trim());
  const req = { generic: 0, W: 0, U: 0, B: 0, R: 0, G: 0, C: 0, X: 0, hybrid: [], monoHybrid: [], phyrexian: [], unknown: [], nonMana: [] };
  for (const s of symbols) {
    if (/^\d+$/.test(s)) {
      req.generic += +s;
      continue;
    }
    if (COLORS.includes(s)) {
      req[s]++;
      continue;
    }
    if (s === 'X') {
      req.X++;
      continue;
    }
    if (['T', 'Q', 'E'].includes(s)) {
      req.nonMana.push(s);
      continue;
    }
    const phy = s.match(/^([WUBRGC])(?:\/([WUBRGC]))?\/P$/);
    if (phy) {
      req.phyrexian.push({ symbol: s, colors: [phy[1], phy[2]].filter(Boolean) });
      continue;
    }
    const hy = s.match(/^([WUBRGC])\/([WUBRGC])$/);
    if (hy) {
      req.hybrid.push({ symbol: s, colors: [hy[1], hy[2]] });
      continue;
    }
    const mono = s.match(/^2\/([WUBRG])$/);
    if (mono) {
      req.monoHybrid.push({ symbol: s, color: mono[1] });
      continue;
    }
    req.unknown.push(s);
  }
  return req;
}
function cloneAvailableMana(available = {}) {
  const pool = Object.fromEntries(COLORS.map(c => [c, Math.max(0, Number(available?.[c] || 0))]));
  const flex = (Array.isArray(available?.__flex) ? available.__flex : []).map(x => ({ instanceId: x.instanceId, options: [...new Set((x.options || []).filter(c => COLORS.includes(c)))], zone: x.zone || 'battlefield', zoneManaAbility: !!x.zoneManaAbility })).filter(x => x.instanceId && x.options.length);
  return { pool, flex };
}
function planFixedMana(available, req) {
  const { pool, flex } = cloneAvailableMana(available), chosen = { W: 0, U: 0, B: 0, R: 0, G: 0, C: 0 }, assignments = [], usedFlex = new Set();
  const takeFlex = (color, count) => { for (let n = 0; n < count; n++) {
    const src = flex.find(x => !usedFlex.has(x.instanceId) && x.options.includes(color));
    if (!src)
      return false;
    usedFlex.add(src.instanceId);
    assignments.push({ instanceId: src.instanceId, color, zone: src.zone, zoneManaAbility: src.zoneManaAbility });
  } return true; };
  for (const c of ['W', 'U', 'B', 'R', 'G']) {
    const need = Math.max(0, Number(req[c] || 0)), fixed = Math.min(pool[c], need);
    chosen[c] += fixed;
    pool[c] -= fixed;
    const deficit = need - fixed;
    if (deficit && !takeFlex(c, deficit))
      return null;
  }
  {
    const need = Math.max(0, Number(req.C || 0)), fixed = Math.min(pool.C, need);
    chosen.C += fixed;
    pool.C -= fixed;
    const deficit = need - fixed;
    if (deficit && !takeFlex('C', deficit))
      return null;
  }
  let generic = Math.max(0, Number(req.generic || 0));
  const cUse = Math.min(pool.C, generic);
  chosen.C += cUse;
  pool.C -= cUse;
  generic -= cUse;
  // Creatures tapped for convoke pay generic last, after lands and other sources.
  while (generic > 0) {
    const src = flex.find(x => !usedFlex.has(x.instanceId) && !x.convoke);
    if (!src)
      break;
    usedFlex.add(src.instanceId);
    const color = src.options.includes('C') ? 'C' : src.options[0];
    assignments.push({ instanceId: src.instanceId, color, generic: true, zone: src.zone, zoneManaAbility: src.zoneManaAbility });
    generic--;
  }
  for (const c of ['W', 'U', 'B', 'R', 'G']) {
    if (!generic)
      break;
    const use = Math.min(pool[c], generic);
    chosen[c] += use;
    pool[c] -= use;
    generic -= use;
  }
  while (generic > 0) {
    const src = flex.find(x => !usedFlex.has(x.instanceId));
    if (!src)
      break;
    usedFlex.add(src.instanceId);
    assignments.push({ instanceId: src.instanceId, color: src.options[0], generic: true, zone: src.zone, convoke: !!src.convoke });
    generic--;
  }
  if (generic)
    return null;
  if (assignments.length)
    chosen.__sourceAssignments = assignments;
  return { chosen, remaining: { ...pool, __flex: flex.filter(x => !usedFlex.has(x.instanceId)) }, sourceAssignments: assignments };
}
function paymentSignature(candidate) { const mana = COLORS.map(c => `${c}${Number(candidate?.chosen?.[c] || 0)}`).join('|'), sources = (candidate?.chosen?.__sourceAssignments || []).map(x => `${x.instanceId}:${x.color}`).sort().join(','); return `${mana}|life${candidate.lifePayment || 0}|${sources}`; }
export function manaPaymentOptions(available, cost, tax = 0, lifeAvailable = 0, { maxOptions = 64 } = {}) {
  const req = parseManaCost(cost);
  req.generic += Math.max(0, Number(tax || 0));
  if (req.unknown.length)
    return { ok: false, reason: `Unsupported mana symbol${req.unknown.length === 1 ? '' : 's'}: ${req.unknown.map(x => `{${x}}`).join(' ')}`, required: req, options: [] };
  const decisions = [];
  for (const h of req.hybrid)
    decisions.push({ kind: 'hybrid', symbol: h.symbol, choices: h.colors.map(color => ({ color })) });
  for (const h of req.monoHybrid)
    decisions.push({ kind: 'monoHybrid', symbol: h.symbol, choices: [{ color: h.color }, { generic: 2 }] });
  for (const p of req.phyrexian)
    decisions.push({ kind: 'phyrexian', symbol: p.symbol, choices: [...p.colors.map(color => ({ color })), { life: 2 }] });
  const base = { generic: req.generic, W: req.W, U: req.U, B: req.B, R: req.R, G: req.G, C: req.C }, raw = [], seen = new Set(), lifeCap = Math.max(0, Number(lifeAvailable || 0));
  const walk = (i, need, lifePayment, phyChoices) => { if (raw.length >= Math.max(1, Number(maxOptions || 64)) * 8)
    return; if (i >= decisions.length) {
    if (lifePayment > lifeCap)
      return;
    const planned = planFixedMana(available, need);
    if (!planned)
      return;
    const chosen = { ...planned.chosen };
    if (lifePayment)
      chosen.__lifePayment = lifePayment;
    if (phyChoices.length)
      chosen.__phyrexianChoices = phyChoices;
    const candidate = { chosen, lifePayment, sourceAssignments: planned.sourceAssignments, remaining: planned.remaining }, sig = paymentSignature(candidate);
    if (!seen.has(sig)) {
      seen.add(sig);
      raw.push(candidate);
    }
    return;
  } const d = decisions[i]; for (const choice of d.choices) {
    const next = { ...need }, phy = [...phyChoices];
    let life = lifePayment;
    if (choice.color)
      next[choice.color] = Number(next[choice.color] || 0) + 1;
    if (choice.generic)
      next.generic = Number(next.generic || 0) + choice.generic;
    if (choice.life) {
      life += choice.life;
      if (life > lifeCap)
        continue;
    }
    if (d.kind === 'phyrexian')
      phy.push({ symbol: d.symbol, paidWith: choice.life ? 'life' : choice.color, life: choice.life || 0 });
    walk(i + 1, next, life, phy);
  } };
  walk(0, base, 0, []);
  raw.sort((a, b) => Number(a.lifePayment || 0) - Number(b.lifePayment || 0));
  const options = raw.slice(0, Math.max(1, Number(maxOptions || 64)));
  if (!options.length)
    return { ok: false, reason: req.phyrexian.length ? 'Not enough mana or life to pay this Phyrexian cost.' : 'Not enough mana to pay this cost.', required: req, options: [] };
  return { ok: true, required: req, options };
}
function manaCapacitySourceUsable(game, card) {
  const def = game?.cardDefinitions?.[card?.definitionId];
  if (!/Creature/i.test(String(def?.typeLine || '')))
    return true;
  const haste = (def?.keywords || []).some(k => String(k).toLowerCase() === 'haste') || /\bHaste\b/i.test(String(def?.oracleText || '')) || (card?.temporaryEffects || []).some(e => e?.kind === 'keyword' && e?.enabled !== false && String(e.keyword || '').toLowerCase() === 'haste');
  if (haste)
    return true;
  return Number(card?.controlSinceTurn ?? card?.enteredTurn ?? -1) < Number(game?.turnNumber || 0);
}
function counterAmount(card, name) { const counters = card?.counters || {}; const target = String(name || '').toLowerCase(); for (const [k, v] of Object.entries(counters))
  if (String(k).toLowerCase() === target)
    return Math.max(0, Number(v || 0)); return 0; }
export function effectiveManaOptionsForSource({ game, player, card, definition = null, ability = null } = {}) {
  const def = definition || game?.cardDefinitions?.[card?.definitionId];
  if (!card || !def)
    return [];
  // Gemstone Caverns is conditional: without a luck counter it produces only {C};
  // with a luck counter, the replacement effect makes it one mana of any color instead.
  if (/^Gemstone Caverns$/i.test(String(def?.name || ''))) {
    return counterAmount(card, 'luck') > 0 ? ['W', 'U', 'B', 'R', 'G'] : ['C'];
  }
  // Chrome Mox: "Add one mana of any of the exiled card's colors." — the card it imprinted.
  if (/any of the exiled card'?s colors/i.test(ability?.effect || def?.oracleText || '')) {
    const imp = (game?.players || []).flatMap(p => p.deck?.exile || []).find(c => (card.imprintIds || []).includes(c.instanceId));
    return imp ? [...new Set((game.cardDefinitions?.[imp.definitionId]?.colors || []).filter(x => COLORS.includes(x)))] : [];
  }
  let options = ability?.manaOptions?.length ? [...ability.manaOptions] : Array.isArray(card?.manaCapacityOptions) ? card.manaCapacityOptions.filter(x => COLORS.includes(x)) : [];
  if (options.length < 2 && !ability) {
    options = [...new Set(tapManaAbilities(def).flatMap(row => row.options || []).filter(x => COLORS.includes(x)))];
  }
  const identity = new Set();
  for (const cmd of player?.commanders || [])
    for (const c of game?.cardDefinitions?.[cmd.cardId]?.colorIdentity || [])
      if (COLORS.includes(c))
        identity.add(c);
  if (/commander(?:'s|’s)? color identity/i.test(String(def?.oracleText || '')) && identity.size)
    options = options.filter(x => identity.has(x));
  return [...new Set(options.filter(x => COLORS.includes(x)))];
}
export function playerManaAvailability(player, game = null) {
  const base = Object.fromEntries(COLORS.map(c => [c, Math.max(0, Number(player?.mana?.available?.[c] || 0))]));
  // Extra mana from Mana Reflection, Crypt Ghast, Wild Growth … for each untapped single-type source.
  const extraFlex = [];
  if (game) for (const card of player?.deck?.battlefield || []) {
    const opts = Array.isArray(card.manaCapacityOptions) && card.manaCapacityOptions.length ? card.manaCapacityOptions : (card.manaCapacityColor ? [card.manaCapacityColor] : []);
    if (!card.manaCapacityRegistered || opts.length !== 1 || card.tapped || !manaCapacitySourceUsable(game, card)) continue;
    const b = Math.max(1, Number(card.manaCapacityAmount || 1)), ex = manaExtras(game, card, opts[0], b);
    base[opts[0]] += Math.max(0, ex.amount - b);
    for (const c of ex.fixed) base[c] += 1;   // Wild Growth on an Island, Utopia Sprawl's chosen colour
    extraFlex.push(...Array.from({ length: ex.any }, (_, k) => ({ instanceId: `extra:${card.instanceId}:${k}`, options: [...ANY_COLORS], zone: 'extra', extraOf: card.instanceId })));   // Fertile Ground
  }
  const flex = [];
  for (const card of player?.deck?.battlefield || []) {
    if (card?.tapped || !manaCapacitySourceUsable(game, card))
      continue;
    const def = withOverlay(card, game?.cardDefinitions?.[card?.definitionId]);
    const options = effectiveManaOptionsForSource({ game, player, card, definition: def });
    if (options.length > 1)
      flex.push({ instanceId: card.instanceId, options, zone: 'battlefield' });
    // A mana ability granted by another permanent (Cryptolith Rite, Paradise Mantle) is not a registered source: offer it here.
    else if (options.length === 1 && ((card.grantedText?.length && !card.manaCapacityRegistered && card.grantedText.some(t => /^\{T\}: Add/i.test(t))) || (card.imprintIds?.length && /any of the exiled card'?s colors/i.test(def?.oracleText || ''))))
      flex.push({ instanceId: card.instanceId, options, zone: 'battlefield' });
  }
  // Zone-aware mana abilities explicitly permitted from hand (Spirit Guides and similar cards).
  for (const card of player?.deck?.hand || []) {
    const def = game?.cardDefinitions?.[card?.definitionId];
    for (const ability of parseActivatedAbilities(def)) {
      const cost = String(ability?.cost || '').trim();
      if (!ability?.manaAbility || !/^Exile\s+(?:this card|[^:]+?)\s+from your hand$/i.test(cost))
        continue;
      const options = [...new Set(ability.manaOptions || [])];
      if (options.length)
        flex.push({ instanceId: card.instanceId, options, zone: 'hand', zoneManaAbility: true });
    }
  }
  flex.push(...extraFlex);
  return { ...base, __flex: flex };
}
export function planMana(available, cost, tax = 0, options = {}) {
  const lifeAvailable = options && Number.isFinite(Number(options.lifeAvailable)) ? Math.max(0, Number(options.lifeAvailable)) : 0;
  const planned = manaPaymentOptions(available, cost, tax, lifeAvailable, { maxOptions: Math.max(1, Number(options.maxOptions || 64)) });
  if (!planned.ok)
    return { ok: false, reason: planned.reason, required: planned.required || parseManaCost(cost), chosen: {}, alternatives: [] };
  const best = planned.options[0];
  return { ok: true, required: planned.required, chosen: best.chosen, remaining: best.remaining, sourceAssignments: best.sourceAssignments, lifePayment: best.lifePayment || 0, alternatives: planned.options };
}
function definitionLookup(definitions, game, instance) {
  if (!instance)
    return null;
  if (definitions instanceof Map)
    return definitions.get(instance.definitionId) || null;
  return definitions?.[instance.definitionId] || game?.cardDefinitions?.[instance.definitionId] || null;
}
function spellTargetLegalityIssues({ game, player, definition, definitions } = {}) {
  const text = String(definition?.oracleText || '');
  const issues = [];
  if (!/\btarget\b/i.test(text))
    return issues;
  // A permanent spell's enters-trigger target, and any "up to one target … card", don't have to exist to cast it (Nyla with an empty graveyard).
  if (!/\b(?:Instant|Sorcery)\b/i.test(String(definition?.typeLine || '').split('—')[0]) || /\bup to (?:one|two|three|\w+) target (?:creature )?cards?\b/i.test(text))
    return issues;
  const graveRows = (ownerOnly = false) => {
    const players = ownerOnly ? [player] : (game?.players || []);
    return players.filter(Boolean).flatMap(p => p.deck?.graveyard || []);
  };
  if (/target creature card (?:from|in) your graveyard/i.test(text)) {
    const legal = graveRows(true).some(c => /Creature/i.test(definitionLookup(definitions, game, c)?.typeLine || ''));
    if (!legal)
      issues.push('No creature card is available in your graveyard to target.');
  }
  else if (/target creature card (?:from|in) (?:a|any) graveyard/i.test(text)) {
    const legal = graveRows(false).some(c => /Creature/i.test(definitionLookup(definitions, game, c)?.typeLine || ''));
    if (!legal)
      issues.push('No creature card is available in a graveyard to target.');
  }
  else if (/target card (?:from|in) your graveyard/i.test(text)) {
    if (!graveRows(true).length)
      issues.push('No card is available in your graveyard to target.');
  }
  else if (/target card (?:from|in) (?:a|any) graveyard/i.test(text)) {
    if (!graveRows(false).length)
      issues.push('No card is available in a graveyard to target.');
  }
  return issues;
}
export function validatePlay({ game, player, definition, instance, kind = 'cast', commander = null, definitions, costOverride = null, extraFlex = [] }) {
  const reasons = [];
  const warnings = [];
  if (!definition || !isCardDefinitionComplete(definition))
    reasons.push('Card data is unresolved or incomplete.');
  if (instance && instance.ownerId !== player.playerId)
    reasons.push('This card is not owned by this player.');
  const main = ['precombat-main', 'postcombat-main'].includes(game.phase);
  const active = game?.activePlayerId === player?.playerId;
  const stackEmpty = !Array.isArray(game?.stack) || game.stack.length === 0;
  const type = definition?.typeLine || '';
  const hasFlash = /\bFlash\b/i.test(String(definition?.oracleText || '')) || (definition?.keywords || []).some(k => String(k).toLowerCase() === 'flash');
  const instantSpeed = /\bInstant\b/i.test(type) || hasFlash || (player?.temporaryPermissions || []).some(x => x?.kind === 'flash');
  if (kind !== 'land' && /Cast this spell only during (?:the )?combat\b/i.test(String(definition?.oracleText || '')) && !['begin-combat', 'declare-attackers', 'declare-blockers', 'combat-damage', 'end-combat'].includes(game?.phase))
    reasons.push('This spell can be cast only during combat.');
  if (kind !== 'land' && /Cast this spell only during combat on an opponent'?s turn/i.test(String(definition?.oracleText || '')) && game?.activePlayerId === player?.playerId)
    reasons.push('This spell can be cast only during an opponent\'s turn.');
  if (kind === 'land') {
    if (!active || !main || !stackEmpty)
      reasons.push('A land can normally be played only during your own main phase while the stack is empty.');
    const landLimit = (game.rulesConfig?.allowExtraLand ? 2 : 1) + Number(player.counters?.extraLandPlaysThisTurn || 0);
    if (player.noLandPlayTurn === game.turnNumber)
      reasons.push('You can\'t play lands this turn.');
    if ((player.counters?.landsPlayedThisTurn || 0) >= landLimit)
      reasons.push('Normal land play for this turn has already been used.');
  }
  else if (!instantSpeed && (!active || !main || !stackEmpty))
    reasons.push('This card normally requires your own main phase while the stack is empty.');
  if (kind !== 'land' && definition)
    reasons.push(...spellTargetLegalityIssues({ game, player, definition, definitions }));
  const rules = normalizeRulesConfig(game?.rulesConfig);
  const identity = definitions ? effectiveIdentity(player, definitions) : [];
  if (rules.colorIdentity !== false && definition && identity.length && definition.colorIdentity.some(c => !identity.includes(c)))
    reasons.push('Card color identity is outside the commander identity.');
  const tax = commander && rules.commanderTax !== false ? commander.commanderTax : 0;
  // A card cannot help pay for itself (for example a Spirit Guide exiled from hand for mana).
  const available = playerManaAvailability(player, game);
  if (instance) available.__flex = available.__flex.filter(x => x.instanceId !== instance.instanceId);
  available.__flex.push(...extraFlex.filter(x => !available.__flex.some(y => y.instanceId === x.instanceId)));
  // costOverride is the full cost already worked out (alternative cost, tax, reductions).
  const payment = kind === 'land' ? { ok: true, chosen: {} } : costOverride !== null ? planMana(available, costOverride, 0, { lifeAvailable: Number(player?.life || 0) }) : planMana(available, definition?.manaCost || '', tax, { lifeAvailable: Number(player?.life || 0) });
  if (!payment.ok)
    reasons.push(payment.reason);
  if (rules.ruleZeroOverrides && reasons.length) {
    warnings.push(...reasons.map(x => `Rule Zero override: ${x}`));
    return { legal: true, reasons: [], requiredMana: payment.required || {}, suggestedPayment: payment.chosen || {}, warnings, overridden: true };
  }
  return { legal: reasons.length === 0, reasons, requiredMana: payment.required || {}, suggestedPayment: payment.chosen || {}, warnings };
}
function effectiveIdentity(player, definitions) { return [...new Set(player.commanders.flatMap(c => definitions.get(c.cardId)?.colorIdentity || []))]; }
export function isCommanderEligible(card) {
  if (!card)
    return false;
  const type = card.typeLine || '', text = card.oracleText || '';
  return (/Legendary/i.test(type) && /Creature/i.test(type)) || /can be your commander/i.test(text);
}
export function isSecondaryCommanderEligible(card) {
  return isCommanderEligible(card) || background(card);
}
function characterSelectPartner(x) { return /Partner\s*[—-]\s*Character select/i.test(x?.oracleText || ''); }
function plainPartner(x) { return !characterSelectPartner(x) && /(^|\n)Partner\b(?! with)/i.test(x?.oracleText || ''); }
function friends(x) { return /Friends forever/i.test(x?.oracleText || ''); }
function doctor(x) { return /Legendary Creature[^—]*—[^\n]*Doctor\b/i.test(x?.typeLine || ''); }
function doctorsComp(x) { return /Doctor's companion/i.test(x?.oracleText || ''); }
function background(x) { return /Legendary Enchantment\s+—\s+Background/i.test(x?.typeLine || ''); }
function chooseBg(x) { return /Choose a Background/i.test(x?.oracleText || ''); }
function partnerWith(x, y) { return new RegExp(`Partner with\\s+${String(y?.name || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`, 'i').test(x?.oracleText || ''); }
export function allowsSecondaryCommander(card) {
  if (!card)
    return false;
  return plainPartner(card) || characterSelectPartner(card) || friends(card) || doctorsComp(card) || chooseBg(card) || background(card) || /Partner with\s+/i.test(card.oracleText || '') || doctor(card);
}
export function canShareCommandZone(a, b) {
  if (!a || !b || a.definitionId === b.definitionId)
    return false;
  return (plainPartner(a) && plainPartner(b)) || (characterSelectPartner(a) && characterSelectPartner(b)) || (friends(a) && friends(b)) || (doctor(a) && doctorsComp(b)) || (doctor(b) && doctorsComp(a)) || (background(a) && chooseBg(b)) || (background(b) && chooseBg(a)) || partnerWith(a, b) || partnerWith(b, a);
}
export function validateCommanderConfiguration(commanders = []) {
  if (commanders.length < 1 || commanders.length > 2)
    return { legal: false, reasons: ['Commander requires one commander or an allowed two-card commander configuration.'] };
  if (commanders.length === 1)
    return isCommanderEligible(commanders[0]) ? { legal: true, reasons: [] } : { legal: false, reasons: ['The selected card is not legally eligible to be a commander.'] };
  if (commanders.some(c => !isSecondaryCommanderEligible(c)))
    return { legal: false, reasons: ['Every selected command-zone card must be legal in that Commander configuration.'] };
  const legal = canShareCommandZone(commanders[0], commanders[1]);
  return { legal, reasons: legal ? [] : ['These two cards do not form a legal shared commander configuration.'] };
}
export function validateDeckColorIdentity(definitions, commanders) {
  const identity = [...new Set(commanders.flatMap(c => c.colorIdentity || []))];
  const violations = [];
  for (const d of definitions) {
    if ((d.colorIdentity || []).some(c => !identity.includes(c)))
      violations.push(d.name);
  }
  return { legal: violations.length === 0, identity, violations };
}
function instanceKeyword(instance, definition, name) {
  const n = String(name || '').toLowerCase();
  // "loses defender" / "can attack as though it didn't have defender" wins over every source of the keyword.
  if ((instance?.temporaryEffects || []).some(e => e?.kind === 'keyword' && e?.enabled === false && String(e.keyword || '').toLowerCase() === n))
    return false;
  if (new RegExp(`\\b${String(name).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(String(definition?.oracleText || '')))
    return true;
  if ((definition?.keywords || []).some(x => String(x).toLowerCase() === n))
    return true;
  return (instance?.temporaryEffects || []).some(e => e?.kind === 'keyword' && e?.enabled !== false && String(e.keyword || '').toLowerCase() === n);
}
function combatRestriction(instance, name) { return (instance?.temporaryEffects || []).some(e => e?.kind === 'combat-restriction' && e?.restriction === name); }
export function validateAttack({ game, attackerId, defenderId, instance, definition = null }) {
  const reasons = [];
  if (!['combat', 'begin-combat', 'declare-attackers'].includes(game.phase))
    reasons.push('Attacks can be declared only during combat.');
  if (attackerId === defenderId)
    reasons.push('A player cannot attack themselves.');
  const defender = (game.players || []).find(p => p.playerId === defenderId);
  if (!defender)
    reasons.push('The chosen defending player is not in this game.');
  else if (defender.eliminated)
    reasons.push('An eliminated player cannot be attacked.');
  if (instance?.tapped)
    reasons.push('A tapped creature cannot attack.');
  if (combatRestriction(instance, 'cant-attack-or-block') || combatRestriction(instance, 'cant-attack'))
    reasons.push('This creature cannot attack right now.');
  if (definition && !/Creature/i.test(definition.typeLine || ''))
    reasons.push('Only creatures can attack.');
  if (instanceKeyword(instance, definition, 'Defender') && !/can attack as though it didn'?t have defender/i.test(definition?.oracleText || ''))
    reasons.push('A creature with defender cannot attack.');
  // Goaded: it attacks a player other than the goading player(s) if it can.
  const goaders = goadersOf(game, instance, attackerId);
  if (goaders.has(defenderId) && (game.players || []).some(p => !p.eliminated && p.playerId !== attackerId && !goaders.has(p.playerId)))
    reasons.push('This creature is goaded: it must attack a player who did not goad it.');
  const haste = instanceKeyword(instance, definition, 'Haste');
  if (!haste && Number(instance?.controlSinceTurn ?? instance?.enteredTurn ?? -1) >= Number(game.turnNumber))
    reasons.push('This creature has summoning sickness and cannot attack this turn.');
  return { legal: !reasons.length, reasons };
}
export function validateBlock({ blocker, definition, attackerDefinition, attacker = null }) {
  const reasons = [];
  if (!blocker)
    reasons.push('A blocker must be an actual creature card.');
  if (definition && !/Creature/i.test(definition.typeLine || ''))
    reasons.push('Only creatures can block.');
  if (blocker?.tapped)
    reasons.push('A tapped creature cannot block.');
  if (combatRestriction(blocker, 'cant-block') || combatRestriction(blocker, 'cant-attack-or-block'))
    reasons.push('This creature cannot block this turn.');
  const bt = String(definition?.oracleText || ''), at = String(attackerDefinition?.oracleText || '');
  if (/can'?t block/i.test(bt) || /(?:^|\n)\s*Decayed\b/i.test(bt.replace(/\([^()]*\)/g, '')))
    reasons.push('This creature cannot block.');
  if (/can'?t be blocked/i.test(at) || combatRestriction(attacker, 'cant-be-blocked'))
    reasons.push('This attacker cannot be blocked.');
  const flying = instanceKeyword(attacker, attackerDefinition, 'Flying'), reach = instanceKeyword(blocker, definition, 'Reach'), blockerFlying = instanceKeyword(blocker, definition, 'Flying');
  if (flying && !reach && !blockerFlying)
    reasons.push('A creature with flying can be blocked only by flying or reach unless another effect allows it.');
  if (instanceKeyword(attacker, attackerDefinition, 'Shadow') && !instanceKeyword(blocker, definition, 'Shadow'))
    reasons.push('Shadow prevents this creature from blocking that attacker.');
  if (!instanceKeyword(attacker, attackerDefinition, 'Shadow') && instanceKeyword(blocker, definition, 'Shadow'))
    reasons.push('A creature with shadow can block only creatures with shadow.');
  const blockerArtifact = /Artifact/i.test(definition?.typeLine || ''), blockerColors = definition?.colors || [];
  if (instanceKeyword(attacker, attackerDefinition, 'Fear') && !blockerArtifact && !blockerColors.includes('B'))
    reasons.push('Fear: only artifact or black creatures can block it.');
  if (instanceKeyword(attacker, attackerDefinition, 'Intimidate') && !blockerArtifact && !blockerColors.some(c => (attackerDefinition?.colors || []).includes(c)))
    reasons.push('Intimidate: only artifact creatures or creatures sharing a color can block it.');
  // "Target creature can't block this creature this turn."
  if ((blocker?.temporaryEffects || []).some(e => e?.kind === 'cant-block-creature' && e.creatureId === attacker?.instanceId))
    reasons.push('It can\u2019t block that creature this turn.');
  // Skulk: can't be blocked by creatures with greater power. Unleash: a creature with a +1/+1 counter can't block.
  if (instanceKeyword(attacker, attackerDefinition, 'Skulk') && Number(definition?.power || 0) + Number(blocker?.counters?.['+1/+1'] || 0) - Number(blocker?.counters?.['-1/-1'] || 0) > Number(attackerDefinition?.power || 0) + Number(attacker?.counters?.['+1/+1'] || 0) - Number(attacker?.counters?.['-1/-1'] || 0))
    reasons.push('Skulk: creatures with greater power can\u2019t block it.');
  if (/(?:^|\n)\s*Unleash\b/i.test(String(definition?.oracleText || '')) && Number(blocker?.counters?.['+1/+1'] || 0) > 0)
    reasons.push('Unleash: it has a +1/+1 counter, so it can\u2019t block.');
  if (instanceKeyword(attacker, attackerDefinition, 'Horsemanship') && !instanceKeyword(blocker, definition, 'Horsemanship'))
    reasons.push('Horsemanship: only creatures with horsemanship can block it.');
  return { legal: !reasons.length, reasons };
}
export function validateForcedBlockAssignments({ game, defender, assignments = [] } = {}) {
  const reasons = [];
  if (!game || !defender)
    return { legal: true, reasons };
  const attackers = (game.combatState?.attackers || []).filter(a => a.defenderId === defender.playerId);
  for (const blocker of defender.deck?.battlefield || []) {
    for (const fx of blocker.temporaryEffects || []) {
      if (fx?.kind !== 'forced-block' || !fx.attackerId)
        continue;
      const attack = attackers.find(a => a.instanceId === fx.attackerId);
      if (!attack)
        continue;
      const attackerOwner = (game.players || []).find(p => (p.deck?.battlefield || []).some(c => c.instanceId === attack.instanceId));
      const attacker = attackerOwner?.deck?.battlefield?.find(c => c.instanceId === attack.instanceId);
      const bdef = game.cardDefinitions?.[blocker.definitionId], adef = attacker && game.cardDefinitions?.[attacker.definitionId];
      if (!attacker || !validateBlock({ blocker, definition: bdef, attackerDefinition: adef, attacker }).legal)
        continue;
      const assigned = assignments.some(x => x.blockerId === blocker.instanceId && x.attackerId === attack.instanceId);
      if (!assigned)
        reasons.push(`${bdef?.name || 'A creature'} must block ${adef?.name || 'the chosen attacker'} if able.`);
    }
  }
  // Build 102: "Target creature blocks this turn if able" (any attacker), "It must be blocked this turn if able", and
  // "All creatures able to block target creature this turn do so" (Lure for one turn).
  const findCard = id => { for (const q of game.players || []) { const c = (q.deck?.battlefield || []).find(x => x.instanceId === id); if (c) return c; } return null; };
  const canBlock = (b, a) => !!a && validateBlock({ blocker: b, definition: game.cardDefinitions?.[b.definitionId], attackerDefinition: game.cardDefinitions?.[a.definitionId], attacker: a }).legal;
  const mine = defender.deck?.battlefield || [];
  for (const blocker of mine) {
    if (!(blocker.temporaryEffects || []).some(e => e?.kind === 'must-block-any')) continue;
    if (assignments.some(x => x.blockerId === blocker.instanceId)) continue;
    if (attackers.some(a => canBlock(blocker, findCard(a.instanceId)))) reasons.push(`${game.cardDefinitions?.[blocker.definitionId]?.name || 'A creature'} must block this turn if able.`);
  }
  for (const a of attackers) {
    const card = findCard(a.instanceId);
    if (!card) continue;
    const fx = card.temporaryEffects || [];
    const name = game.cardDefinitions?.[card.definitionId]?.name || 'That attacker';
    if (fx.some(e => e?.kind === 'lure-turn')) {
      for (const b of mine) if (canBlock(b, card) && !assignments.some(x => x.blockerId === b.instanceId && x.attackerId === card.instanceId)) reasons.push(`${game.cardDefinitions?.[b.definitionId]?.name || 'A creature'} must block ${name} if able.`);
    } else if (fx.some(e => e?.kind === 'must-be-blocked') && !assignments.some(x => x.attackerId === card.instanceId) && mine.some(b => canBlock(b, card) && !assignments.some(x => x.blockerId === b.instanceId)))
      reasons.push(`${name} must be blocked if able.`);
  }
  return { legal: reasons.length === 0, reasons };
}
export function validateBlockAssignments({ game, defender, assignments = [] } = {}) {
  const reasons = [];
  if (!game || !defender)
    return { legal: false, reasons: ['Defender and game state are required.'] };
  const incoming = (game.combatState?.attackers || []).filter(a => a.defenderId === defender.playerId);
  const incomingIds = new Set(incoming.map(a => a.instanceId));
  const seenPairs = new Set(), counts = new Map();
  for (const row of assignments || []) {
    if (!row?.blockerId || !row?.attackerId) {
      reasons.push('Every blocker assignment must name a blocker and attacker.');
      continue;
    }
    const pair = `${row.blockerId}=>${row.attackerId}`;
    if (seenPairs.has(pair)) {
      reasons.push('The same blocker cannot be assigned to the same attacker more than once.');
      continue;
    }
    seenPairs.add(pair);
    if (!incomingIds.has(row.attackerId)) {
      reasons.push('A blocker was assigned to a creature that is not attacking this defender.');
      continue;
    }
    const blocker = (defender.deck?.battlefield || []).find(c => c.instanceId === row.blockerId);
    if (!blocker) {
      reasons.push('A blocker assignment references a creature this defender does not control on the battlefield.');
      continue;
    }
    const attack = incoming.find(a => a.instanceId === row.attackerId);
    const attackerOwner = (game.players || []).find(p => (p.deck?.battlefield || []).some(c => c.instanceId === attack?.instanceId));
    const attacker = attackerOwner?.deck?.battlefield?.find(c => c.instanceId === attack?.instanceId);
    const bdef = game.cardDefinitions?.[blocker.definitionId], adef = attacker && game.cardDefinitions?.[attacker.definitionId];
    const legal = validateBlock({ blocker, definition: bdef, attackerDefinition: adef, attacker });
    if (!legal.legal) {
      reasons.push(`${bdef?.name || 'That creature'} cannot block ${adef?.name || 'that attacker'}: ${legal.reasons[0] || 'illegal block'}`);
      continue;
    }
    counts.set(blocker.instanceId, (counts.get(blocker.instanceId) || 0) + 1);
    if (counts.get(blocker.instanceId) > blockerCapacity(bdef, blocker))
      reasons.push(`${bdef?.name || 'That creature'} is assigned to block more attackers than it can legally block.`);
  }
  for (const attack of incoming) {
    const attackerOwner = (game.players || []).find(p => (p.deck?.battlefield || []).some(c => c.instanceId === attack.instanceId));
    const attacker = attackerOwner?.deck?.battlefield?.find(c => c.instanceId === attack.instanceId);
    const adef = attacker && game.cardDefinitions?.[attacker.definitionId];
    const count = (assignments || []).filter(x => x.attackerId === attack.instanceId).length, min = attackerMinimumBlockers(adef, attacker);
    if (count > 0 && count < min)
      reasons.push(`${adef?.name || 'That attacker'} requires at least ${min} blockers.`);
  }
  const forced = validateForcedBlockAssignments({ game, defender, assignments });
  if (!forced.legal)
    reasons.push(...forced.reasons);
  return { legal: reasons.length === 0, reasons };
}
const NUMBER_WORDS = { one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12 };
function commanderCopyLimit(card) {
  if (!card)
    return 1;
  if (/\bBasic\b.*\bLand\b/i.test(card.typeLine || ''))
    return Infinity;
  const text = String(card.oracleText || '');
  if (/A deck can have any number of cards named/i.test(text))
    return Infinity;
  const m = text.match(/A deck can have up to\s+(\d+|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)\s+cards named/i);
  if (m) {
    const k = String(m[1]).toLowerCase();
    return /^\d+$/.test(k) ? Number(k) : (NUMBER_WORDS[k] || 1);
  }
  return 1;
}
export function validateCommanderDeck({ manifest = [], definitions = [], commanders = [], rulesConfig = {} } = {}) {
  const rules = normalizeRulesConfig(rulesConfig);
  const reasons = [];
  const warnings = [];
  const defs = definitions instanceof Map ? definitions : new Map((definitions || []).map(d => [d.definitionId, d]));
  const total = (manifest || []).reduce((n, e) => n + Number(e.quantity ?? e.qty ?? 1), 0);
  if (total !== 100)
    reasons.push(`Commander decks must contain exactly 100 cards including commander(s); this deck has ${total}.`);
  const commanderCheck = validateCommanderConfiguration(commanders);
  if (!commanderCheck.legal)
    reasons.push(...commanderCheck.reasons);
  for (const c of commanders) {
    const qty = (manifest || []).filter(e => e.definitionId === c.definitionId).reduce((n, e) => n + Number(e.quantity ?? e.qty ?? 1), 0);
    if (qty < 1)
      reasons.push(`${c.name || 'Selected commander'} is not present in the 100-card deck list.`);
  }
  const byName = new Map();
  for (const e of manifest || []) {
    const d = defs.get(e.definitionId);
    const q = Number(e.quantity ?? e.qty ?? 1);
    if (!Number.isInteger(q) || q < 1) {
      reasons.push(`Deck quantities must be positive whole numbers (${e.definitionId}).`);
      continue;
    }
    if (!d) {
      reasons.push(`Deck contains an unresolved card definition (${e.definitionId}).`);
      continue;
    }
    const key = String(d.name || '').toLocaleLowerCase('en-US');
    const row = byName.get(key) || { name: d.name, quantity: 0, card: d };
    row.quantity += q;
    byName.set(key, row);
    const commanderLegality = d.legalities?.commander;
    if (rules.bannedList !== false && commanderLegality && commanderLegality !== 'legal')
      reasons.push(`${d.name} is ${commanderLegality.replace('_', ' ')} in Commander.`);
  }
  if (rules.singleton !== false)
    for (const { name, quantity, card } of byName.values()) {
      const limit = commanderCopyLimit(card);
      if (quantity > limit)
        reasons.push(limit === 1 ? `${name} appears ${quantity} times; Commander is singleton except for basic lands or cards whose rules text allows extra copies.` : `${name} appears ${quantity} times; its rules allow at most ${limit}.`);
    }
  const identity = validateDeckColorIdentity([...defs.values()], commanders);
  if (rules.colorIdentity !== false && !identity.legal)
    reasons.push(`Cards outside commander color identity: ${identity.violations.slice(0, 8).join(', ')}${identity.violations.length > 8 ? '…' : ''}`);
  return { legal: reasons.length === 0, reasons: [...new Set(reasons)], warnings, total, identity: identity.identity };
}
export function isBasicLand(definition) { return /\bBasic\b.*\bLand\b/i.test(definition?.typeLine || ''); }
export function basicLandManaColor(definition) { const t = definition?.typeLine || ''; if (!isBasicLand(definition))
  return null; if (/Plains/i.test(t))
  return 'W'; if (/Island/i.test(t))
  return 'U'; if (/Swamp/i.test(t))
  return 'B'; if (/Mountain/i.test(t))
  return 'R'; if (/Forest/i.test(t))
  return 'G'; return null; }
export function parseActivatedAbilities(definition) {
  const raw = String(definition?.oracleText || '').replace(/\r/g, '');
  // Equip is an activated ability written as a keyword: treat "Equip {2}" as "{2}: Attach …".
  const lines = raw.split('\n').map(x => x.trim()).filter(Boolean)
    .map(x => x.replace(/^Equip\s*((?:\{[^}]+\})+).*$/i, '$1: Attach this Equipment to target creature you control. Activate only as a sorcery.'))
    // A keyword line's reminder text ("Cycling {3} ({3}, Discard this card: Draw a card.)") explains the keyword; it is
    // not a second ability. A line that is only reminder text ("({T}: Add {G}, {U}, or {R}.)") is kept: it is the mana.
    .map(x => (/^\(/.test(x) ? x : x.replace(/\s*\([^()]*\)/g, '').trim())).filter(Boolean);
  const abilities = [];
  let current = null;
  for (const line of lines) {
    // A colon inside quotes is an ability granted to something else ('Equipped creature has "{T}: …"').
    const quoteAt = line.indexOf('"');
    const looksActivated = line.includes(':') && !(quoteAt >= 0 && quoteAt < line.indexOf(':')) && !/^[•—-]/.test(line) && !/^(When|Whenever|At)\b/i.test(line) && !/(?:^|[—-]\s*)(When|Whenever|At)\b/i.test(line);
    if (looksActivated) {
      if (current)
        abilities.push(current);
      current = { text: line, continuations: [] };
    }
    else if (current && (/^[•—-]/.test(line) || /^Choose\b/i.test(line) || /^Activate (?:only|no more than)\b/i.test(line) || /^This ability\b/i.test(line))) {
      current.continuations.push(line);
    }
    else if (current) {
      abilities.push(current);
      current = null;
    }
  }
  if (current)
    abilities.push(current);
  return abilities.map((a, index) => {
    const full = [a.text, ...a.continuations].join('\n');
    const m = a.text.match(/^(.+?):\s*(.*)$/s);
    const cost = (m?.[1] || '').trim();
    // "…, where X is the number of cards exiled this way" after a cost that exiled, sacrificed or removed them: the cost's count
    // (ops.js remembers it as costCount), written "as a cost" so the amount reader can tell it from an effect's own "this way".
    let effect = [m?.[2] || '', ...a.continuations].filter(Boolean).join('\n').trim();
    if (/\b(?:Exile|Sacrifice|Remove)\b/.test(cost) && /\b(?:exiled|sacrificed|removed) this way\b/i.test(effect)) effect = effect.replace(/\b(exiled|sacrificed|removed) this way\b/gi, '$1 as a cost');
    const modes = [...effect.matchAll(/(?:^|\n)•\s*([^\n]+)/g)].map(x => x[1].trim());
    const chooseMatch = effect.match(/Choose\s+(one|two|three|one or more)\s*[—-]/i);
    const loyaltyMatch = cost.match(/^([+−-])\s*(\d+)$/);
    const loyaltyDelta = loyaltyMatch ? (loyaltyMatch[1] === '+' ? 1 : -1) * Number(loyaltyMatch[2]) : null;
    return {
      id: `ability-${index}`,
      text: full,
      cost, effect,
      requiresTap: /\{T\}/i.test(cost),
      requiresUntap: /\{Q\}/i.test(cost),
      sacrificesSelf: /Sacrifice\s+(?:this permanent|this creature|this artifact|this enchantment|this land|this planeswalker|~)\b/i.test(cost) || new RegExp(`Sacrifice\\s+${String(definition?.name || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(cost),
      sacrificeRequirement: (cost.match(/Sacrifice\s+(?:an?\s+|another\s+)?(creature|artifact|enchantment|land|permanent)(?: or (artifact|creature|enchantment|land))?\b/i) || []).slice(1, 3).filter(Boolean).join(' or ').toLowerCase() || null,   // "Sacrifice another creature or artifact" (Ayara)
      // "Sacrifice two Treasures" (Olivia, Opulent Outlaw): several permanents of one kind, chosen as the cost is paid.
      sacrificeMany: (m2 => (m2 ? { n: { a: 1, an: 1, two: 2, three: 3, four: 4, five: 5, six: 6 }[m2[1].toLowerCase()] || Number(m2[1]), word: m2[2].replace(/s$/i, '').toLowerCase() } : null))(cost.match(/Sacrifice (two|three|four|five|six|\d+) (?!of\b)([A-Za-z]+?s?)(?=[,:]|$|\s*\{)/i) || cost.match(/Sacrifice (an?) (?!(?:creature|artifact|enchantment|land|permanent|planeswalker|nonland|another|other)\b)([A-Z][a-z]+)(?=[,:]|$|\s*\{)/)),
      discards: /Discard\b/i.test(cost),
      discardCount: /Discard\s+(?:a|one)\s+card/i.test(cost) || /Discard\s+an?\s+[A-Za-z ]+? card\b/i.test(cost) ? 1 : 0,
      // Tidal Control: "Pay 2 life or {2}": one or the other (the player who activates picks); no life is owed until they choose it.
      costChoice: (m3 => (m3 ? { life: Number(m3[1]), mana: m3[2] } : null))(cost.match(/^Pay (\d+) life or ((?:\{[^}]+\})+)$/i)),
      lifeCost: /^Pay \d+ life or (?:\{[^}]+\})+$/i.test(cost) ? 0 : Number((cost.match(/Pay\s+(\d+)\s+life/i) || [])[1] || 0),
      energyCost: (cost.match(/\{E\}/gi) || []).length,
      loyaltyDelta,
      hasX: /\{X\}|\bX\b/.test(cost) || (/\bX\b/.test(effect) && !/\bwhere X is\b/i.test(effect)),   // "where X is …" is worked out, not chosen
      needsTarget: /\btarget\b/i.test(effect),
      modes,
      modeCount: chooseMatch ? chooseMatch[1].toLowerCase() : null,
      manaAbility: isManaAbilityLine(full),
      manaOptions: manaOptionsFromAbility(full)
    };
  });
}
export function activatedAbilityLines(definition) { return parseActivatedAbilities(definition).map(a => a.text); }
export function isManaAbilityLine(line = '') {
  const [cost, effect = ''] = String(line).split(/:(.*)/s);
  return /\bAdd\b/i.test(effect) && !/\btarget\b/i.test(effect) && !/(loyalty|planeswalker)/i.test(cost);
}
export function manaOptionsFromAbility(line = '') {
  if (!isManaAbilityLine(line))
    return [];
  const effect = String(line).split(/:(.*)/s)[1] || '';
  const out = [];
  for (const m of effect.matchAll(/\{([WUBRGC])\}/g))
    out.push(m[1]);
  // "one mana of any color", "three mana of any one color" (Gilded Lotus), "Choose a color. Add … mana of that color" (Nykthos).
  if (/mana of any (?:one )?color|mana in any combination of colors|Choose a color\.[^]*mana of that color/i.test(effect))
    out.push('W', 'U', 'B', 'R', 'G');
  if (/mana of any type/i.test(effect))
    out.push('W', 'U', 'B', 'R', 'G', 'C');
  return [...new Set(out)];
}
// Free tap abilities only: Nykthos's "{2}, {T}: …" is not mana the auto-payer can count on.
export function tapManaAbilities(definition) { return parseActivatedAbilities(definition).filter(a => a.requiresTap && a.manaAbility && a.manaOptions.length && !/\{(?:\d+|[WUBRGCX])(?:\/[WUBRGP])?\}/i.test(String(a.cost || '').replace(/\{T\}/gi, ''))).map(a => ({ text: a.text, options: a.manaOptions, ability: a })); }
export function validateActivatedAbility({ game, instance, definition, ability }) {
  const reasons = [];
  if (!instance)
    reasons.push('The source permanent is no longer available.');
  if (!ability)
    reasons.push('The selected activated ability is unavailable.');
  if (ability?.requiresTap && instance?.tapped)
    reasons.push('This permanent is already tapped and cannot pay {T}.');
  if (ability?.requiresUntap && !instance?.tapped)
    reasons.push('This permanent is untapped and cannot pay {Q}.');
  const hasHaste = instanceKeyword(instance, definition, 'Haste');
  if ((ability?.requiresTap || ability?.requiresUntap) && /Creature/i.test(definition?.typeLine || '') && !hasHaste && Number(instance?.controlSinceTurn ?? instance?.enteredTurn ?? -1) >= Number(game?.turnNumber))
    reasons.push('This creature has summoning sickness and cannot activate an ability with {T} or {Q} in its cost.');
  return { legal: !reasons.length, reasons };
}
/** "This ability costs {1} less to activate for each legendary creature you control." (Boseiju, Takenuma) */
export function activationReduction(game, player, ability) {
  // Equip: "Equip abilities you activate cost {1} less to activate" (Danitha Capashen); "Metalcraft — Equipment you control have
  // equip {0} as long as you control three or more artifacts" (Puresteel Paladin).
  if (player && (/^Equip\b/i.test(String(ability?.text || '')) || /^Attach this Equipment to target creature you control\b/i.test(String(ability?.effect || '')))) {
    let n = 0;
    const mine = player.deck?.battlefield || [];
    const artifacts = mine.filter(c => /\bArtifact\b/.test(withOverlay(c, game?.cardDefinitions?.[c.definitionId])?.typeLine || '')).length;
    for (const c of mine) {
      const t = String(withOverlay(c, game?.cardDefinitions?.[c.definitionId])?.oracleText || '');
      const r = t.match(/Equip abilities you activate cost \{(\d+)\} less to activate/i);
      if (r) n += Number(r[1]);
      if (/Equipment you control have equip \{0\}(?: as long as you control three or more artifacts)?/i.test(t) && (!/three or more artifacts/i.test(t) || artifacts >= 3)) n += 99;
    }
    return n;
  }
  const m = String(ability?.effect || '').match(/This ability costs \{(\d+)\} less to activate for each ([a-z ]+?) you control/i);
  if (!m || !player) return 0;
  const words = m[2].trim().split(/\s+/), noun = words.pop().replace(/s$/, '');
  const n = (player.deck?.battlefield || []).filter(c => { const t = withOverlay(c, game?.cardDefinitions?.[c.definitionId])?.typeLine || ''; return new RegExp(`\\b${noun}\\b`, 'i').test(t) && words.every(w => new RegExp(`\\b${w}\\b`, 'i').test(t)); }).length;
  return Number(m[1]) * n;
}
export function validateActivatedAbilityFull({ game, player, instance, definition, ability, definitions } = {}) {
  const base = validateActivatedAbility({ game, instance, definition, ability });
  const reasons = [...base.reasons];
  if (!player)
    reasons.push('The activating player is unavailable.');
  if (ability?.sacrificesSelf && instance?.zone !== 'battlefield')
    reasons.push('The source permanent is no longer on the battlefield to sacrifice.');
  const cost = String(ability?.cost || '');
  const manaCost = (cost.match(/\{(?:\d+|[WUBRGC](?:\/[WUBRGC])?(?:\/P)?|2\/[WUBRG])\}/gi) || []).join('');
  if (ability?.costChoice && player) {
    // life or mana, whichever the player can pay
    const lifeOk = Number(player.life || 0) >= ability.costChoice.life, manaOk = planMana(playerManaAvailability(player, game), ability.costChoice.mana, 0, { lifeAvailable: 0 }).ok;
    if (!lifeOk && !manaOk) reasons.push(`Pay ${ability.costChoice.life} life or ${ability.costChoice.mana}: you can pay neither.`);
  } else if (manaCost && player) {
    const red = activationReduction(game, player, ability);
    const reduced = red ? manaCost.replace(/\{(\d+)\}/, (_, n) => `{${Math.max(0, Number(n) - red)}}`).replace(/\{0\}/, '') : manaCost;
    const payment = planMana(playerManaAvailability(player, game), reduced, 0, { lifeAvailable: Math.max(0, Number(player?.life || 0) - Number(ability?.lifeCost || 0)) });
    if (!payment.ok)
      reasons.push(payment.reason);
  }
  if (ability?.lifeCost && player && Number(player.life || 0) < Number(ability.lifeCost))
    reasons.push('Not enough life to pay this activation cost.');
  // Classes gain one level at a time, as a sorcery; level up (counters) is also sorcery speed.
  const level = String(ability?.effect || '').match(/^Level (\d+)\.?$/i);
  if (level || /^Level up\b/i.test(String(ability?.text || ''))) {
    if (level && Number(instance?.classLevel || 1) !== Number(level[1]) - 1) reasons.push(`Gain level ${Number(level[1]) - 1} first.`);
    const sorcery = game && game.activePlayerId === player?.playerId && ['precombat-main', 'postcombat-main'].includes(game.phase) && !(game.stack || []).length;
    if (game && !sorcery) reasons.push('Only as a sorcery: your main phase, with an empty stack.');
  }
  if (ability?.energyCost && player && Number(player.counters?.energy || 0) < Number(ability.energyCost))
    reasons.push('Not enough Energy to pay this activation cost.');
  if (Number(ability?.loyaltyDelta) < 0 && Number(instance?.counters?.loyalty || 0) < Math.abs(Number(ability.loyaltyDelta)))
    reasons.push('Not enough loyalty to pay this activation cost.');
  if (ability?.discards && player && (player.deck?.hand?.length || 0) < Math.max(1, ability.discardCount || 1))
    reasons.push('Not enough cards in hand to pay this activation cost.');
  if (ability?.sacrificeMany && player) {
    const have = (player.deck?.battlefield || []).filter(c => c.instanceId !== instance?.instanceId && new RegExp(`\\b${ability.sacrificeMany.word}s?\\b`, 'i').test(((d => `${d?.typeLine || ''} ${d?.name || ''}`)(definitions instanceof Map ? definitions.get(c.definitionId) : definitions?.[c.definitionId])))).length;
    if (have < ability.sacrificeMany.n) reasons.push(`You need ${ability.sacrificeMany.n} ${ability.sacrificeMany.word}s to sacrifice.`);
  }
  if (ability?.sacrificeRequirement && player && !ability?.sacrificesSelf) {
    const need = String(ability.sacrificeRequirement);
    const candidates = (player.deck?.battlefield || []).filter(c => c.instanceId !== instance?.instanceId && new RegExp(`\\b(?:${need.replace(/ or /g, '|')})\\b`, 'i').test((definitions instanceof Map ? definitions.get(c.definitionId) : definitions?.[c.definitionId])?.typeLine || ''));
    if (!candidates.length)
      reasons.push(`No legal ${need.toLowerCase()} is available to sacrifice.`);
  }
  if (ability?.needsTarget) {
    // A modal ability ("Choose one — • Destroy target artifact. • Proliferate."): one usable mode is enough.
    const hasTarget = effect => {
    let targetFound = !/\btarget\b/i.test(effect);
    if (/target (?:player|opponent)/i.test(effect))
      targetFound = (game?.players || []).some(q => !/opponent/i.test(effect) || q.playerId !== player?.playerId);
    // "any target" can always be a player (Prodigal Pyromancer); other wordings the checks below don't know are allowed
    // here and checked when the targets are chosen.
    if (/\bany (?:other )?target\b/i.test(effect) || !/target (?:player|opponent|creature|permanent|artifact|enchantment|planeswalker|land|card)/i.test(effect))
      targetFound = true;
    if (/target (?:creature|permanent|artifact|enchantment|planeswalker|land)/i.test(effect)) {
      const players = /you control/i.test(effect.replace(/\bfor as long as\b.*$/i, '').replace(/\bwith (?:mana value|power|toughness) (?:less|greater) than.*$/i, '')) ? [player] : (game?.players || []);
      for (const q of players.filter(Boolean))
        for (const c of q.deck?.battlefield || []) {
          const d = definitions instanceof Map ? definitions.get(c.definitionId) : definitions?.[c.definitionId];
          const t = d?.typeLine || '';
          if (/target creature/i.test(effect) && !/Creature/i.test(t))
            continue;
          if (/target artifact/i.test(effect) && !/Artifact/i.test(t))
            continue;
          if (/target enchantment/i.test(effect) && !/Enchantment/i.test(t))
            continue;
          if (/target planeswalker/i.test(effect) && !/Planeswalker/i.test(t))
            continue;
          if (/target land/i.test(effect) && !/Land/i.test(t))
            continue;
          if (/with a counter on it/i.test(effect) && !Object.values(c.counters || {}).some(v => Number(v) > 0))
            continue;
          targetFound = true;
          break;
        }
    }
    if (/target card in (?:a|your) graveyard/i.test(effect)) {
      const players = /your graveyard/i.test(effect) ? [player] : (game?.players || []);
      targetFound = players.filter(Boolean).some(q => (q.deck?.graveyard || []).length > 0);
    }
    // "target card exiled with this artifact": needs a card this permanent still holds in exile (607.2a).
    if (/target (?:[a-z ]+? )?card (?:you own )?(?:with mana value \w+ )?exiled with\b/i.test(effect))
      targetFound = (instance?.linkedExile || []).some(id => (game?.players || []).some(q => (q.deck?.exile || []).some(x => x.instanceId === id && x.exiledBy === instance.instanceId)));
    return targetFound;
    };
    const targetFound = (ability.modes?.length ? ability.modes : [String(ability.effect || '')]).some(hasTarget);
    if (!targetFound)
      reasons.push('No legal target is currently available for this ability.');
  }
  return { legal: reasons.length === 0, reasons: [...new Set(reasons)] };
}
export function availableActivatedAbilities({ game, instance, definition }) {
  return parseActivatedAbilities(definition).map(ability => ({ ability, ...validateActivatedAbility({ game, instance, definition, ability }) }));
}
export function canActivateTapAbility({ game, instance, definition }) {
  const rows = availableActivatedAbilities({ game, instance, definition }).filter(x => x.ability.requiresTap);
  if (!rows.length)
    return { legal: false, reasons: ['No activated ability with {T} in its cost was found.'] };
  const legal = rows.find(x => x.legal);
  return legal ? { legal: true, reasons: [] } : { legal: false, reasons: [...new Set(rows.flatMap(x => x.reasons))] };
}
export function entersBattlefieldTapped({ definition, battlefield = [], definitions = {} } = {}) {
  const text = String(definition?.oracleText || '');
  if (!/enters(?: the battlefield)? tapped/i.test(text))
    return false;
  const getDef = c => definitions instanceof Map ? definitions.get(c.definitionId) : definitions?.[c.definitionId];
  const fewer = text.match(/enters(?: the battlefield)? tapped unless you control (\d+|one|two|three|four|five|six|seven|eight|nine|ten) or fewer other lands/i);
  if (fewer) {
    const words = { one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10 };
    const max = Number(fewer[1]) || words[String(fewer[1]).toLowerCase()] || 0;
    const otherLands = (battlefield || []).filter(c => /\bLand\b/i.test(String(getDef(c)?.typeLine || ''))).length;
    return otherLands > max;
  }
  // Count-based tracked-state clauses, e.g. "unless you control two or more basic lands."
  const count = text.match(/enters(?: the battlefield)? tapped unless you control (\d+|one|two|three|four|five|six|seven|eight|nine|ten) or more ([^.]+?)(?: cards?| permanents?| lands?)?\./i);
  if (count) {
    const words = { one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10 };
    const need = Number(count[1]) || words[String(count[1]).toLowerCase()] || 0;
    const phrase = String(count[2] || '').trim();
    const matches = c => { const d = getDef(c), type = String(d?.typeLine || ''); if (/basic land/i.test(phrase))
      return /\bBasic\b/i.test(type) && /\bLand\b/i.test(type); if (/land/i.test(phrase))
      return /\bLand\b/i.test(type); if (/artifact/i.test(phrase))
      return /\bArtifact\b/i.test(type); if (/creature/i.test(phrase))
      return /\bCreature\b/i.test(type); return new RegExp(`\\b${phrase.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\$&')}\\b`, 'i').test(type); };
    return battlefield.filter(matches).length < need;
  }
  // Common "unless you control a TYPE" land clause. If the condition can be proven true, it enters untapped.
  const m = text.match(/enters(?: the battlefield)? tapped unless you control (?:a|an) ([A-Za-z]+)(?: or (?:a|an) ([A-Za-z]+))?/i);
  if (m) {
    const types = [m[1], m[2]].filter(Boolean);
    const has = battlefield.some(c => { const d = getDef(c); return types.some(t => new RegExp(`\\b${t}\\b`, 'i').test(d?.typeLine || '')); });
    return !has;
  }
  if (/enters(?: the battlefield)? tapped unless/i.test(text))
    return true;
  return true;
}
/**
 * Who goads this creature: goad on the creature itself, plus game-wide goads ("creatures your opponents control attack each
 * combat if able …", Kardur) from a player other than its controller. A game-wide goad also covers creatures that player's
 * opponents get later (it is a rule about attacking, not a change to the creatures; rule 611.2c).
 */
export function goadersOf(game, card, controllerId) {
  const by = new Set((card?.temporaryEffects || []).filter(e => e?.kind === 'goad').map(e => e.by));
  if (/Creature/i.test(game?.cardDefinitions?.[card?.definitionId]?.typeLine || ''))
    for (const g of game?.goadEach || []) if (g.by !== controllerId) by.add(g.by);
  return by;
}
export function validateRequiredAttackers({ game, player, draft = [] } = {}) {
  const reasons = [];
  if (!game || !player)
    return { legal: true, reasons };
  const chosen = new Set((draft || []).map(x => x.instanceId));
  const opponents = (game.players || []).filter(p => p.playerId !== player.playerId && !p.eliminated);
  for (const c of player.deck?.battlefield || []) {
    const goaded = goadersOf(game, c, player.playerId).size > 0;
    if (!combatRestriction(c, 'must-attack') && !goaded)
      continue;
    const d = game.cardDefinitions?.[c.definitionId];
    const able = opponents.some(o => validateAttack({ game: { ...game, phase: 'declare-attackers' }, attackerId: player.playerId, defenderId: o.playerId, instance: c, definition: d }).legal);
    if (able && !chosen.has(c.instanceId))
      reasons.push(`${d?.name || 'A creature'} ${goaded ? 'is goaded and ' : ''}must attack this combat if able.`);
    // "attacks that opponent this turn if able" (Encore): that player, when it can attack them.
    const must = (c.temporaryEffects || []).find(e => e?.kind === 'combat-restriction' && e.restriction === 'must-attack' && e.playerId);
    const pick = (draft || []).find(x => x.instanceId === c.instanceId);
    if (must && pick && pick.defenderId !== must.playerId && opponents.some(o => o.playerId === must.playerId && validateAttack({ game: { ...game, phase: 'declare-attackers' }, attackerId: player.playerId, defenderId: o.playerId, instance: c, definition: d }).legal))
      reasons.push(`${d?.name || 'A creature'} must attack ${opponents.find(o => o.playerId === must.playerId)?.displayName || 'that player'} this turn if able.`);
  }
  return { legal: reasons.length === 0, reasons };
}
// "This creature can block an additional creature this turn." (build 102): temporary extra blocks on the card.
export function blockerCapacity(definition, card = null) { return blockerCapacityPrinted(definition) + (card?.temporaryEffects || []).filter(e => e?.kind === 'extra-blocks').reduce((n, e) => n + Number(e.amount || 0), 0); }
function blockerCapacityPrinted(definition) { const text = String(definition?.oracleText || ''); if (/\bcan block any number of creatures\b/i.test(text)) return 99; const m = text.match(/can block an additional (\d+|one|two|three|four|five) creatures?/i); if (!m)
  return 1; const words = { one: 1, two: 2, three: 3, four: 4, five: 5 }; return 1 + (Number(m[1]) || words[m[1].toLowerCase()] || 0); }
export function attackerMinimumBlockers(definition, instance = null) { return instanceKeyword(instance, definition, 'Menace') ? 2 : 1; }

import { manaExtras } from './mana-extras.js';
import { withOverlay } from './overlay.js';
import { evaluateLosses, basicLandManaColor, tapManaAbilities, effectiveManaOptionsForSource } from './rules.js';
import { sync } from './deck.js';
import { advanceTurn, configurePhaseGates, cleanupEndCombatEffects } from './phase.js';
import { effectivePower, effectiveToughness } from './combat.js';
import { applyEffects as applyGenericEffects, locateCardInGame, definitionFor, moveCard, snapshotGame, restoreGameSnapshot, clearCastState, refreshMutated } from './effects.js';
import { queueTriggers } from './triggers.js';
import { FACE_DOWN_ID, faceDownDefinition } from './face-down.js';
import { castPreparedCopy } from '../game/prepare.js';
import { graveyardDestination } from './replacements.js';
const ZONES = ['remainingLibrary', 'hand', 'battlefield', 'graveyard', 'exile', 'tokens', 'attachments', 'commandZone'];
function locate(deck, id) { for (const z of ZONES) {
  const a = deck[z] || [];
  const i = a.findIndex(c => c.instanceId === id);
  if (i >= 0)
    return { z, a, i, card: a[i] };
} return null; }
function zoneKey(zone) { return zone === 'library' ? 'remainingLibrary' : zone === 'command' ? 'commandZone' : zone; }
function defFor(game, card) { return withOverlay(card, plainDefFor(game, card)); }
function plainDefFor(game, card) { if (!card)
  return null; const base = game.cardDefinitions?.[card.definitionId] || null, i = Number.isInteger(card?.activeFaceIndex) ? card.activeFaceIndex : null, face = i === null ? null : base?.cardFaces?.[i]; return face ? { ...base, ...face, definitionId: base.definitionId, colorIdentity: base.colorIdentity, cardFaces: base.cardFaces, set: base.set, collectorNumber: base.collectorNumber, printing: base.printing, legalities: base.legalities, hydrationStatus: base.hydrationStatus } : base; }
function shuffleArray(a) { for (let i = a.length - 1; i > 0; i--) {
  const j = Math.floor(Math.random() * (i + 1));
  [a[i], a[j]] = [a[j], a[i]];
} return a; }
function commanderIdentity(game, player) { const out = new Set(); for (const cmd of player?.commanders || []) {
  for (const c of game?.cardDefinitions?.[cmd.cardId]?.colorIdentity || [])
    if (['W', 'U', 'B', 'R', 'G'].includes(c))
      out.add(c);
} return out; }
function manaAbilityAmount(row) { const effect = String(row?.ability?.effect || row?.text || ''); const symbols = [...effect.matchAll(/\{([WUBRGC])\}/g)].map(x => x[1]); if (symbols.length) {
  if (/\bor\b/i.test(effect))
    return 1;
  return Math.max(1, symbols.length);
} const m = effect.match(/Add (one|two|three|four|five|\d+) mana/i), words = { one: 1, two: 2, three: 3, four: 4, five: 5 }; return Math.max(1, Number(m?.[1]) || words[String(m?.[1] || '').toLowerCase()] || 1); }
function inferredManaCapacitySpec(game, player, card) {
  if (!card)
    return null;
  const def = defFor(game, card), basic = (String(def?.typeLine || '').match(/Plains|Island|Swamp|Mountain|Forest/g) || []).length > 1 ? null : basicLandManaColor(def);   // a land with two basic land types (Urborg) makes either colour: read from its text
  if (basic)
    return { options: [basic], amount: 1 };
  const abilities = tapManaAbilities(def).filter(row => String(row?.ability?.cost || '').replace(/\s+/g, '') === '{T}');
  if (!abilities.length)
    return null;
  let options = effectiveManaOptionsForSource({ game, player, card, definition: def });
  if (!options.length && ['W', 'U', 'B', 'R', 'G', 'C'].includes(card.chosenColor))
    options = [card.chosenColor];
  if (!options.length)
    return null;
  const amount = Math.max(1, ...abilities.map(manaAbilityAmount));
  return { options, amount: options.length > 1 ? 1 : amount };
}
function manaSourceUsable(game, card) {
  const def = defFor(game, card);
  if (!/Creature/i.test(String(def?.typeLine || '')))
    return true;
  const haste = (def?.keywords || []).some(k => String(k).toLowerCase() === 'haste') || /\bHaste\b/i.test(String(def?.oracleText || '')) || (card?.temporaryEffects || []).some(e => e?.kind === 'keyword' && e?.enabled !== false && String(e.keyword || '').toLowerCase() === 'haste');
  if (haste)
    return true;
  const since = Number(card?.controlSinceTurn ?? card?.enteredTurn ?? -1);
  return since < Number(game?.turnNumber || 0);
}
function registerManaSource(game, player, card) {
  if (!player || !card || card.manaCapacityRegistered)
    return;
  const saved = Array.isArray(card.manaCapacityOptions) && card.manaCapacityOptions.length ? { options: card.manaCapacityOptions, amount: Math.max(1, Number(card.manaCapacityAmount || 1)) } : null, spec = saved || inferredManaCapacitySpec(game, player, card);
  if (!spec?.options?.length)
    return;
  card.manaCapacityOptions = [...new Set(spec.options)];
  card.manaCapacityAmount = Math.max(1, Number(spec.amount || 1));
  card.manaCapacityRegistered = true;
  if (card.manaCapacityOptions.length === 1) {
    const color = card.manaCapacityOptions[0], amount = card.manaCapacityAmount;
    card.manaCapacityColor = color;
    player.mana.total[color] = Number(player.mana.total[color] || 0) + amount;
    if (!card.tapped && manaSourceUsable(game, card))
      player.mana.available[color] = Number(player.mana.available[color] || 0) + amount;
  }
  else
    card.manaCapacityColor = null;
}
/** A permanent that became a copy (Thespian's Stage) or stopped being one makes the copied card's mana: register it again. */
export function refreshManaSource(game, player, card) {
  if (!player || !card) return;
  unregisterManaSource(player, card);
  delete card.manaCapacityOptions; delete card.manaCapacityAmount; delete card.manaCapacityColor; card.manaCapacityRegistered = false;
  registerManaSource(game, player, card);
}
/** A land whose land types changed (or changed back): register the mana it makes now, if that differs from what is registered. */
export function resyncManaSource(game, player, card) {
  if (!player || !card || !/\bLand\b/.test(defFor(game, card)?.typeLine || '')) return;
  const spec = inferredManaCapacitySpec(game, player, card), had = card.manaCapacityRegistered ? [...(card.manaCapacityOptions || [])].sort().join('') : '', want = spec?.options?.length ? [...new Set(spec.options)].sort().join('') : '';
  if (had !== want) refreshManaSource(game, player, card);
}
function unregisterManaSource(player, card, { wasTapped = null } = {}) {
  if (!player || !card || !card.manaCapacityRegistered)
    return;
  const options = Array.isArray(card.manaCapacityOptions) ? card.manaCapacityOptions : (card.manaCapacityColor ? [card.manaCapacityColor] : []), tapped = wasTapped === null ? !!card.tapped : !!wasTapped, amount = Math.max(1, Number(card.manaCapacityAmount || 1));
  if (options.length === 1) {
    const color = options[0];
    player.mana.total[color] = Math.max(0, Number(player.mana.total[color] || 0) - amount);
    if (!tapped)
      player.mana.available[color] = Math.max(0, Number(player.mana.available[color] || 0) - amount);
  }
  card.manaCapacityRegistered = false;
  card.manaCapacityColor = null;
  card.manaCapacityOptions = [];
  card.manaCapacityAmount = 1;
}
function emit(game, event) {
  if (event?.type === 'dies') game.creatureDiedTurn = Number(game.turnNumber || 0);   // morbid
  if (event?.type === 'dies' && /\bCreature\b/i.test(event.typeLine || '')) game.creaturesDied = { turn: Number(game.turnNumber || 0), n: (game.creaturesDied?.turn === Number(game.turnNumber || 0) ? game.creaturesDied.n : 0) + 1 };   // "for each creature that died this turn" (build 77)
  if (event?.type === 'tapped') {
    const hit = locateCardInGame(game, event.sourceId);
    if (hit?.card) {
      const key = `tap:${Number(game.turnNumber || 0)}`;
      hit.card.turnEventCounts = hit.card.turnEventCounts || {};
      hit.card.turnEventCounts[key] = Number(hit.card.turnEventCounts[key] || 0) + 1;
      event.tapNumberThisTurn = hit.card.turnEventCounts[key];
      event.typeLine = event.typeLine || defFor(game, hit.card)?.typeLine || '';
    }
  }
  if (event?.type === 'enters-battlefield') {
    const hit = locateCardInGame(game, event.sourceId);
    const player = game.players.find(p => p.playerId === (event.controllerId || hit?.card?.controllerId));
    if (hit?.zone === 'battlefield')
      registerManaSource(game, player, hit.card);
  }
  else if (event?.type === 'leaves-battlefield') {
    const hit = locateCardInGame(game, event.sourceId);
    const player = game.players.find(p => p.playerId === event.controllerId);
    if (hit?.card)
      unregisterManaSource(player, hit.card, { wasTapped: event.wasTapped });
  }
  return queueTriggers(game, event);
}
/** Leaving the battlefield: remember counters for "dies" abilities, then reset the card. */
function leaveBattlefield(card, to = 'graveyard') {
  delete card.temporaryGrants;
  const last = { counters: { ...(card.counters || {}) }, castMode: card.castMode || null, damage: Number(card.damageMarked || 0) };
  card.damageMarked = 0;
  card.deathtouchDamage = false;
  card.counters = {};
  card.temporaryEffects = [];
  delete card.attacking;
  delete card.blocking;
  delete card.unlockedFaces;   // Room doors lock again
  clearCastState(card, to);
  return last;
}
/** What kind of source made a mana ("mana from a Treasure was spent"): the subtypes after the dash of its type line (Treasure, Food, Clue …). */
function sourceTag(game, card) { const d = defFor(game, card), t = `${String(d?.typeLine || '').split('—')[1] || ''} ${/^(?:Treasure|Food|Clue|Blood|Gold|Powerstone)$/.test(d?.name || '') ? d.name : ''}`; return t.trim() ? t.trim().split(/\s+/).filter(x => /^(?:Treasure|Food|Clue|Blood|Gold|Powerstone)$/.test(x)).join(' ') || null : null; }
function payMana(game, player, payment) {
  player.mana.spentTags = [];
  if (!payment)
    return;
  const lifePayment = Math.max(0, Number(payment.__lifePayment || 0));
  if (lifePayment && Number(player.life || 0) < lifePayment)
    throw new Error('Not enough life to pay this Phyrexian mana cost');
  const assignments = Array.isArray(payment.__sourceAssignments) ? payment.__sourceAssignments : [];
  // Expend: the total mana this player spent this turn; "whenever you expend 4" fires as the total reaches 4.
  const spentNow = Object.entries(payment).filter(([k]) => !k.startsWith('__')).reduce((n, [, v]) => n + Math.max(0, Number(v || 0)), 0);
  if (spentNow) {
    const before = player.manaSpent?.turn === game.turnNumber ? Number(player.manaSpent.n || 0) : 0;
    player.manaSpent = { turn: game.turnNumber, n: before + spentNow };
    for (let k = before + 1; k <= before + spentNow; k++) emit(game, { type: 'expend', playerId: player.playerId, controllerId: player.playerId, amount: k });
  }
  // Extra mana of any colour (Fertile Ground) the plan already spent, by source (ids are `extra:<source id>:<n>`).
  const extraParent = id => String(id).slice(6).replace(/:\d+$/, '');
  const anyAssigned = {};
  for (const a of assignments) if (a.zone === 'extra') { const id = extraParent(a.instanceId); anyAssigned[id] = (anyAssigned[id] || 0) + 1; }
  const optsOf = c => Array.isArray(c.manaCapacityOptions) && c.manaCapacityOptions.length ? c.manaCapacityOptions : (c.manaCapacityColor ? [c.manaCapacityColor] : []);
  const singles = () => (player.deck?.battlefield || []).filter(c => !c.tapped && manaSourceUsable(game, c) && c.manaCapacityRegistered && optsOf(c).length === 1);
  const tapEvent = (card, color) => emit(game, { type: 'tapped-for-mana', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: player.playerId, playerId: player.playerId, color, land: /\bLand\b/.test(defFor(game, card)?.typeLine || ''), creature: /\bCreature\b/.test(defFor(game, card)?.typeLine || ''), typeLine: defFor(game, card)?.typeLine || '' });
  // Tap a registered source: its capacity becomes real mana in the pool, with every extra (Mana Reflection, Wild Growth, Utopia Sprawl, Fertile Ground).
  const tapSource = (src, color, capacity = true) => {
    src.tapped = true;
    tapEvent(src, color);
    const b = Math.max(1, Number(src.manaCapacityAmount || 1)), ex = manaExtras(game, src, color, b);
    if (capacity) player.mana.available[color] = Math.max(0, Number(player.mana.available[color] || 0) - b);
    addMana(player, color, ex.amount);
    for (const c of ex.fixed) addMana(player, c, 1);
    // Any-colour extra the plan did not spend: kept as the source's own colour.
    const spare = Math.max(0, ex.any - (anyAssigned[src.instanceId] || 0));
    if (spare) addMana(player, color, spare);
  };
  const spend = (color, n) => { player.mana.floating[color] = Math.max(0, Number(player.mana.floating[color] || 0) - n); player.mana.available[color] = Math.max(0, Number(player.mana.available[color] || 0) - n); };
  // Mana from a tagged source (a sacrificed Treasure) is spent first, and the tag goes with the spell ("if mana from a Treasure was spent to cast it").
  const fromPool = (color, need) => {
    const use = Math.min(need, Math.max(0, Number(player.mana.floating?.[color] || 0)));
    if (use) {
      spend(color, use);
      for (let k = 0, left = use; k < (player.mana.tags || []).length && left > 0; ) { const t = player.mana.tags[k]; if (t.color === color) { player.mana.spentTags.push(t.tag); player.mana.tags.splice(k, 1); left--; } else k++; }
    }
    return need - use;
  };
  player.mana.floating = player.mana.floating || { W: 0, U: 0, B: 0, R: 0, G: 0, C: 0 };
  for (const [color, raw] of Object.entries(payment)) {
    if (color.startsWith('__'))
      continue;
    const amount = Math.max(0, Number(raw || 0));
    if (!amount)
      continue;
    let need = fromPool(color, amount);
    const own = singles().filter(c => optsOf(c)[0] === color).sort((a, b) => Number(b.manaCapacityAmount || 1) - Number(a.manaCapacityAmount || 1));
    for (const src of own) {
      if (need <= 0) break;
      tapSource(src, color);
      need = fromPool(color, need);
    }
    // A source whose extra mana is this colour (an Island with Wild Growth paying {G}).
    for (const src of singles()) {
      if (need <= 0) break;
      const main = optsOf(src)[0];
      if (!manaExtras(game, src, main, Math.max(1, Number(src.manaCapacityAmount || 1))).fixed.includes(color)) continue;
      tapSource(src, main);
      need = fromPool(color, need);
    }
    if (need > 0)
      player.mana.available[color] = Math.max(0, Number(player.mana.available[color] || 0) - need);
  }
  for (const a of assignments) {
    if (a.zone === 'extra') {
      // Fertile Ground's any-colour mana: it comes from tapping the land it enchants.
      const parent = (player.deck?.battlefield || []).find(c => c.instanceId === extraParent(a.instanceId));
      if (parent && !parent.tapped) { const main = optsOf(parent)[0]; if (main) tapSource(parent, main); }
      continue;
    }
    if (a.zoneManaAbility || a.zone === 'hand') {
      const hit = locate(player.deck, a.instanceId);
      if (!hit || hit.z !== 'hand')
        throw new Error('Chosen hand mana source is no longer available');
      const [card] = hit.a.splice(hit.i, 1);
      card.zone = 'exile';
      card.tapped = false;
      player.deck.exile.push(card);
      continue;
    }
    const card = (player.deck?.battlefield || []).find(c => c.instanceId === a.instanceId);
    if (card && !card.tapped) {
      card.tapped = true;
      tapEvent(card, a.color || null);
      // Fixed extra mana on a flexible source (Wild Growth on a dual land) goes to the pool.
      if (a.color) { const ex = manaExtras(game, card, a.color, 1); if (ex.amount > 1) addMana(player, a.color, ex.amount - 1); for (const c of ex.fixed) addMana(player, c, 1); }
    }
  }
  if (lifePayment) {
    player.life = Math.max(0, Number(player.life || 0) - lifePayment);
    emit(game, { type: 'life-lost', playerId: player.playerId, amount: lifePayment, controllerId: player.playerId, phyrexianPayment: true });
  }
}
function addMana(player, color, amount = 1, tag = null) { const n = Number(amount || 0); if (tag && n > 0) { player.mana.tags = player.mana.tags || []; for (let k = 0; k < n; k++) player.mana.tags.push({ color, tag }); } player.mana.available[color] = Number(player.mana.available[color] || 0) + n; player.mana.floating = player.mana.floating || { W: 0, U: 0, B: 0, R: 0, G: 0, C: 0 }; player.mana.floating[color] = Number(player.mana.floating[color] || 0) + n; }
function setTappedWithCapacity(game, player, card, nextTapped) { const next = !!nextTapped, prev = !!card.tapped; if (prev === next) {
  card.tapped = next;
  return;
} const opts = Array.isArray(card.manaCapacityOptions) ? card.manaCapacityOptions : (card.manaCapacityColor ? [card.manaCapacityColor] : []); if (opts.length === 1 && manaSourceUsable(game, card)) {
  const mc = opts[0], amount = Math.max(1, Number(card.manaCapacityAmount || 1)), delta = (next ? -1 : 1) * amount;
  player.mana.available[mc] = Math.max(0, Number(player.mana.available[mc] || 0) + delta);
} card.tapped = next; }
function removeFromZone(deck, id, allowed = null) { const hit = locate(deck, id); if (!hit)
  throw new Error('Card instance not found'); if (allowed && !allowed.includes(hit.z))
  throw new Error('Card is not in a legal source zone'); const [card] = hit.a.splice(hit.i, 1); return { card, from: hit.z }; }
function ownerFor(game, card, fallback) { return game.players.find(p => p.playerId === card?.ownerId) || fallback; }
function insertOwnedZone(game, card, to, fallback, { position = 'bottom' } = {}) { const owner = ownerFor(game, card, fallback); const target = owner?.deck?.[zoneKey(to)]; if (!target)
  throw new Error('Invalid target zone'); card.zone = to; card.controllerId = to === 'battlefield' ? (card.controllerId || fallback?.playerId) : owner.playerId; if (to === 'library' && position === 'top')
  target.unshift(card);
else
  target.push(card); return owner; }
function applyTrackedEffects(game, player, effects = [], bindings = {}) {
  const notes = [];
  // One bindings object for the whole package so a later effect can read what an earlier one recorded.
  // resolutionId: events from one resolution, for "one or more … leave your graveyard" (one trigger per batch).
  const resolutionId = `res:${Date.now()}:${Math.random()}`;
  const shared = { ...bindings, onEvent: e => emit(game, { ...e, resolutionId }) };
  for (const effect of effects || []) {
    // Legacy Special Move payload remains supported.
    if (effect.kind === 'damage-from-creature') {
      const sourceId = effect.sourceId;
      const src = locateCardInGame(game, sourceId);
      if (!src || src.zone !== 'battlefield') {
        notes.push('The chosen source creature was no longer on the battlefield.');
        continue;
      }
      const sd = definitionFor(game, src.card), amount = effectivePower(src.card, sd, game);
      const mapped = { kind: 'damage-from-selected-creature', sourceId, targetId: effect.targetId, targetBind: null, amount, sourceBind: null, sacrificeSource: !!effect.sacrificeSource };
      notes.push(...applyGenericEffects(game, player.playerId, [mapped], { ...bindings, sourceId, onEvent: e => emit(game, e) }));
      continue;
    }
    notes.push(...applyGenericEffects(game, player.playerId, [effect], shared));
  }
  return notes;
}
function putSpellOnStack(game, player, action, deck) {
  const allowed = Array.isArray(action.fromZones) && action.fromZones.length ? action.fromZones : ['hand', 'commandZone'];
  const { card, from } = removeFromZone(deck, action.instanceId, allowed);
  delete card.gySeen;
  if (from === 'graveyard') game.leftGraveyard = { ...(game.leftGraveyard || {}), [player.playerId]: game.turnNumber };
  payMana(game, player, action.payment);
  if (Number.isInteger(action.activeFaceIndex))
    card.activeFaceIndex = action.activeFaceIndex;
  // Delve and escape exile graveyard cards as part of the cost.
  for (const id of action.exileFromGraveyard || []) {
    const i = deck.graveyard.findIndex(c => c.instanceId === id);
    if (i < 0)
      throw new Error('A graveyard card chosen to pay the cost is gone.');
    const [gone] = deck.graveyard.splice(i, 1);
    game.leftGraveyard = { ...(game.leftGraveyard || {}), [player.playerId]: game.turnNumber };
    gone.zone = 'exile';
    deck.exile.push(gone);
  }
  // "As an additional cost to cast this spell, sacrifice … / pay X life."
  if (action.sacrificeForCost) {
    const mv = locate(deck, action.sacrificeForCost);
    if (!mv || mv.z !== 'battlefield')
      throw new Error('The permanent chosen to sacrifice is gone.');
    const def = defFor(game, mv.card), fromController = mv.card.controllerId || player.playerId, wasTapped = !!mv.card.tapped;
    const [paid] = mv.a.splice(mv.i, 1);
    const last = leaveBattlefield(paid);
    paid.zone = 'graveyard';
    paid.tapped = false;
    const owner = ownerFor(game, paid, player);
    if (!paid.token)
      owner.deck.graveyard.push(paid);
    emit(game, { type: 'sacrificed', sourceId: paid.instanceId, definitionId: paid.definitionId, controllerId: fromController, ownerId: paid.ownerId, typeLine: def?.typeLine || '', token: !!paid.token, cost: true });
    emit(game, { type: 'leaves-battlefield', sourceId: paid.instanceId, definitionId: paid.definitionId, controllerId: fromController, ownerId: paid.ownerId, destination: 'graveyard', typeLine: def?.typeLine || '', wasTapped });
    if (/Creature/i.test(def?.typeLine || ''))
      emit(game, { type: 'dies', sourceId: paid.instanceId, definitionId: paid.definitionId, controllerId: fromController, ownerId: paid.ownerId, typeLine: def?.typeLine || '', token: !!paid.token, last });
  }
  if (action.exileFromHandForCost) {
    const i = deck.hand.findIndex(c => c.instanceId === action.exileFromHandForCost);
    if (i < 0)
      throw new Error('The card chosen to exile is gone.');
    const [gone] = deck.hand.splice(i, 1);
    gone.zone = 'exile';
    deck.exile.push(gone);
  }
  if (action.lifeForCost) {
    if (player.life < action.lifeForCost)
      throw new Error('Not enough life to pay this cost.');
    player.life -= action.lifeForCost;
    emit(game, { type: 'life-lost', playerId: player.playerId, amount: action.lifeForCost, controllerId: player.playerId, sourceId: card.instanceId });
  }
  if (action.discardForCost) {
    const i = deck.hand.findIndex(c => c.instanceId === action.discardForCost);
    if (i < 0)
      throw new Error('The card chosen to discard is gone.');
    const [gone] = deck.hand.splice(i, 1);
    const to = graveyardDestination(game, gone);
    gone.zone = to;
    deck[to].push(gone);
    emit(game, { type: 'discard', playerId: player.playerId, sourceId: gone.instanceId, definitionId: gone.definitionId, cost: true });
  }
  // Alternative costs of the "rather than pay this spell's mana cost" family (game/alt-costs.js).
  for (const o of action.altPayOps || []) {
    if (o.op === 'gain-life') { const q = game.players.find(x => x.playerId === o.playerId); if (q) { q.life += Number(o.amount || 0); emit(game, { type: 'life-gained', playerId: q.playerId, amount: Number(o.amount || 0), controllerId: q.playerId, sourceId: card.instanceId }); } continue; }
    const at = locate(deck, o.id);
    if (!at) throw new Error('A card chosen to pay the cost is gone.');
    if (o.op === 'tap') { if (at.z !== 'battlefield' || at.card.tapped) throw new Error('The creature chosen to tap is gone.'); at.card.tapped = true; continue; }
    if (o.op === 'discard') { const to = graveyardDestination(game, at.card); const [gone] = at.a.splice(at.i, 1); gone.zone = to; deck[to].push(gone); emit(game, { type: 'discard', playerId: player.playerId, sourceId: gone.instanceId, definitionId: gone.definitionId, cost: true }); continue; }
    if (o.op === 'exile-gy') game.leftGraveyard = { ...(game.leftGraveyard || {}), [player.playerId]: game.turnNumber };
    moveCard(game, o.id, o.op === 'return' ? 'hand' : o.op === 'sacrifice' ? 'graveyard' : 'exile', { onEvent: e => emit(game, { ...e, cost: true }), ...(o.op === 'sacrifice' ? { moveReason: 'sacrifice' } : {}) });
  }
  delete card.onAdventure;
  delete card.foretold;
  delete card.foretoldTurn;
  if (action.castMode && action.castMode !== 'normal')
    card.castMode = action.castMode;
  delete card.plotted; delete card.plottedTurn; delete card.suspended; delete card.graveyardCastPermission;   // leaving exile/graveyard ends plot, suspend, permissions
  if (card.preparedOf) castPreparedCopy(game, card);   // Prepared: casting the copy unprepares the creature
  card.wasCast = true;   // "if you cast it" (The One Ring); forgotten when it changes zones again
  card.castFromZone = action.fromZone || 'hand';   // Fblthp, the Lost: "was cast from your library"
  if (action.kicked) {
    card.kicked = true;
    card.kickCount = Number(action.kickCount || 1);
  }
  // Offspring / squad (token copies as it enters) and bargain ("if it was bargained").
  if (action.offspring) card.offspring = true;
  if (action.squadCount) card.squadCount = Number(action.squadCount);
  if (action.bargained) card.bargained = true;
  if (action.disturbed) card.disturbed = true;
  if (action.prototype) card.prototype = action.prototype;
  if (action.bestowed) card.bestowed = true;   // an Aura while it enchants a creature   // "If it would be put into a graveyard from anywhere, exile it instead."
  if (action.faceDown) {
    game.cardDefinitions[FACE_DOWN_ID] = game.cardDefinitions[FACE_DOWN_ID] || faceDownDefinition();
    card.realDefinitionId = card.definitionId;
    card.definitionId = FACE_DOWN_ID;
    card.faceDownKind = action.faceDown;
    card.castFlags = { turnUpCost: action.turnUpCost || null, megamorph: !!action.megamorph };
    card.activeFaceIndex = null;
  }
  card.zone = 'stack';
  game.stack = game.stack || [];
  const spellDef = defFor(game, card), defaultTo = /Instant|Sorcery/i.test(spellDef?.typeLine || '') ? 'graveyard' : 'battlefield';
  const stackObject = {
    id: action.stackId || `stack:${Date.now()}:${Math.random()}`, kind: 'spell', controllerId: player.playerId, ownerId: card.ownerId, card, sourceDefinitionId: card.definitionId,
    fromZone: from, to: action.to || defaultTo, effects: structuredClone(action.effects || []), effectBindings: structuredClone(action.effectBindings || {}), searchResult: structuredClone(action.searchResult || null),
    asEntersChoices: structuredClone(action.asEntersChoices || null), manaCapacityColor: action.manaCapacityColor || null, label: action.label || `Cast ${defFor(game, card)?.name || 'spell'}`,
    commanderId: action.commanderId || null, guidedResolution: structuredClone(action.guidedResolution || null), createdAt: new Date().toISOString(),
    castMode: action.castMode || 'normal', exileOnLeave: !!action.exileOnLeave, adventure: !!action.adventure, kicked: !!action.kicked, kickCount: Number(action.kickCount || 0)
  };
  if (card.castCopy) stackObject.isCopy = true;
  // Conduit of Worlds: after that spell, no more spells this turn.
  if (player.lockAfterNextCast) { delete player.lockAfterNextCast; game.castLocks = [...(game.castLocks || []).filter(x => x.turn === game.turnNumber), { turn: game.turnNumber, playerIds: [player.playerId], noncreature: false, source: 'Conduit of Worlds' }]; }   // a cast copy (Isochron Scepter) ceases to exist as it resolves
  player.counters = player.counters || {};
  player.counters.spellsCastThisTurn = Number(player.counters.spellsCastThisTurn || 0) + 1;
  // What this player cast this turn, for "their first noncreature spell each turn" and similar.
  const castDef = defFor(game, card);
  player.castNamesGame = [...(player.castNamesGame || []), { name: castDef?.name || '', fromZone: from }];   // Approach of the Second Sun
  player.counters.castThisTurn = [...(player.counters.castThisTurn || []), { typeLine: castDef?.typeLine || '', colors: castDef?.colors || [], manaValue: Number(castDef?.manaValue ?? castDef?.cmc ?? 0) }];
  game.spellsCastThisTurn = Number(game.spellsCastThisTurn || 0) + 1;
  // Mistrise Village ("the next spell you cast this turn can't be countered"), Veil of Summer.
  const perms = player.temporaryPermissions || [];
  const next = perms.findIndex(x => x?.kind === 'next-uncounterable');
  if (next >= 0 || perms.some(x => x?.kind === 'uncounterable-turn')) stackObject.cantBeCountered = true;
  if (next >= 0) perms.splice(next, 1);
  // "The next spell you cast this turn has improvise / cascade": used up by this spell (its cascade was queued as it was cast).
  for (let k = perms.length - 1; k >= 0; k--) if (perms[k]?.kind === 'next-spell-keyword' && !(perms[k].noncreature && /\bCreature\b/.test(castDef?.typeLine || ''))) perms.splice(k, 1);
  game.stack.push(stackObject);
  // the colours of mana spent on it (Sunburst)
  stackObject.colorsSpent = [...new Set([...Object.entries(action.payment || {}).filter(([k, v]) => /^[WUBRG]$/.test(k) && Number(v) > 0).map(([k]) => k), ...(action.payment?.__sourceAssignments || []).map(a => a.color).filter(c => /^[WUBRG]$/.test(c))])];
  const manaSpent = Object.entries(action.payment || {}).filter(([k]) => !k.startsWith('__')).reduce((n, [, v]) => n + Math.max(0, Number(v || 0)), 0) + (action.payment?.__sourceAssignments || []).length;
  stackObject.manaFrom = [...new Set(player.mana.spentTags || [])];   // the kinds of source the mana came from (Treasure)
  stackObject.manaSpentCount = manaSpent;   // "the amount of mana spent to cast this spell"
  emit(game, { type: 'spell-cast', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: player.playerId, fromZone: from, ...(card.preparedOf ? { prepared: true } : {}), stackId: stackObject.id, castMode: stackObject.castMode, kicked: !!action.kicked, manaSpent, manaFrom: stackObject.manaFrom, typeLine: defFor(game, card)?.typeLine || '', manaValue: Number(defFor(game, card)?.manaValue ?? defFor(game, card)?.cmc ?? 0) });
  return stackObject;
}
function payAbilityCosts(game, player, action, deck) {
  const before = locate(deck, action.instanceId);
  for (const id of action.costExileIds || []) {
    const h = locateCardInGame(game, id);
    if (!h || !['battlefield', 'graveyard', 'hand'].includes(h.zone)) throw new Error('The card chosen to exile is gone.');   // graveyard: forage; hand: Jhoira
    moveCard(game, id, 'exile', { onEvent: e => emit(game, { ...e, cost: true }) });
  }
  // "Exile this card from your graveyard" as the cost: the source has gone to exile by now, but it still pays the rest.
  let hit = (action.costExileIds || []).includes(action.instanceId) && before && before.z === action.fromZone ? { card: before.card, z: action.fromZone } : locate(deck, action.instanceId);
  // "Any player may activate this ability": the source is another player's permanent.
  if (!hit && action.anyPlayer) { const g = locateCardInGame(game, action.instanceId); if (g && g.zone === 'battlefield') hit = { card: g.card, z: 'battlefield' }; }
  // Channel (from the hand) and "return this card from your graveyard" abilities name the zone they work from.
  if (!hit || (hit.z !== 'battlefield' && !(action.fromZone && hit.z === action.fromZone)))
    throw new Error('Ability source must be on the battlefield');
  const card = hit.card;
  if (action.requiresTap) {
    if (card.tapped)
      throw new Error('Ability source is already tapped');
    setTappedWithCapacity(game, player, card, true);
    emit(game, { type: 'tapped', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: player.playerId });
  }
  if (action.requiresUntap) {
    if (!card.tapped)
      throw new Error('Ability source is not tapped');
    setTappedWithCapacity(game, player, card, false);
    emit(game, { type: 'untapped', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: player.playerId });
  }
  // "Remove all eyeball counters from this artifact" (a cost): counted by ops.js before it is paid.
  for (const rc of action.costRemoveCounters || []) {
    if (!rc.amount) continue;
    card.counters = card.counters || {};
    card.counters[rc.counter] = Math.max(0, Number(card.counters[rc.counter] || 0) - Number(rc.amount));
    if (!card.counters[rc.counter]) delete card.counters[rc.counter];
    emit(game, { type: 'counter-removed', sourceId: card.instanceId, controllerId: player.playerId, counter: rc.counter, amount: Number(rc.amount) });
  }
  payMana(game, player, action.payment);
  if (action.energyCost) {
    player.counters = player.counters || {};
    if (Number(player.counters.energy || 0) < Number(action.energyCost))
      throw new Error('Not enough Energy to pay this activation cost');
    player.counters.energy = Number(player.counters.energy || 0) - Number(action.energyCost);
  }
  if (action.lifeCost) {
    if (player.life < action.lifeCost)
      throw new Error('Not enough life to pay this activation cost');
    player.life -= action.lifeCost;
    emit(game, { type: 'life-lost', playerId: player.playerId, amount: action.lifeCost, controllerId: player.playerId, sourceId: card.instanceId });
  }
  if (Array.isArray(action.costMoveIds))
    for (const id of action.costMoveIds) {
      const mv = locate(deck, id);
      if (!mv)
        throw new Error('Chosen activation-cost card is unavailable');
      const def = defFor(game, mv.card), fromZone = mv.z, fromController = mv.card.controllerId || player.playerId, wasTapped = !!mv.card.tapped;
      const [paid] = mv.a.splice(mv.i, 1);
      const last = fromZone === 'battlefield' ? leaveBattlefield(paid) : null;
      paid.zone = 'graveyard';
      paid.tapped = false;
      const owner = ownerFor(game, paid, player);
      if (!paid.token)
        owner.deck.graveyard.push(paid);
      if (fromZone === 'battlefield') {
        emit(game, { type: 'sacrificed', sourceId: paid.instanceId, definitionId: paid.definitionId, controllerId: fromController, ownerId: paid.ownerId, typeLine: def?.typeLine || '', token: !!paid.token, cost: true });
        emit(game, { type: 'leaves-battlefield', sourceId: paid.instanceId, definitionId: paid.definitionId, controllerId: fromController, ownerId: paid.ownerId, destination: 'graveyard', typeLine: def?.typeLine || '', wasTapped });
        if (/Creature/i.test(def?.typeLine || ''))
          emit(game, { type: 'dies', sourceId: paid.instanceId, definitionId: paid.definitionId, controllerId: fromController, ownerId: paid.ownerId, typeLine: def?.typeLine || '', token: !!paid.token, last });
      }
      else if (fromZone === 'hand') {
        emit(game, { type: 'discard', playerId: player.playerId, sourceId: paid.instanceId, definitionId: paid.definitionId, cost: true });
      }
    }
  if (action.sacrificeSelf) {
    const selfHit = locate(deck, action.instanceId);
    if (selfHit) {
      const def = defFor(game, selfHit.card), fromController = selfHit.card.controllerId || player.playerId, wasTapped = !!selfHit.card.tapped;
      const [sacrificed] = selfHit.a.splice(selfHit.i, 1);
      const last = leaveBattlefield(sacrificed);
      action.sacLastCounters = { ...(last.counters || {}) };   // "the number of charge counters on this artifact" (Ratchet Bomb) reads what it had as it was sacrificed
      sacrificed.zone = 'graveyard';
      sacrificed.tapped = false;
      const owner = ownerFor(game, sacrificed, player);
      if (!sacrificed.token)
        owner.deck.graveyard.push(sacrificed);
      emit(game, { type: 'sacrificed', sourceId: sacrificed.instanceId, definitionId: sacrificed.definitionId, controllerId: fromController, ownerId: sacrificed.ownerId, typeLine: def?.typeLine || '', token: !!sacrificed.token, cost: true });
      emit(game, { type: 'leaves-battlefield', sourceId: sacrificed.instanceId, definitionId: sacrificed.definitionId, controllerId: fromController, ownerId: sacrificed.ownerId, destination: 'graveyard', typeLine: def?.typeLine || '', wasTapped });
      if (/Creature/i.test(def?.typeLine || ''))
        emit(game, { type: 'dies', sourceId: sacrificed.instanceId, definitionId: sacrificed.definitionId, controllerId: fromController, ownerId: sacrificed.ownerId, typeLine: def?.typeLine || '', token: !!sacrificed.token, last });
    }
  }
  return card;
}
function putAbilityOnStack(game, player, action, deck) {
  const source = payAbilityCosts(game, player, action, deck);
  game.stack = game.stack || [];
  const obj = { id: action.stackId || `stack:${Date.now()}:${Math.random()}`, kind: 'ability', controllerId: player.playerId, sourceId: action.instanceId, sourceDefinitionId: source?.definitionId || action.sourceDefinitionId || null, effects: structuredClone(action.effects || []), effectBindings: structuredClone(action.effectBindings || {}), searchResult: structuredClone(action.searchResult || null), manaColor: action.manaColor || null, manaAmount: action.manaAmount || 1, label: action.label || 'Activated ability', guidedResolution: structuredClone(action.guidedResolution || null), createdAt: new Date().toISOString() };
  { const tag = sourceTag(game, { definitionId: obj.sourceDefinitionId }); if (tag) obj.effectBindings.sourceTag = tag; }
  if (globalThis.__dbg) console.log('ABIL', obj.sourceDefinitionId, JSON.stringify(obj.effectBindings), JSON.stringify(obj.effects));   // mana this ability adds remembers what made it (Treasure)
  if (action.sacLastCounters) { obj.effectBindings = { ...(obj.effectBindings || {}), eventCounters: action.sacLastCounters }; delete action.sacLastCounters; }
  game.stack.push(obj);
  emit(game, { type: 'ability-activated', sourceId: action.instanceId, definitionId: obj.sourceDefinitionId, controllerId: player.playerId, stackId: obj.id });
  return obj;
}
function applySearchResult(game, player, obj) {
  const deck = player.deck;
  // Several colours at once: "Add {W}{U}." (Signets), "For each color among permanents you control, add one mana of that color." (Bloom Tender)
  const tag = sourceTag(game, { definitionId: obj.sourceDefinitionId });
  if (obj.manaMix?.length)
    for (const c of obj.manaMix) addMana(player, c, 1, tag);
  else if (obj.manaColor)
    addMana(player, obj.manaColor, obj.manaAmount || 1, tag);
  const search = obj.searchResult;
  if (!search)
    return;
  emit(game, { type: 'library-searched', playerId: player.playerId, controllerId: player.playerId });
  if (!search.instanceId) {
    if (search.shuffle)
      shuffleArray(deck.remainingLibrary);
    return;
  }
  const found = locate(deck, search.instanceId);
  if (!found || found.z !== 'remainingLibrary')
    throw new Error('The selected searched card is no longer in the library');
  const [searched] = found.a.splice(found.i, 1);
  const to = search.to || 'hand';
  searched.zone = to;
  if (to === 'battlefield') {
    searched.controllerId = player.playerId;
    searched.enteredTurn = game.turnNumber;
    searched.enteredFrom = 'library';
    searched.controlSinceTurn = game.turnNumber;
    searched.tapped = !!search.entersTapped;
  }
  const target = deck[zoneKey(to)];
  if (!target)
    throw new Error('Invalid search destination');
  if (to === 'library' && search.position === 'top')
    target.unshift(searched);
  else
    target.push(searched);
  if (search.shuffle)
    shuffleArray(deck.remainingLibrary);
  if (to === 'battlefield' && search.untapIfLandsAtLeast) {
    const landCount = (deck.battlefield || []).filter(x => /\bLand\b/i.test(defFor(game, x)?.typeLine || '')).length;
    if (landCount >= Number(search.untapIfLandsAtLeast))
      searched.tapped = false;
  }
  if (to === 'battlefield')
    emit(game, { type: 'enters-battlefield', sourceId: searched.instanceId, definitionId: searched.definitionId, controllerId: player.playerId, ownerId: searched.ownerId, typeLine: defFor(game, searched)?.typeLine || '' });
}
function resolveStackTop(game) {
  game.stack = game.stack || [];
  const obj = game.stack.pop();
  if (!obj)
    throw new Error('The stack is empty.');
  game.resolvingObj = { id: obj.id, kind: obj.kind, fromZone: obj.fromZone || null };   // "copy this spell" while it resolves (effects-b49.js)
  Object.defineProperty(game, '__resolvingFull', { value: obj, enumerable: false, configurable: true, writable: true });
  const player = game.players.find(p => p.playerId === obj.controllerId);
  if (!player)
    throw new Error('Stack object controller is unavailable.');
  let notes = [];
  if (obj.kind === 'spell' || obj.kind === 'spell-copy') {
    const card = obj.card, def = defFor(game, card), isCopy = obj.kind === 'spell-copy' || obj.isCopy;
    // Mutate: merge with the target non-Human creature its owner controls, over or under it (if it's still legal).
    if (obj.mutateOnto && !isCopy) {
      const host = (player.deck.battlefield || []).find(c => c.instanceId === obj.mutateOnto);
      const hd = host && defFor(game, host);
      if (host && /\bCreature\b/.test(hd?.typeLine || '') && !/\bHuman\b/.test(hd?.typeLine || '') && host.ownerId === player.playerId) {
        card.zone = 'merged';
        card.controllerId = player.playerId;
        host.mutatedWith = [...(host.mutatedWith || []), card];
        host.mutateOrder = obj.mutateUnder ? [...(host.mutateOrder || [host.instanceId]), card.instanceId] : [card.instanceId, ...(host.mutateOrder || [host.instanceId])];
        refreshMutated(game, host);
        emit(game, { type: 'spell-resolved', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: player.playerId, destination: 'merged' });
        emit(game, { type: 'mutated', sourceId: host.instanceId, definitionId: host.definitionId, controllerId: player.playerId });
        return { obj, notes: [`${defFor(game, card)?.name} mutates ${obj.mutateUnder ? 'under' : 'onto'} ${hd.name}.`] };
      }
    }
    let to = isCopy ? 'none' : (obj.to || (/Instant|Sorcery/i.test(def?.typeLine || '') ? 'graveyard' : 'battlefield'));
    if (to === 'graveyard' && graveyardDestination(game, card) === 'exile')
      obj.to = to = 'exile';
    delete card.exileInsteadOfGraveyard;
    card.zone = to;
    if (to === 'battlefield') {
      card.controllerId = player.playerId;
      card.enteredTurn = game.turnNumber;
      card.controlSinceTurn = game.turnNumber;
      card.tapped = !!obj.entersTapped;
      if (obj.asEntersChoices?.color)
        card.chosenColor = obj.asEntersChoices.color;
      if (obj.asEntersChoices?.creatureType)
        card.chosenCreatureType = obj.asEntersChoices.creatureType;
      if (obj.asEntersChoices?.cardName)
        card.chosenCardName = obj.asEntersChoices.cardName;
      if (obj.asEntersChoices?.playerId)
        card.chosenPlayerId = obj.asEntersChoices.playerId;
      if (obj.asEntersChoices?.protectorId)
        card.protectorId = obj.asEntersChoices.protectorId;
      if (obj.asEntersChoices && 'tributePaid' in obj.asEntersChoices) card.tributePaid = !!obj.asEntersChoices.tributePaid;
      if (obj.asEntersChoices?.plusCounters) {
        card.counters = card.counters || {};
        card.counters['+1/+1'] = Number(card.counters['+1/+1'] || 0) + Number(obj.asEntersChoices.plusCounters);
      }
      card.devoured = 0;
      if (obj.asEntersChoices?.devour?.length) {
        // Devour: the chosen creatures still there are sacrificed; counters for each one sacrificed
        let n = 0;
        for (const id of obj.asEntersChoices.devour) {
          const h = locateCardInGame(game, id);
          if (!h || h.zone !== 'battlefield' || id === card.instanceId) continue;
          moveCard(game, id, 'graveyard', { moveReason: 'sacrifice', onEvent: e => emit(game, e) });
          n++;
        }
        if (n) { card.counters = card.counters || {}; card.counters['+1/+1'] = Number(card.counters['+1/+1'] || 0) + n * Number(obj.asEntersChoices.devourEach || 1); }
        card.devoured = n;   // Skullmulcher: "for each creature it devoured"
      }
      if (obj.asEntersChoices?.haste)
        card.temporaryEffects = [...(card.temporaryEffects || []), { kind: 'keyword', keyword: 'Haste', enabled: true }];
      if (obj.manaCapacityColor)
        card.manaCapacityColor = obj.manaCapacityColor;
    }
    // A permanent spell enters before its effects; an instant or sorcery goes to its graveyard as the last step of
    // resolving (608.2n), so "Exile all graveyards" (Farewell) does not take the spell itself.
    let nth = null;
    const place = () => {
      const owner = ownerFor(game, card, player), target = (to === 'battlefield' ? player.deck : owner.deck)[zoneKey(to)];
      if (!target)
        throw new Error('Invalid spell destination');
      if (nth && to === 'library') target.splice(Math.min(target.length, nth - 1), 0, card);   // "seventh from the top"
      else target.push(card);
    };
    if (!isCopy && to === 'battlefield')
      place();
    applySearchResult(game, player, obj);
    game.resolvingSpellId = isCopy ? null : card.instanceId;
    try { notes.push(...applyTrackedEffects(game, player, obj.effects || [], { ...obj.effectBindings, sourceId: card.instanceId })); } finally { game.resolvingSpellId = null; }
    // "Exile Teferi's Protection." / "Shuffle this card into its owner's library.": the spell goes there instead.
    if (!isCopy && to !== 'battlefield' && game.spellExileSelf === card.instanceId) { to = 'exile'; card.zone = 'exile'; obj.to = 'exile'; }
    if (!isCopy && game.spellSuspendSelf?.id === card.instanceId) { card.suspended = true; card.counters = { ...(card.counters || {}), time: game.spellSuspendSelf.time }; }
    game.spellSuspendSelf = null;
    if (!isCopy && to !== 'battlefield' && game.spellShuffleSelf === card.instanceId) { to = 'library'; card.zone = 'library'; obj.to = 'library'; }
    if (!isCopy && to !== 'battlefield' && game.spellToHand === card.instanceId) { to = 'hand'; card.zone = 'hand'; obj.to = 'hand'; }
    if (!isCopy && to !== 'battlefield' && game.spellLibraryNth?.id === card.instanceId) { nth = Number(game.spellLibraryNth.n); to = 'library'; card.zone = 'library'; obj.to = 'library'; }
    game.spellLibraryNth = null;
    game.spellExileSelf = game.spellShuffleSelf = game.spellToHand = null;
    if (!isCopy && to !== 'battlefield')
      place();
    if (!isCopy && to === 'library' && !nth)
      shuffleArray(ownerFor(game, card, player).deck.remainingLibrary);
    if (!isCopy && to === 'battlefield')
      emit(game, { type: 'enters-battlefield', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: player.playerId, ownerId: card.ownerId, typeLine: def?.typeLine || '' });
    if (!isCopy && to !== 'battlefield') {
      card.activeFaceIndex = null;
      clearCastState(card, to);
      if (to === 'exile' && obj.adventure)
        card.onAdventure = true;
    }
    if (obj.commanderId) {
      const cmd = player.commanders.find(c => c.id === obj.commanderId);
      if (cmd) {
        cmd.zone = to;
        cmd.commandZone = to === 'command';
      }
    }
    emit(game, { type: isCopy ? 'spell-copy-resolved' : 'spell-resolved', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: player.playerId, destination: to });
  }
  else if (obj.kind === 'ability' || obj.kind === 'trigger') {
    applySearchResult(game, player, obj);
    notes.push(...applyTrackedEffects(game, player, obj.effects || [], { ...obj.effectBindings, sourceId: obj.sourceId }));
    emit(game, { type: obj.kind === 'ability' ? 'ability-resolved' : 'trigger-resolved', sourceId: obj.sourceId, definitionId: obj.sourceDefinitionId, controllerId: player.playerId });
  }
  else
    throw new Error(`Unsupported stack object kind: ${obj.kind}`);
  // AU invariant: a non-copy spell may not disappear during resolution.
  if ((obj.kind === 'spell') && !obj.isCopy) {
    const expected = obj.to || (/Instant|Sorcery/i.test(defFor(game, obj.card)?.typeLine || '') ? 'graveyard' : 'battlefield');
    const owner = ownerFor(game, obj.card, player);
    const host = expected === 'battlefield' ? player : owner;
    const zone = host?.deck?.[zoneKey(expected)] || [];
    if (!zone.some(c => c.instanceId === obj.card.instanceId))
      throw new Error(`Resolution invariant failed: ${defFor(game, obj.card)?.name || 'spell'} did not reach ${expected}.`);
  }
  return { obj, notes };
}
function restore(game, before) { restoreGameSnapshot(game, before); }
function event(game, action) { game.log.unshift({ id: `event:${Date.now()}:${Math.random()}`, turn: game.turnNumber, phase: game.phase, type: action.type, playerId: action.playerId, affectedPlayerIds: action.playerId ? [action.playerId] : [], text: action.label || action.type, at: new Date().toISOString() }); }
function rebuildAvailableFromSources(game, player) {
  const fixed = { W: 0, U: 0, B: 0, R: 0, G: 0, C: 0 }, registered = { W: 0, U: 0, B: 0, R: 0, G: 0, C: 0 };
  for (const c of player.deck?.battlefield || []) {
    if (!c.manaCapacityRegistered)
      continue;
    const opts = Array.isArray(c.manaCapacityOptions) ? c.manaCapacityOptions : (c.manaCapacityColor ? [c.manaCapacityColor] : []);
    if (opts.length === 1) {
      const amount = Math.max(1, Number(c.manaCapacityAmount || 1));
      registered[opts[0]] += amount;
      if (!c.tapped && manaSourceUsable(game, c))
        fixed[opts[0]] += amount;
    }
  }
  for (const color of ['W', 'U', 'B', 'R', 'G', 'C']) {
    const manual = Math.max(0, Number(player.mana?.total?.[color] || 0) - registered[color]);
    fixed[color] += manual;
  }
  if (player.keepManaTurn === game.turnNumber) for (const c of Object.keys(fixed)) fixed[c] += Math.max(0, Number(player.mana.floating?.[c] || 0));
  player.mana.available = fixed;
  if (!(player.keepManaTurn === game.turnNumber)) { player.mana.floating = { W: 0, U: 0, B: 0, R: 0, G: 0, C: 0 }; player.mana.tags = []; }   // Birgi: kept until end of turn
}
function resetManaAtBoundary(game) { for (const p of game.players || [])
  rebuildAvailableFromSources(game, p); }
export function createTransactionEngine(game) {
  function commit(action) {
    const player = game.players.find(p => p.playerId === action.playerId);
    if (!player)
      throw new Error('Unknown player');
    const rollback = snapshotGame(game);
    const deck = player.deck;
    try {
      if (action.type === 'cast-spell')
        putSpellOnStack(game, player, action, deck);
      else if (action.type === 'activate-ability-stack')
        putAbilityOnStack(game, player, action, deck);
      else if (action.type === 'activate-zone-mana-ability') {
        const hit = locate(deck, action.instanceId);
        if (!hit || hit.z !== (action.fromZone || 'hand'))
          throw new Error('Ability source is not in the required zone');
        const [card] = hit.a.splice(hit.i, 1);
        card.zone = action.toZone || 'exile';
        card.tapped = false;
        deck[zoneKey(card.zone)].push(card);
        addMana(player, action.manaColor, Math.max(1, Number(action.manaAmount || 1)));
      }
      else if (action.type === 'special-action') {
        // Cycling, foretell, ninjutsu, turning a face-down creature face up.
        payMana(game, player, action.payment);
        const card = locate(deck, action.instanceId)?.card;
        if (!card)
          throw new Error('That card is no longer available.');
        const def = defFor(game, card);
        if (action.kind === 'cycle') {
          const hit = locate(deck, card.instanceId);
          hit.a.splice(hit.i, 1);
          card.zone = 'graveyard';
          deck.graveyard.push(card);
          emit(game, { type: 'discard', playerId: player.playerId, sourceId: card.instanceId, definitionId: card.definitionId, cost: true });
          emit(game, { type: 'cycled', playerId: player.playerId, controllerId: player.playerId, sourceId: card.instanceId, definitionId: card.definitionId });
        }
        else if (action.kind === 'reinforce') {
          // Cost: discard this card.
          const hit = locate(deck, card.instanceId);
          if (!hit || hit.z !== 'hand') throw new Error('Reinforce: the card is no longer in your hand.');
          hit.a.splice(hit.i, 1);
          card.zone = 'graveyard';
          deck.graveyard.push(card);
          emit(game, { type: 'discard', playerId: player.playerId, sourceId: card.instanceId, definitionId: card.definitionId, cost: true });
        }
        else if (action.kind === 'scavenge') {
          // Cost: exile this card from the graveyard.
          const hit = locate(deck, card.instanceId);
          if (!hit || hit.z !== 'graveyard')
            throw new Error('Scavenge: the card is no longer in the graveyard.');
          hit.a.splice(hit.i, 1);
          card.zone = 'exile';
          deck.exile.push(card);
        }
        else if (action.kind === 'outlast') {
          if (card.tapped) throw new Error('Outlast: it is already tapped.');
          setTappedWithCapacity(game, player, card, true);
          emit(game, { type: 'tapped', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: player.playerId });
        }
        else if (action.kind === 'craft') {
          // Cost: exile this permanent and the chosen materials (other permanents or graveyard cards).
          for (const id of [card.instanceId, ...(action.materialIds || [])]) {
            const where = locateCardInGame(game, id);
            if (!where || !['battlefield', 'graveyard'].includes(where.zone))
              throw new Error('Craft: a card to exile is gone.');
            moveCard(game, id, 'exile', { onEvent: e => emit(game, { ...e, cost: true }) });
          }
        }
        else if (action.kind === 'unlock') {
          const hit = locate(deck, card.instanceId);
          if (!hit || hit.z !== 'battlefield') throw new Error('Unlock: the Room is no longer on the battlefield.');
          const open = card.unlockedFaces || (Number.isInteger(card.activeFaceIndex) ? [card.activeFaceIndex] : []);
          if (open.includes(action.face)) throw new Error('That door is already unlocked.');
          card.unlockedFaces = [...open, action.face];
          emit(game, { type: 'door-unlocked', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: player.playerId, playerId: player.playerId, face: action.face, fully: card.unlockedFaces.length >= 2 });
        }
        else if (action.kind === 'companion') {
          const hit = locate(deck, card.instanceId);
          if (!hit || hit.z !== 'commandZone') throw new Error('Companion: it is no longer outside the game.');
          hit.a.splice(hit.i, 1);
          card.zone = 'hand';
          deck.hand.push(card);
          player.companionUsed = true;
        }
        else if (action.kind === 'suspend') {
          const hit = locate(deck, card.instanceId);
          if (!hit || hit.z !== 'hand')
            throw new Error('Suspend: the card is no longer in your hand.');
          hit.a.splice(hit.i, 1);
          card.zone = 'exile';
          card.suspended = true;
          card.counters = { ...(card.counters || {}), time: Number(action.time || 0) };
          deck.exile.push(card);
        }
        else if (action.kind === 'unearth') {
          if (locate(deck, card.instanceId)?.z !== 'graveyard')
            throw new Error('Unearth: the card is no longer in the graveyard.');
        }
        else if (action.kind === 'crew') {
          for (const id of action.crewIds || []) {
            const c = locate(deck, id)?.card;
            if (!c || c.tapped)
              throw new Error('A crewing creature is no longer untapped.');
            c.tapped = true;
            emit(game, { type: 'tapped', sourceId: c.instanceId, controllerId: player.playerId, forCrew: true });
          }
          emit(game, { type: action.saddle ? 'saddled' : 'crewed', sourceId: card.instanceId, controllerId: player.playerId, crewIds: action.crewIds || [] });
        }
        else if (action.kind === 'plot') {
          const hit = locate(deck, card.instanceId);
          if (!hit || hit.z !== 'hand') throw new Error('Plot: the card is no longer in your hand.');
          hit.a.splice(hit.i, 1);
          card.zone = 'exile';
          card.plotted = true;
          card.plottedTurn = game.turnNumber;
          deck.exile.push(card);
          emit(game, { type: 'plotted', sourceId: card.instanceId, controllerId: player.playerId, playerId: player.playerId });
        }
        else if (action.kind === 'foretell') {
          const hit = locate(deck, card.instanceId);
          hit.a.splice(hit.i, 1);
          card.zone = 'exile';
          card.foretold = true;
          card.foretoldTurn = game.turnNumber;
          deck.exile.push(card);
        }
        else if (action.kind === 'turn-face-up') {
          if (!card.realDefinitionId)
            throw new Error('That permanent is not face down.');
          card.definitionId = card.realDefinitionId;
          delete card.realDefinitionId;
          delete card.faceDownKind;
          if (card.castFlags?.megamorph) {
            card.counters = card.counters || {};
            card.counters['+1/+1'] = Number(card.counters['+1/+1'] || 0) + 1;
          }
          delete card.castFlags;
          emit(game, { type: 'turned-face-up', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: player.playerId });
        }
        else if (action.kind === 'ninjutsu') {
          const back = locate(deck, action.returnId);
          const attack = (game.combatState?.attackers || []).find(a => a.instanceId === action.returnId);
          if (!back || back.z !== 'battlefield' || !attack)
            throw new Error('The unblocked attacker is gone.');
          back.a.splice(back.i, 1);
          const returned = back.card;
          returned.zone = 'hand';
          returned.tapped = false;
          returned.counters = {};
          returned.temporaryEffects = [];
          clearCastState(returned, 'hand');
          deck.hand.push(returned);
          emit(game, { type: 'leaves-battlefield', sourceId: returned.instanceId, definitionId: returned.definitionId, controllerId: player.playerId, ownerId: returned.ownerId, destination: 'hand', typeLine: defFor(game, returned)?.typeLine || '' });
          const hit = locate(deck, card.instanceId);
          hit.a.splice(hit.i, 1);
          card.zone = 'battlefield';
          card.tapped = true;
          card.controllerId = player.playerId;
          card.enteredTurn = game.turnNumber;
          card.controlSinceTurn = game.turnNumber;
          deck.battlefield.push(card);
          attack.instanceId = card.instanceId;
          card.attacking = attack.defenderId;
          emit(game, { type: 'enters-battlefield', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: player.playerId, ownerId: card.ownerId, typeLine: def?.typeLine || '' });
        }
        if (action.stack) {
          game.stack = game.stack || [];
          game.stack.push({ id: action.stack.id, kind: 'ability', controllerId: player.playerId, sourceId: card.instanceId, sourceDefinitionId: card.definitionId, effects: structuredClone(action.stack.effects || []), effectBindings: structuredClone(action.stack.effectBindings || {}), label: action.stack.label, abilityText: action.stack.text || '', guidedResolution: structuredClone(action.stack.guided || null), createdAt: new Date().toISOString() });
        }
      }
      else if (action.type === 'put-trigger-stack') {
        game.stack = game.stack || [];
        game.stack.push({ id: action.stackId || `stack:${Date.now()}:${Math.random()}`, kind: 'trigger', controllerId: player.playerId, sourceId: action.sourceId || null, sourceDefinitionId: action.sourceDefinitionId || null, effects: structuredClone(action.effects || []), effectBindings: structuredClone(action.effectBindings || {}), label: action.label || 'Triggered ability', abilityText: action.abilityText || '', guidedResolution: structuredClone(action.guidedResolution || null), createdAt: new Date().toISOString() });
      }
      else if (action.type === 'resolve-stack') {
        let r;
        try {
          r = resolveStackTop(game);
        }
        catch (error) {
          // The outer catch restores the pre-commit snapshot.
          throw error;
        }
        action.label = `${r.obj.label || 'Stack object'} resolves.${r.notes.length ? ' ' + r.notes.join(' ') : ''}`;
      }
      else if (action.type === 'resolve-effects') {
        const notes = applyTrackedEffects(game, player, action.effects || [], { ...action.effectBindings, sourceId: action.sourceId || null });
        if (notes.length)
          action.label = `${action.label || 'Effect resolves.'} ${notes.join(' ')}`;
      }
      else if (action.type === 'dredge') {
        // Dredge N instead of drawing: mill N, then return the dredge card from the graveyard to hand.
        const hit = locate(deck, action.instanceId);
        if (!hit || hit.z !== 'graveyard' || deck.remainingLibrary.length < Number(action.amount || 0))
          throw new Error('That card can no longer dredge.');
        for (let k = 0; k < Number(action.amount || 0); k++) { const c = deck.remainingLibrary.shift(); c.zone = 'graveyard'; deck.graveyard.push(c); emit(game, { type: 'mill', playerId: player.playerId, sourceId: c.instanceId, definitionId: c.definitionId, amount: 1 }); }
        const at = deck.graveyard.findIndex(c => c.instanceId === action.instanceId);
        const [card] = deck.graveyard.splice(at, 1);
        delete card.gySeen;
        game.leftGraveyard = { ...(game.leftGraveyard || {}), [player.playerId]: game.turnNumber };
        card.zone = 'hand'; deck.hand.push(card);
        emit(game, { type: 'zone-change', sourceId: card.instanceId, definitionId: card.definitionId, from: 'graveyard', to: 'hand', controllerId: player.playerId, ownerId: card.ownerId });
      }
      else if (action.type === 'draw') {
        const card = deck.remainingLibrary.shift();
        if (!card)
          throw new Error('Library is empty');
        card.zone = 'hand';
        card.drawnTurn = game.turnNumber;
        deck.hand.push(card);
        player.counters = player.counters || {};
        player.counters.cardsDrawnThisTurn = Number(player.counters.cardsDrawnThisTurn || 0) + 1;
        emit(game, { type: 'draw', playerId: player.playerId, sourceId: card.instanceId, definitionId: card.definitionId, drawNumberThisTurn: player.counters.cardsDrawnThisTurn, isFirstNormalDrawStepDraw: game.phase === 'draw' && player.counters.cardsDrawnThisTurn === 1 });
      }
      else if (action.type === 'move-card') {
        if (action.to === 'graveyard') {
          const probe = locate(deck, action.instanceId);
          if (probe && graveyardDestination(game, probe.card) === 'exile')
            action = { ...action, to: 'exile' };
        }
        const hit = locate(deck, action.instanceId);
        if (!hit)
          throw new Error('Card not found');
        const card = hit.card, def = defFor(game, card), from = hit.z, fromController = card.controllerId || player.playerId;
        hit.a.splice(hit.i, 1);
        const last = { counters: { ...(card.counters || {}) }, castMode: card.castMode || null };
        if (from === 'battlefield' && action.to !== 'battlefield') {
          card.damageMarked = 0;
          card.deathtouchDamage = false;
          card.counters = {};
          card.temporaryEffects = [];
          delete card.attacking;
          delete card.blocking;
          delete card.unlockedFaces;   // Room doors lock again
        }
        clearCastState(card, action.to);
        const wasTappedBeforeMove = !!card.tapped;
        card.zone = action.to;
        card.tapped = action.to === 'battlefield' ? !!action.tapped : false;
        card.controllerId = action.to === 'battlefield' ? (action.controllerId || player.playerId) : card.ownerId;
        const owner = ownerFor(game, card, player), target = (action.to === 'battlefield' ? (game.players.find(p => p.playerId === card.controllerId) || owner) : owner).deck[zoneKey(action.to)];
        if (!target)
          throw new Error('Invalid target zone');
        if (action.to === 'library' && action.position === 'top')
          target.unshift(card);
        else if (!(card.token && action.to !== 'battlefield'))
          target.push(card);
        if (from === 'battlefield' && action.to !== 'battlefield') {
          if (action.moveReason === 'sacrifice') emit(game, { type: 'sacrificed', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: fromController, ownerId: card.ownerId, typeLine: def?.typeLine || '', token: !!card.token });
          emit(game, { type: 'leaves-battlefield', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: fromController, ownerId: card.ownerId, destination: action.to, typeLine: def?.typeLine || '', wasTapped: wasTappedBeforeMove });
          if (action.to === 'graveyard' && /Creature/i.test(def?.typeLine || ''))
            emit(game, { type: 'dies', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: fromController, ownerId: card.ownerId, typeLine: def?.typeLine || '', token: !!card.token, last });
        }
        if (action.to === 'battlefield') {
          card.enteredTurn = game.turnNumber;
          card.controlSinceTurn = game.turnNumber;
          emit(game, { type: 'enters-battlefield', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: card.controllerId, ownerId: card.ownerId, typeLine: def?.typeLine || '' });
        }
        else if (action.to !== 'stack')
          card.activeFaceIndex = null;
        const cmd = player.commanders.find(x => x.cardId === card.definitionId);
        if (cmd) {
          cmd.zone = action.to;
          cmd.commandZone = action.to === 'command';
        }
      }
      else if (action.type === 'play-land') {
        const hit = locate(deck, action.instanceId);
        if (!hit || hit.z !== 'hand')
          throw new Error('Land must be in hand');
        const [card] = hit.a.splice(hit.i, 1);
        if (Number.isInteger(action.activeFaceIndex))
          card.activeFaceIndex = action.activeFaceIndex;
        card.zone = 'battlefield';
        card.controllerId = player.playerId;
        card.enteredTurn = game.turnNumber;
        card.controlSinceTurn = game.turnNumber;
        card.tapped = !!action.entersTapped;
        if (action.asEntersChoices?.color)
          card.chosenColor = action.asEntersChoices.color;
        if (action.asEntersChoices?.creatureType)
          card.chosenCreatureType = action.asEntersChoices.creatureType;
        if (action.asEntersChoices?.cardName)
          card.chosenCardName = action.asEntersChoices.cardName;
        if (action.asEntersChoices?.playerId)
          card.chosenPlayerId = action.asEntersChoices.playerId;
        if (action.lifeCost) {
          if (Number(player.life || 0) < Number(action.lifeCost))
            throw new Error('Not enough life to pay for this land.');
          player.life = Number(player.life) - Number(action.lifeCost);
        }
        deck.battlefield.push(card);
        if (!action.doesNotCountAsLandPlay)
          player.counters.landsPlayedThisTurn = Number(player.counters.landsPlayedThisTurn || 0) + 1;
        if (action.basicManaColor)
          card.manaCapacityColor = action.basicManaColor;
        emit(game, { type: 'enters-battlefield', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: player.playerId, ownerId: card.ownerId, typeLine: defFor(game, card)?.typeLine || '', manaValue: Number(defFor(game, card)?.manaValue ?? defFor(game, card)?.cmc ?? 0), played: !action.doesNotCountAsLandPlay });
      }
      else if (action.type === 'cast-card') {
        // Legacy immediate-resolution path retained for older callers/tests. New UI routes spells through cast-spell + priority.
        const hit = locate(deck, action.instanceId);
        if (!hit || !['hand', 'commandZone'].includes(hit.z))
          throw new Error('Card is not castable from that zone');
        const [card] = hit.a.splice(hit.i, 1);
        payMana(game, player, action.payment);
        if (Number.isInteger(action.activeFaceIndex))
          card.activeFaceIndex = action.activeFaceIndex;
        card.zone = action.to || 'battlefield';
        const def = defFor(game, card);
        if (card.zone === 'battlefield') {
          card.controllerId = player.playerId;
          card.enteredTurn = game.turnNumber;
          card.controlSinceTurn = game.turnNumber;
          card.tapped = !!action.entersTapped;
          if (action.asEntersChoices?.color)
            card.chosenColor = action.asEntersChoices.color;
          if (action.manaCapacityColor)
            card.manaCapacityColor = action.manaCapacityColor;
        }
        const owner = ownerFor(game, card, player), target = (card.zone === 'battlefield' ? player.deck : owner.deck)[zoneKey(card.zone)];
        target.push(card);
        if (card.zone === 'battlefield')
          emit(game, { type: 'enters-battlefield', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: player.playerId, ownerId: card.ownerId, typeLine: def?.typeLine || '' });
        const effectNotes = applyTrackedEffects(game, player, action.effects || [], { ...action.effectBindings, sourceId: card.instanceId });
        if (card.zone !== 'battlefield')
          card.activeFaceIndex = null;
        if (effectNotes.length)
          action.label = `${action.label || 'Spell resolved.'} ${effectNotes.join(' ')}`;
      }
      else if (action.type === 'tap-card') {
        const hit = locate(deck, action.instanceId);
        if (!hit)
          throw new Error('Card instance not found');
        if (hit.z !== 'battlefield')
          throw new Error('Only battlefield permanents can be tapped or untapped.');
        const card = hit.card;
        if (action.tapped === false && !action.allowUntap)
          throw new Error('A tapped permanent can only untap during the untap step or because a rule/card effect permits it.');
        if (action.tapped !== false && card.tapped)
          throw new Error('This permanent is already tapped.');
        setTappedWithCapacity(game, player, card, action.tapped !== false);
        emit(game, { type: card.tapped ? 'tapped' : 'untapped', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: card.controllerId || player.playerId });
      }
      else if (action.type === 'activate-mana') {
        const hit = locate(deck, action.instanceId);
        if (!hit || hit.z !== 'battlefield')
          throw new Error('Mana source must be on the battlefield');
        if (hit.card.tapped)
          throw new Error('Mana source is already tapped');
        if (!manaSourceUsable(game, hit.card))
          throw new Error('This creature has summoning sickness and cannot activate a mana ability with {T} in its cost.');
        const opts = Array.isArray(hit.card.manaCapacityOptions) ? hit.card.manaCapacityOptions : [];
        if (opts.length && action.color && !opts.includes(action.color))
          throw new Error('That mana source cannot produce the chosen color.');
        setTappedWithCapacity(game, player, hit.card, true);
        addMana(player, action.color, action.amount || 1, sourceTag(game, hit.card));
        emit(game, { type: 'tapped', sourceId: hit.card.instanceId, definitionId: hit.card.definitionId, controllerId: player.playerId });
      }
      else if (action.type === 'activate-ability') {
        // Legacy immediate-resolution path; mana abilities still intentionally use it because mana abilities do not use the stack.
        const hit = locate(deck, action.instanceId);
        if (!hit || hit.z !== 'battlefield')
          throw new Error('Ability source must be on the battlefield');
        const card = hit.card;
        action.sourceDefinitionId = action.sourceDefinitionId || card.definitionId;   // the mana it adds is tagged with what made it (Treasure), also when the source is sacrificed as a cost
        { const tag = sourceTag(game, card); if (tag) action.effectBindings = { ...(action.effectBindings || {}), sourceTag: tag }; }
        if (action.requiresTap) {
          if (card.tapped)
            throw new Error('Ability source is already tapped');
          setTappedWithCapacity(game, player, card, true);
          emit(game, { type: 'tapped', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: player.playerId });
          if (action.manaColor) emit(game, { type: 'tapped-for-mana', sourceId: card.instanceId, definitionId: card.definitionId, controllerId: player.playerId, playerId: player.playerId, color: action.manaColor, land: /\bLand\b/.test(defFor(game, card)?.typeLine || ''), creature: /\bCreature\b/.test(defFor(game, card)?.typeLine || ''), typeLine: defFor(game, card)?.typeLine || '' });
        }
        if (action.requiresUntap) {
          if (!card.tapped)
            throw new Error('Ability source is not tapped');
          setTappedWithCapacity(game, player, card, false);
        }
        payMana(game, player, action.payment);
        if (action.lifeCost) {
          if (player.life < action.lifeCost)
            throw new Error('Not enough life to pay this activation cost');
          player.life -= action.lifeCost;
        }
        if (Array.isArray(action.costMoveIds))
          for (const id of action.costMoveIds) {
            const mv = locate(deck, id);
            if (!mv)
              throw new Error('Chosen activation-cost card is unavailable');
            const def = defFor(game, mv.card), fromZone = mv.z, fromController = mv.card.controllerId || player.playerId, wasTapped = !!mv.card.tapped;
            const [paid] = mv.a.splice(mv.i, 1);
            paid.zone = 'graveyard';
            paid.tapped = false;
            const owner = ownerFor(game, paid, player);
            if (!paid.token)
              owner.deck.graveyard.push(paid);
            if (fromZone === 'battlefield') {
              emit(game, { type: 'sacrificed', sourceId: paid.instanceId, definitionId: paid.definitionId, controllerId: fromController, ownerId: paid.ownerId, typeLine: def?.typeLine || '', token: !!paid.token, cost: true });
              emit(game, { type: 'leaves-battlefield', sourceId: paid.instanceId, definitionId: paid.definitionId, controllerId: fromController, ownerId: paid.ownerId, destination: 'graveyard', typeLine: def?.typeLine || '', wasTapped });
              if (/Creature/i.test(def?.typeLine || ''))
                emit(game, { type: 'dies', sourceId: paid.instanceId, definitionId: paid.definitionId, controllerId: fromController, ownerId: paid.ownerId, typeLine: def?.typeLine || '', token: !!paid.token, last });
            }
            else if (fromZone === 'hand') {
              emit(game, { type: 'discard', playerId: player.playerId, sourceId: paid.instanceId, definitionId: paid.definitionId, cost: true });
            }
          }
        if (action.sacrificeSelf) {
          const selfHit = locate(deck, action.instanceId);
          if (selfHit && selfHit.z === 'battlefield')
            moveCard(game, action.instanceId, 'graveyard', { moveReason: 'sacrifice', onEvent: e => emit(game, { ...e, cost: true }) });
        }
        applySearchResult(game, player, action);
        const effectNotes = applyTrackedEffects(game, player, action.effects || [], { ...action.effectBindings, sourceId: action.instanceId });
        if (effectNotes.length)
          action.label = `${action.label || 'Ability resolved.'} ${effectNotes.join(' ')}`;
      }
      else if (action.type === 'guided-note') {
        game.guidedRules = game.guidedRules || [];
        game.guidedRules.push({ text: action.note || 'Guided Oracle effect', sourceId: action.sourceId || null, playerId: player.playerId, expires: action.expires || null, turn: game.turnNumber });
        action.label = action.label || `Guided effect tracked: ${action.note || 'Oracle effect'}`;
      }
      else if (action.type === 'pay-mana') {
        // Another player pays a cost for an effect ("unless that player pays {1}").
        payMana(game, player, action.payment);
        if (action.lifeCost) {
          player.life = Math.max(0, player.life - Number(action.lifeCost));
          emit(game, { type: 'life-lost', playerId: player.playerId, amount: Number(action.lifeCost), controllerId: player.playerId });
        }
      }
      else if (action.type === 'life') {
        const before = player.life;
        player.life = Math.max(0, player.life + action.delta);
        const delta = player.life - before;
        player.lifeFeedback = delta ? { direction: delta > 0 ? 'gain' : 'loss', until: Date.now() + 20000 } : null;
        emit(game, { type: delta >= 0 ? 'life-gained' : 'life-lost', playerId: player.playerId, amount: Math.abs(delta), controllerId: player.playerId });
      }
      else if (action.type === 'poison')
        player.poison = Math.max(0, player.poison + action.delta);
      else if (action.type === 'counter')
        player.counters[action.counter] = Math.max(0, Number(player.counters[action.counter] || 0) + action.delta);
      else if (action.type === 'card-counter') {
        const hit = locate(deck, action.instanceId);
        if (!hit)
          throw new Error('Card not found');
        const refreshMana = hit.z === 'battlefield' && !!hit.card.manaCapacityRegistered;
        if (refreshMana)
          unregisterManaSource(player, hit.card, { wasTapped: hit.card.tapped });
        hit.card.counters = hit.card.counters || {};
        const oldValue = Number(hit.card.counters[action.counter] || 0);
        hit.card.counters[action.counter] = Math.max(0, oldValue + action.delta);
        const newValue = Number(hit.card.counters[action.counter] || 0);
        if (refreshMana)
          registerManaSource(game, player, hit.card);
        emit(game, { type: 'counter-added', targetId: hit.card.instanceId, controllerId: hit.card.controllerId || player.playerId, counter: action.counter, amount: action.delta, oldValue, newValue });
      }
      else if (action.type === 'status') {
        const set = new Set(player.statuses);
        action.enabled === false ? set.delete(action.status) : set.add(action.status);
        player.statuses = [...set];
        if (!action.label)
          action.label = `${player.displayName} ${action.enabled === false ? 'loses' : 'gains'} status: ${action.status}.`;
      }
      else if (action.type === 'mana-total') {
        player.mana.total[action.color] = Math.max(0, Number(player.mana.total[action.color] || 0) + action.delta);
        player.mana.available[action.color] = Math.max(0, Number(player.mana.available[action.color] || 0) + action.delta);
      }
      else if (action.type === 'mana-available')
        player.mana.available[action.color] = Math.max(0, Number(player.mana.available[action.color] || 0) + action.delta);
      else if (action.type === 'commander-tax-adjust') {
        const cmd = player.commanders.find(c => c.id === action.commanderId);
        if (!cmd)
          throw new Error('Commander not found');
        cmd.commanderTax = Math.max(0, Number(cmd.commanderTax || 0) + Number(action.delta || 0));
      }
      else if (action.type === 'cast-commander') {
        const cmd = player.commanders.find(c => c.id === action.commanderId);
        if (!cmd)
          throw new Error('Commander not found');
        if (cmd.zone !== 'command')
          throw new Error('Commander is not in the command zone');
        const cmdInst = deck.commandZone.find(x => x.definitionId === cmd.cardId);
        if (!cmdInst)
          throw new Error('Commander card instance is unavailable');
        putSpellOnStack(game, player, { ...action, type: 'cast-spell', instanceId: cmdInst.instanceId, fromZones: ['commandZone'], to: 'battlefield', commanderId: cmd.id }, deck);
        cmd.castCount = Number(cmd.castCount || 0) + 1;
        cmd.commanderTax = game.rulesConfig?.commanderTax === false ? 0 : Math.max(0, cmd.castCount * 2);
        cmd.zone = 'stack';
        cmd.commandZone = false;
      }
      else if (action.type === 'commander-to-command') {
        const cmd = player.commanders.find(c => c.id === action.commanderId);
        if (!cmd)
          throw new Error('Commander not found');
        const hit = locate(deck, action.instanceId);
        if (hit) {
          const [card] = hit.a.splice(hit.i, 1);
          card.zone = 'command';
          card.controllerId = player.playerId;
          deck.commandZone.push(card);
        }
        cmd.zone = 'command';
        cmd.commandZone = true;
      }
      else if (action.type === 'phase') {
        // Keep phase-ending confirmations inside the same transaction so Undo restores
        // the exact pre-confirmation combat state rather than a half-advanced state.
        if (action.noAttackCombat) {
          player.confirmations = player.confirmations || {};
          player.confirmations.attackers = true;
          game.combatState = { attackers: [], defenders: [], blocks: {}, damage: [], waitingFor: null, resolved: true };
        }
        resetManaAtBoundary(game);
        if (action.phase === 'postcombat-main')
          cleanupEndCombatEffects(game);
        game.phase = action.phase;
        configurePhaseGates(game, action.phase);
        if (action.phase === 'upkeep')
          emit(game, { type: 'upkeep', playerId: game.activePlayerId });
        if (action.phase === 'draw')
          emit(game, { type: 'draw-step', playerId: game.activePlayerId });
        if (action.phase === 'precombat-main')
          emit(game, { type: 'precombat-main-start', playerId: game.activePlayerId, controllerId: game.activePlayerId });
        if (action.phase === 'postcombat-main')
          emit(game, { type: 'postcombat-main-start', playerId: game.activePlayerId, controllerId: game.activePlayerId });
        if (action.phase === 'end-step')
          emit(game, { type: 'end-step', playerId: game.activePlayerId });
        if (action.phase === 'begin-combat' || action.phase === 'combat')
          emit(game, { type: 'begin-combat', playerId: game.activePlayerId });
      }
      else if (action.type === 'end-turn') {
        advanceTurn(game);
        if (game.dayNightChanged === game.turnNumber) emit(game, { type: 'day-night-changed', to: game.dayNight, playerId: game.activePlayerId });
      }
      else if (action.type === 'concede') {
        if (player.eliminated)
          throw new Error('This player has already left the game.');
        player.eliminated = true;
        player.eliminationReason = 'concession';
        player.concededAt = new Date().toISOString();
        game.log.unshift({ text: `${player.displayName} concedes the game.`, turn: game.turnNumber, phase: game.phase, at: new Date().toISOString() });
      }
      else
        throw new Error(`Unsupported transaction ${action.type}`);
      sync(deck);
      if (!action.silent)
        event(game, action);
      const losses = evaluateLosses(game);
      if (action.type === 'concede') {
        const alive = (game.players || []).filter(p => !p.eliminated);
        if ((game.players || []).length > 1 && alive.length === 1) {
          game.winner = alive[0].playerId;
          game.result = 'winner';
          game.status = 'complete';
          game.completionReason = 'last-player-standing';
        }
        else if ((game.players || []).length > 1 && alive.length === 0) {
          game.winner = null;
          game.result = 'draw';
          game.status = 'complete';
          game.completionReason = 'all-players-eliminated';
        }
      }
      for (const x of losses.newly || []) {
        const q = game.players.find(p => p.playerId === x.playerId);
        game.log.unshift({ text: `${q?.displayName || 'A player'} loses the game (${x.reason}).`, turn: game.turnNumber, phase: game.phase, at: new Date().toISOString() });
      }
      if (game.status !== 'complete' && !game.winner && game.players.find(p => p.playerId === game.activePlayerId)?.eliminated) {
        const currentIndex = Math.max(0, game.players.findIndex(p => p.playerId === game.activePlayerId));
        let next = null, nextStep = 0;
        for (let step = 1; step <= game.players.length; step++) {
          const candidate = game.players[(currentIndex + step) % game.players.length];
          if (candidate && !candidate.eliminated) {
            next = candidate;
            nextStep = step;
            break;
          }
        }
        if (next) {
          if ((currentIndex + nextStep) >= game.players.length)
            game.roundNumber = Math.max(1, Number(game.roundNumber || 1) + 1);
          game.activePlayerId = next.playerId;
          game.turnNumber = Math.max(1, Number(game.turnNumber || 1) + 1);
          game.phase = 'untap';
          configurePhaseGates(game, 'untap');
          game.log.unshift({ text: `Turn passes to ${next.displayName} because the active player was eliminated.`, turn: game.turnNumber, phase: game.phase, at: new Date().toISOString() });
        }
      }
      // AT stack/undo stabilization: stack bookkeeping is part of the player's root action,
      // not a separate undoable game action. Keep the pre-cast/pre-activation snapshot as
      // the Undo boundary while automatic trigger placement and stack resolution run inside it.
      // Undo history is owned by the game controller (src/game/controller.js), which snapshots
      // once per player input instead of once per engine commit.
      if (game.status !== 'complete' && !game.winner)
        game.status = 'active';
      return game;
    }
    catch (error) {
      restore(game, rollback);
      throw error;
    }
  }
  function preview(action) { game.pendingTransaction = { action: structuredClone(action), createdAt: new Date().toISOString() }; return structuredClone(game.pendingTransaction); }
  function cancel() { game.pendingTransaction = null; }
  function confirm() { if (!game.pendingTransaction)
    return false; const a = game.pendingTransaction.action; game.pendingTransaction = null; commit(a); return true; }
  return { preview, cancel, confirm, commit };
}

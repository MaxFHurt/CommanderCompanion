import { loadProfile } from './profile.js';
import { listDecks } from './deck-store.js';
import { readBuilderProfile, writeBuilderProfile, moveGameDecks } from './deck-builder.js';
import { durableSet } from './userdata-db.js';
import { listPlaymats } from './playmats.js';
import { listOnlineGames, mergeOnlineGames } from '../app/online-games.js';
const PROFILE_KEY = 'ccv07-profile';
const DECKS_KEY = 'ccv07-decks';
const BACKUP_FORMAT = 'commander-companion-profile';
const BACKUP_VERSION = 2;
function safeName(value) {
  return String(value || 'Commander-Companion').trim().replace(/[^a-z0-9._-]+/gi, '-').replace(/^-+|-+$/g, '') || 'Commander-Companion';
}
function validateBackup(raw) {
  if (!raw || typeof raw !== 'object')
    throw new Error('That file is not a Commander Companion profile backup.');
  if (raw.format !== BACKUP_FORMAT || ![1, 2].includes(Number(raw.backupVersion)))
    throw new Error('That Commander Companion backup format is not supported by this build.');
  if (!raw.profile || typeof raw.profile !== 'object' || Array.isArray(raw.profile))
    throw new Error('The backup is missing valid profile data.');
  if (!Array.isArray(raw.decks))
    throw new Error('The backup is missing valid saved deck data.');
  return raw;
}
export function buildProfileBackup() {
  const profile = loadProfile();
  const decks = listDecks();
  return {
    format: BACKUP_FORMAT,
    backupVersion: BACKUP_VERSION,
    exportedAt: new Date().toISOString(),
    profile,
    decks,                              // the Deck Builder's Commander decks as lists (older builds read these)
    deckBuilder: readBuilderProfile(),  // the Deck Builder's whole profile: decks, collection, buy lists, tablemates
    playmats: listPlaymats(),
    onlineGames: listOnlineGames()   // online games this player is in, so they show on every device
  };
}
export async function saveProfileBackupFile() {
  const backup = buildProfileBackup();
  const player = safeName(backup.profile?.account?.displayName || 'Commander-Companion');
  const date = new Date().toISOString().slice(0, 10);
  const filename = `${player}-CommanderCompanion-${date}.ccsave`;
  const text = JSON.stringify(backup, null, 2);
  const file = new File([text], filename, { type: 'application/json' });
  if (navigator.share && navigator.canShare?.({ files: [file] })) {
    await navigator.share({ files: [file], title: 'Commander Companion Profile Backup', text: 'Save this Commander Companion profile backup to Files or iCloud Drive.' });
    return filename;
  }
  const url = URL.createObjectURL(file);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.style.display = 'none';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
  return filename;
}
export async function restoreProfileBackupFile(file) {
  if (!file)
    throw new Error('Choose a Commander Companion profile backup file.');
  const text = await file.text();
  let raw;
  try {
    raw = JSON.parse(text);
  }
  catch {
    throw new Error('That backup file could not be read.');
  }
  return restoreProfileBackup(raw);
}
/** Replace this device's profile, decks and playmats with a backup (from a file or online). */
export async function restoreProfileBackup(raw) {
  const backup = validateBackup(raw);
  const profile = structuredClone(backup.profile);
  const decks = structuredClone(backup.decks);
  // A backup made since the merge carries the Deck Builder's profile; an older one carries the old editor's decks,
  // which move into the Deck Builder.
  const builder = backup.deckBuilder ? structuredClone(backup.deckBuilder) : null;
  let localOk = true;
  try {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
    if (!builder) localStorage.setItem(DECKS_KEY, JSON.stringify(decks));
  }
  catch {
    localOk = false;
  }
  let durableOk = true;
  try {
    await durableSet('profile', profile);
    if (!builder) await durableSet('decks', decks);
    if (Array.isArray(backup.playmats))
      await durableSet('playmats', structuredClone(backup.playmats));
  }
  catch {
    durableOk = false;
  }
  if (!localOk && !durableOk)
    throw new Error('The profile could not be restored because this browser is not allowing local storage.');
  mergeOnlineGames(backup.onlineGames);
  if (builder) writeBuilderProfile(builder);
  else moveGameDecks(decks, localStorage, { again: true });
  return { profile, decks, exportedAt: backup.exportedAt || null };
}

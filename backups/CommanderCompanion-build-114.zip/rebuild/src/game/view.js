import { rankTools, stepLabel } from './toolbox.js';
// What one viewer is allowed to see. The game screen renders only from this, and the host
// sends exactly this to remote devices, so hidden cards never leave the host.

import { phaseLabel } from '../engine/phase.js';
import { goadersOf } from '../engine/rules.js';
import { effectivePower, effectiveToughness } from '../engine/combat.js';
import { activePlayer, defOf, isCreature, isLand, playerById } from './helpers.js';
import {
  abilityRows, attackOptions, availableMana, blockOptions, playCheck, responseOptions, stackTop, timingBlock
} from './legal.js';
import { openingPenalty, mulliganInfo } from './setup.js';
import { playableFaces } from './ops.js';
import { castOptions, FACE_DOWN_ID, faceDownDefinition } from './casting.js';
import { gameAwards, statsView } from './stats.js';
import { coachFor } from './coach.js';
import { guidedActionsFor, guidedHintFor } from '../data/mechanics.js';

/** What a hand-resolved effect targeted, described for the resolution screen. */
function guidedTargetsView(game, picks = []) {
  return picks.map(t => {
    const p = playerById(game, t.id);
    if (p) return { id: t.id, kind: 'player', name: p.displayName, label: t.label };
    const s = (game.stack || []).find(x => x.id === t.id);
    if (s) return { id: t.id, kind: 'stack', name: s.name || s.label || 'Spell', label: t.label };
    for (const q of game.players) for (const zone of ['battlefield', 'graveyard', 'exile', 'hand']) {
      const c = (q.deck[zone] || []).find(x => x.instanceId === t.id);
      if (c) return { id: t.id, kind: zone === 'battlefield' ? 'permanent' : 'card', zone, name: defOf(game, c)?.name || 'Card', owner: q.displayName, label: t.label };
    }
    return { id: t.id, kind: 'gone', name: 'No longer there', label: t.label };
  });
}

/** The player the game is waiting on right now (used by single-device pass-and-play). */
export function actorId(game) {
  const f = game.flow;
  if (game.status === 'complete') return game.activePlayerId;
  if (f.stage === 'opening') return game.players.find(p => !f.opening[p.playerId]?.kept)?.playerId || game.activePlayerId;
  if (f.op?.decision) return f.op.decision.playerId;
  if (f.guided) return stackTop(game)?.controllerId || game.activePlayerId;
  if (f.priority?.holderId) return f.priority.holderId;
  if (f.blocks?.pending.length) return f.blocks.pending[0];
  if (f.discard) return f.discard.playerId;
  return game.activePlayerId;
}

function sick(game, card, def) {
  if (!isCreature(def)) return false;
  if ((def.keywords || []).some(k => String(k).toLowerCase() === 'haste') || /\bHaste\b/.test(def.oracleText || '')) return false;
  if ((card.temporaryEffects || []).some(e => e?.kind === 'keyword' && e.enabled !== false && String(e.keyword).toLowerCase() === 'haste')) return false;
  return Number(card.controlSinceTurn ?? card.enteredTurn ?? -1) >= Number(game.turnNumber);
}

function cardView(game, card, defs, extra = {}) {
  const def = defOf(game, card);
  if (def) defs[card.definitionId] = game.cardDefinitions[card.definitionId];
  const creature = isCreature(def);
  return {
    id: card.instanceId, def: card.definitionId, face: Number.isInteger(card.activeFaceIndex) ? card.activeFaceIndex : null,
    name: def?.name || 'Card', type: def?.typeLine || '', owner: card.ownerId, controller: card.controllerId,
    tapped: !!card.tapped, token: !!card.token, counters: { ...(card.counters || {}) },
    power: creature ? effectivePower(card, def, game) : null, toughness: creature ? effectiveToughness(card, def, game) : null,
    damage: Number(card.damageMarked || 0), attachedTo: card.attachedTo || null, pairedWith: card.pairedWith || null, attachments: [...(card.attachments || [])],
    chosen: card.chosenColor || card.chosenCreatureType || card.chosenCardName || null,
    ...extra
  };
}

/** Can this graveyard or exile card be cast now (flashback, escape, foretold, adventure)? */
/** "Return this card from your graveyard to the battlefield" (Reassembling Skeleton): offered from the graveyard. */
function graveAbilities(game, p, c, block) {
  const rows = abilityRows(game, p, c);
  return rows.length ? { abilities: rows.map(r => ({ id: r.ability.id, text: r.ability.text, cost: r.ability.cost, mana: false, legal: r.legal && !block, reason: block || r.reasons?.[0] || '' })) } : {};
}

function castable(game, p, c, block) {
  const options = castOptions(game, p, c, defOf(game, c));
  if (!options.length) return {};
  const best = options.find(o => o.legal) || options[0];
  return { playable: !!best.legal && !block, castLabel: best.label, reason: block || (best.legal ? '' : best.reasons?.[0] || '') };
}

function publicDecision(decision) {
  return { key: decision.key, kind: decision.kind, playerId: decision.playerId, title: decision.title, private: !!decision.private };
}

function addOptionDefs(game, decision, defs) {
  for (const o of [...(decision.options || []), ...(decision.cards || [])]) {
    if (o.definitionId && game.cardDefinitions[o.definitionId]) defs[o.definitionId] = game.cardDefinitions[o.definitionId];
  }
}

function promptFor(game, viewerId, defs, viewer) {
  const f = game.flow, name = id => playerById(game, id)?.displayName || 'another player';
  const waiting = (playerId, text) => ({ kind: 'waiting', playerId, text });
  if (game.status === 'complete') return { kind: 'complete' };
  if (f.stage === 'opening') {
    const mine = f.opening[viewerId];
    if (mine && !mine.kept) return { kind: 'opening', mulligans: mine.mulligans, bottom: openingPenalty(game, viewerId), rule: mulliganInfo(game.rulesConfig).label, canMulligan: mine.mulligans < 6 };
    const next = game.players.find(p => !f.opening[p.playerId]?.kept);
    return waiting(next?.playerId, `Waiting for ${name(next?.playerId)} to keep a hand.`);
  }
  if (f.proposal) {
    const pr = f.proposal, voters = game.players.filter(p => !p.eliminated && p.playerId !== pr.requesterId).map(p => p.playerId);
    const pending = voters.filter(id => pr.votes[id] === undefined);
    if (voters.includes(viewerId) && pr.votes[viewerId] === undefined) return { kind: 'proposal', id: pr.id, proposalKind: pr.kind, requesterId: pr.requesterId, requester: name(pr.requesterId), label: pr.label, detail: pr.detail, rules: pr.kind === 'rules' ? pr.data.rules : null };
    return waiting(pending[0], `Waiting for ${pending.map(name).join(', ')} to answer: ${pr.label}`);
  }
  if (f.correction && f.correction.challengerId !== viewerId) return waiting(f.correction.challengerId, `${name(f.correction.challengerId)} is preparing a correction to "${f.correction.playText}".`);
  if (f.vote) {
    const v = f.vote;
    return { kind: 'vote', requesterId: v.requesterId, label: v.label, reason: v.reason, canVote: !!viewerId && viewerId !== v.requesterId && v.votes[viewerId] === undefined, voted: v.votes[viewerId], canDecide: !!viewer.isHost };
  }
  if (f.op?.decision) {
    const d = f.op.decision;
    if (d.playerId === viewerId) { addOptionDefs(game, d, defs); return { kind: 'decision', decision: d }; }
    return { ...waiting(d.playerId, `Waiting for ${name(d.playerId)}: ${d.title || 'making a choice'}.`), decision: publicDecision(d) };
  }
  if (f.guided) {
    const top = stackTop(game);
    if (top?.controllerId === viewerId || viewer.isHost) {
      const text = top.guidedResolution?.oracleText || top.text || '';
      const cardName = (top.card?.definitionId || top.sourceDefinitionId) ? game.cardDefinitions?.[top.card?.definitionId || top.sourceDefinitionId]?.name || '' : '';
      return { kind: 'guided', stackId: top.id, name: top.name || top.label, cardName, ruling: game.storedOutcomes?.[cardName] || null, steps: [...(f.guided.steps || [])], text, notes: top.guidedResolution?.unsupported || [], controllerId: top.controllerId,
        targets: guidedTargetsView(game, top.guidedResolution?.targets), actions: guidedActionsFor(text), hint: guidedHintFor(text),
        // The toolbox: tools in suggested order, the staged steps, and the steps used for this card before.
        toolbox: { order: rankTools(`${(top.guidedResolution?.unsupported || []).join(' ')} ${text}`), staged: [...(f.guided.staged || [])], labels: (f.guided.staged || []).map(x => stepLabel(x)),
          remembered: game.rememberedOutcomes?.[cardName] || null, multi: game.deviceMode === 'multi-device', voters: game.players.filter(p => !p.eliminated && p.playerId !== top.controllerId).map(p => p.displayName) } };
    }
    return waiting(top?.controllerId, `Waiting for ${name(top?.controllerId)} to resolve ${top?.name || 'an effect'} by hand.`);
  }
  if (f.priority?.holderId) {
    const pr = f.priority, seconds = game.deviceMode === 'multi-device' ? Number(game.rulesConfig?.priorityTimer || 0) : 0;
    if (pr.holderId === viewerId) {
      const top = stackTop(game);
      return { kind: 'priority', reason: pr.reason, stackId: top?.id || null, deadline: seconds ? pr.since + seconds * 1000 : null };
    }
    return waiting(pr.holderId, `Waiting for ${name(pr.holderId)} to respond or pass.`);
  }
  if (f.blocks?.pending.length) {
    if (f.blocks.pending.includes(viewerId)) return { kind: 'blocks', rows: blockOptions(game, playerById(game, viewerId)) };
    return waiting(f.blocks.pending[0], `Waiting for ${name(f.blocks.pending[0])} to declare blockers.`);
  }
  if (f.discard) {
    if (f.discard.playerId === viewerId) return { kind: 'discard', need: f.discard.need };
    return waiting(f.discard.playerId, `Waiting for ${name(f.discard.playerId)} to discard.`);
  }
  if (game.activePlayerId === viewerId) return { kind: 'turn' };
  return waiting(game.activePlayerId, `${name(game.activePlayerId)}'s turn — ${phaseLabel(game.phase)}.`);
}

/**
 * viewer: { playerId (null for a judge/host display), isHost }
 * Returns a plain object that is safe to JSON-serialise and send to that viewer.
 */
export function buildView(game, viewer = {}, { canUndo = false, reversible = new Set(), judge = false } = {}) {
  const viewerId = viewer.playerId || null;
  const me = playerById(game, viewerId);
  const defs = {};
  const cs = game.combatState || {};
  const attacking = new Map((cs.attackers || []).map(a => [a.instanceId, a.defenderId]));
  const blocking = new Map();
  for (const row of Object.values(cs.blocks || {})) for (const x of row.assignments || []) blocking.set(x.blockerId, x.attackerId);
  const inCombat = ['declare-attackers', 'declare-blockers', 'combat-damage', 'end-combat'].includes(game.phase);
  const block = me ? timingBlock(game, me.playerId) : 'Watching';

  const players = game.players.map(p => {
    const own = p.playerId === viewerId;
    const mana = availableMana(game, p);
    const battlefield = p.deck.battlefield.map(c => {
      const def = defOf(game, c);
      const extra = { sick: sick(game, c, def), land: isLand(def), creature: isCreature(def) };
      if (c.realDefinitionId) {
        extra.faceDown = c.faceDownKind || 'morph';
        if (own || judge) { extra.realDef = c.realDefinitionId; extra.realName = game.cardDefinitions[c.realDefinitionId]?.name || ''; defs[c.realDefinitionId] = game.cardDefinitions[c.realDefinitionId]; }
      }
      if (c.castMode && c.castMode !== 'normal') extra.castMode = c.castMode;
      if (c.kicked) extra.kicked = Number(c.kickCount || 1);
      if (c.prepared) extra.prepared = game.cardDefinitions[c.definitionId]?.cardFaces?.[1]?.name || true;
      if (goadersOf(game, c, p.playerId).size) extra.goaded = true;
      if (inCombat && attacking.has(c.instanceId)) extra.attacking = attacking.get(c.instanceId);
      if (inCombat && blocking.has(c.instanceId)) extra.blocking = blocking.get(c.instanceId);
      if (own) {
        extra.abilities = abilityRows(game, p, c).map(r => ({ id: r.ability.id, text: r.ability.text, cost: r.ability.cost, mana: r.ability.manaAbility, legal: r.legal && !block, reason: block || r.reasons[0] || '' }));
      }
      else if (me && !me.eliminated) {
        // Someone else's permanent: the abilities any player may activate (Xantcha, Feral Hydra, Warmonger …).
        const rows = abilityRows(game, me, c);
        if (rows.length) extra.abilities = rows.map(r => ({ id: r.ability.id, text: r.ability.text, cost: r.ability.cost, mana: false, legal: r.legal && !block, reason: block || r.reasons[0] || '' }));
      }
      return cardView(game, c, defs, extra);
    });
    const row = {
      playerId: p.playerId, name: p.displayName, seat: p.seat, color: p.color, matId: p.matId || null, advice: p.settings?.advice !== false,
      life: p.life, poison: Number(p.poison || 0), eliminated: !!p.eliminated, eliminationReason: p.eliminationReason || null,
      statuses: [...(p.statuses || [])],
      // Player-level effects with an end (the status light shows these yellow): until: 'turn' | 'next-turn'.
      effects: [
        ...(p.noLandPlayTurn === game.turnNumber ? [{ text: "Can't play lands this turn", until: 'turn', harmful: true }] : []),
        ...((p.skipNextUntap || []).length ? [{ text: 'Skips their next untap', until: 'next-turn', harmful: true }] : []),
        ...(Number(p.skipTurns || 0) > 0 ? [{ text: `Skips their next ${Number(p.skipTurns) === 1 ? 'turn' : `${p.skipTurns} turns`}`, until: 'next-turn', harmful: true }] : [])
      ],
      emblems: (p.emblems || []).map(e => ({ id: e.id, text: e.text, source: e.source || '' })),
      counters: Object.fromEntries(Object.entries(p.counters || {}).filter(([k, v]) => Number(v) > 0 && !/ThisTurn$|^damageDealt$|^failedDraws$/.test(k))),
      commanderDamage: { ...(p.commanderDamage || {}) },
      commanders: (p.commanders || []).map(c => {
        if (game.cardDefinitions[c.cardId]) defs[c.cardId] = game.cardDefinitions[c.cardId];
        return { id: c.id, def: c.cardId, name: game.cardDefinitions[c.cardId]?.name || 'Commander', tax: game.rulesConfig?.commanderTax === false ? 0 : Number(c.commanderTax || 0), zone: c.zone, instanceId: p.deck.commandZone.find(x => x.definitionId === c.cardId)?.instanceId || null };
      }),
      mana, handCount: p.deck.hand.length, libraryCount: p.deck.remainingLibrary.length,
      battlefield,
      graveyard: p.deck.graveyard.map(c => cardView(game, c, defs, own ? { ...castable(game, p, c, block), ...graveAbilities(game, p, c, block) } : {})),
      exile: p.deck.exile.map(c => {
        if ((c.foretold || c.hiddenExile) && !own && !judge) {
          defs[FACE_DOWN_ID] = faceDownDefinition();
          return { id: c.instanceId, def: FACE_DOWN_ID, face: null, name: c.hiddenExile ? 'Face-down card' : 'Foretold card', type: 'Face down', owner: c.ownerId, controller: c.ownerId, tapped: false, token: false, counters: {}, power: null, toughness: null, damage: 0, attachedTo: null, attachments: [], chosen: null, foretold: true };
        }
        return cardView(game, c, defs, { ...(own ? castable(game, p, c, block) : {}), ...(c.foretold ? { foretold: true } : {}), ...(c.onAdventure ? { onAdventure: true } : {}) });
      }),
      dungeon: p.dungeon ? { ...p.dungeon } : null, dungeonsCompleted: Number(p.dungeonsCompleted || 0),
      command: p.deck.commandZone.map(c => {
        const extra = {};
        if (own) { const check = playCheck(game, p, c); extra.playable = check.legal && !block; extra.reason = block || check.reasons[0] || ''; }
        return cardView(game, c, defs, extra);
      }),
      hand: null,
      landsPlayed: Number(p.counters?.landsPlayedThisTurn || 0),
      stats: statsView(p),
      deckName: p.deck.sourceName || ''
    };
    if (own) {
      row.hand = p.deck.hand.map(c => {
        const base = game.cardDefinitions[c.definitionId];
        const faces = playableFaces(base);
        const checks = faces.map(i => playCheck(game, p, c, i));
        const best = checks.find(x => x.legal) || checks[0];
        const handAbility = abilityRows(game, p, c);
        return cardView(game, c, defs, {
          playable: !!best?.legal && !block, reason: block || best?.reasons?.[0] || '', land: isLand(best?.def),
          instant: /\bInstant\b/i.test(best?.def?.typeLine || '') || /\bFlash\b/.test(best?.def?.oracleText || ''),
          abilities: handAbility.map(r => ({ id: r.ability.id, text: r.ability.text, cost: r.ability.cost, mana: !!r.ability.manaAbility, legal: r.ability.manaAbility ? !block : r.legal && !block, reason: block || r.reasons?.[0] || '' }))
        });
      });
    }
    return row;
  });

  const stack = (game.stack || []).map(x => {
    const id = x.sourceDefinitionId || x.card?.definitionId;
    if (id && game.cardDefinitions[id]) defs[id] = game.cardDefinitions[id];
    return { id: x.id, kind: x.kind, name: x.name || game.cardDefinitions[id]?.name || x.label, label: x.label, text: x.text || x.abilityText || '', controllerId: x.controllerId, def: id || null, face: x.card?.activeFaceIndex ?? null, guided: !!x.guidedResolution };
  });

  // Prompts that give host powers (deciding votes, resolving anyone's card by hand) go to the judge only.
  const prompt = promptFor(game, viewerId, defs, { ...viewer, isHost: judge });
  const active = activePlayer(game);
  const isTurn = prompt.kind === 'turn';
  const view = {
    gameId: game.gameId, mode: game.mode, deviceMode: game.deviceMode, status: game.status, stage: game.flow.stage,
    turn: game.turnNumber, phase: game.phase, phaseLabel: phaseLabel(game.phase), activePlayerId: game.activePlayerId, dayNight: game.dayNight || null,
    you: viewerId, isHost: !!viewer.isHost, isJudge: judge,
    canEdit: game.mode === 'freeplay' || judge || (!!game.flow.correction && game.flow.correction.challengerId === viewerId) || (prompt.kind === 'guided' && prompt.controllerId === viewerId),
    canForce: game.mode === 'freeplay',
    canUndo: canUndo && (judge || game.mode === 'freeplay'),
    // Players without a judge: ask the table to undo (if the rules allow it) or challenge a play.
    canAskUndo: !judge && game.mode !== 'freeplay' && game.deviceMode === 'multi-device' && !!me && !me.eliminated,
    undoRule: !!game.rulesConfig?.undo,
    canChallenge: !judge && game.mode !== 'freeplay' && game.deviceMode === 'multi-device' && !game.hasJudge && !!me && !me.eliminated,
    correction: game.flow.correction ? { mine: game.flow.correction.challengerId === viewerId, challengerId: game.flow.correction.challengerId, playText: game.flow.correction.playText } : null,
    lastPlay: (game.plays || [])[0] ? { text: game.plays[0].text, turn: game.plays[0].turn } : null,
    notices: (game.notices || []).filter(n => n.playerId === viewerId).map(n => ({ id: n.id, text: n.text })),
    rules: { ...game.rulesConfig }, players, stack, prompt,
    // The judge's record: every play with a legality verdict. Only the host (or anyone in Free Play) can reverse.
    legality: { plays: (game.plays || []).length, illegal: (game.plays || []).filter(p => p.verdict === 'illegal').length },
    plays: judge || game.mode === 'freeplay' ? (game.plays || []).slice(0, 150).map(p => ({ ...p, reasons: [...p.reasons], reversible: reversible.has(p.id) })) : null,
    log: (game.log || []).slice(0, 150).map(e => ({ id: e.id, text: e.text, turn: e.turn, type: e.type || '', playerId: e.playerId || null })),
    chat: (game.chat || []).slice(-80),
    winner: game.winner || null, result: game.result || null,
    awards: game.status === 'complete' ? gameAwards(game) : [],
    actions: {
      nextPhase: isTurn && ['precombat-main', 'combat', 'begin-combat', 'postcombat-main'].includes(game.phase),
      endTurn: isTurn && ['precombat-main', 'combat', 'begin-combat', 'postcombat-main'].includes(game.phase),
      attack: isTurn && ['combat', 'begin-combat'].includes(game.phase) && me ? attackOptions(game, me) : null,
      respond: prompt.kind === 'priority' && me ? (() => { const r = responseOptions(game, me); return { cards: r.cards.map(c => c.instanceId), abilities: r.abilities.map(c => c.instanceId) }; })() : null
    },
    defs
  };
  view.coach = coachFor(game, view, me, active);
  return view;
}

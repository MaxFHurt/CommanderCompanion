// Turns the effect compiler's "requirements" (targets, modes, numbers, card choices) into
// decisions a player answers, and collects the answers into effect bindings.
//
// Nothing here changes game state. An operation asks for what it needs with `ask(key, build)`;
// if the answer is not recorded yet, `ask` throws a Need and the controller shows the decision.
// When the answer arrives the operation is simply run again from the top.

import { gatherCatalogRequirement, cardFitsWords } from '../engine/effects-catalog.js';
import { CREATURE_TYPES } from '../data/creature-types.js';
import { COLOR_NAMES, defOf, opponentsOf, alivePlayers, playerById, plural, turnOrderFrom } from './helpers.js';
import { cardHasKeyword, effectivePower, effectiveToughness } from '../engine/combat.js';
import { cardMatchesFilter, resolveAmount, limitOf, conditionHolds, exiledWith, locateCardInGame } from '../engine/effects.js';

const COLOR_WORDS = { white: 'W', blue: 'U', black: 'B', red: 'R', green: 'G' };

/** "Protection from …" qualities on a permanent (printed, granted by effects, or by anthems). */
export function protectionsOf(game, card) {
  const d = defOf(game, card), out = new Set();
  const texts = [String(d?.oracleText || ''), ...(card?.temporaryEffects || []).filter(e => e?.kind === 'keyword').map(e => String(e.keyword || ''))];
  for (const t of texts) for (const m of t.matchAll(/protection from ([a-z ,]+?)(?:\.|\n|$| and from)/gi)) {
    for (const part of m[1].split(/,| and | or /)) {
      const w = part.trim().toLowerCase().replace(/^the color of your choice$/, '');
      if (COLOR_WORDS[w]) out.add(COLOR_WORDS[w]);
      else if (/^everything$/.test(w)) out.add('everything');
      else if (/^all colors$/.test(w)) ['W', 'U', 'B', 'R', 'G'].forEach(c => out.add(c));
      else if (/^(creatures|artifacts|enchantments|instants|sorceries|planeswalkers|multicolored|monocolored|colorless)$/.test(w)) out.add(w);
    }
  }
  return out;
}

/** Does a source (its colors and types) have a quality the permanent is protected from? */
export function protectedFrom(game, card, source) {
  if (!source) return false;
  const p = protectionsOf(game, card);
  if (!p.size) return false;
  if (p.has('everything')) return true;
  const colors = source.colors || [], type = String(source.typeLine || '').toLowerCase();
  if (colors.some(c => p.has(c))) return true;
  if (p.has('multicolored') && colors.length > 1) return true;
  if (p.has('monocolored') && colors.length === 1) return true;
  if (p.has('colorless') && !colors.length) return true;
  return ['creature', 'artifact', 'enchantment', 'instant', 'sorcery', 'planeswalker'].some(k => p.has(`${k === 'sorcery' ? 'sorceries' : `${k}s`}`) && type.includes(k));
}

/** May `player` target this permanent with a spell or ability from `source`? (hexproof, shroud, protection) */
export function canTarget(game, card, player, source = null) {
  const d = defOf(game, card);
  if (cardHasKeyword(card, d, 'Shroud', game)) return false;
  const opponent = (card.controllerId || card.ownerId) !== player?.playerId;
  if (opponent && cardHasKeyword(card, d, 'Hexproof', game)) {
    // "Hexproof from [color]" only stops sources of that color.
    const from = String(d?.oracleText || '').match(/hexproof from (white|blue|black|red|green|monocolored|multicolored)/i);
    if (!from) return false;
    const w = from[1].toLowerCase(), colors = source?.colors || [];
    if (COLOR_WORDS[w] ? colors.includes(COLOR_WORDS[w]) : w === 'multicolored' ? colors.length > 1 : colors.length === 1) return false;
  }
  // "Hexproof from blue" given until end of turn (Veil of Summer).
  if (opponent && (card.temporaryEffects || []).some(e => e?.kind === 'keyword' && e.enabled !== false && (m => m && (source?.colors || []).includes(COLOR_WORDS[m[1]]))(String(e.keyword || '').toLowerCase().match(/^hexproof from (white|blue|black|red|green)$/)))) return false;
  return !protectedFrom(game, card, source);
}

/** Players with "You have hexproof/shroud" (Leyline of Sanctity, True Believer) can't be targeted by opponents / anyone. */
export function canTargetPlayer(game, target, player, source = null) {
  if (target.protectionFromEverything) return false;
  // Veil of Summer: "You … gain hexproof from blue and from black until end of turn."
  if (target.playerId !== player?.playerId && target.hexproofFrom?.turn === game?.turnNumber && (source?.colors || []).some(c => target.hexproofFrom.colors.includes(c))) return false;
  if (target.playerId !== player?.playerId && target.hexproofTurn === game?.turnNumber) return false;   // Dawn's Truce
  for (const c of target.deck?.battlefield || []) {
    const t = String(defOf(game, c)?.oracleText || '');
    if (/\bYou have shroud\b/i.test(t)) return false;
    if (target.playerId !== player?.playerId && /\bYou have hexproof\b/i.test(t)) return false;
  }
  return true;
}

export class Need {
  constructor(spec) { this.spec = spec; }
}

/** Requirement kinds answered while casting/activating (targets are locked in then). */
const CAST_TIME = new Set(['linked-target', 'target', 'player', 'graveyard-target', 'stack-target', 'multi-target', 'per-opponent-up-to-one', 'number', 'distribute', 'b101-gy-cards']);

export function splitRequirements(requirements = []) {
  const cast = [], resolve = [];
  for (const req of requirements) (CAST_TIME.has(req.kind) ? cast : resolve).push(req);
  return { cast, resolve };
}

export function makeAsk(op) {
  return (key, build) => {
    if (Object.prototype.hasOwnProperty.call(op.answers, key)) return op.answers[key];
    throw new Need({ key, ...build() });
  };
}

function cardOption(game, card, owner, sub = '') {
  const d = defOf(game, card);
  return {
    id: card.instanceId,
    label: d?.name || 'Card',
    sub: sub || `${owner?.displayName || ''}${d?.typeLine ? ` — ${d.typeLine}` : ''}`,
    instanceId: card.instanceId,
    definitionId: card.definitionId
  };
}

function playerOption(player) {
  return { id: player.playerId, label: player.displayName, sub: `Player — life ${player.life}`, playerId: player.playerId };
}

function isCombatParticipant(game, instanceId) {
  const cs = game.combatState || {};
  if ((cs.attackers || []).some(a => a.instanceId === instanceId)) return true;
  return Object.values(cs.blocks || {}).some(row => (row?.assignments || []).some(x => x.blockerId === instanceId));
}

/** The card-type words of a target phrase: all of them ("artifact creature"), or any one with "or" ("artifact, enchantment, or nonbasic land"). */
const TYPE_WORDS = ['creature', 'artifact', 'enchantment', 'planeswalker', 'land', 'battle', 'equipment', 'vehicle', 'instant', 'sorcery', 'forest', 'island', 'swamp', 'mountain', 'plains'];
function typesFit(typeLine, scope) {
  const t = String(typeLine || '').toLowerCase();
  const words = TYPE_WORDS.filter(w => new RegExp(`(?:^|[^a-z])${w}s?\\b`).test(scope.replace(/\bnon\w+/g, '')));
  if (words.length) {
    const any = /\bor\b|and\/or/.test(scope);
    if (any ? !words.some(w => t.includes(w)) : !words.every(w => t.includes(w))) return false;
  }
  for (const m of scope.matchAll(/\bnon(creature|artifact|enchantment|land|basic|legendary|token)\b/g)) if (m[1] !== 'token' && t.includes(m[1])) return false;
  if (/\blegendary\b/.test(scope) && !t.includes('legendary')) return false;
  if (/(?:^|[^n])\bbasic\b/.test(scope) && !/\bbasic\b/.test(t)) return false;
  if (/\bpermanent card\b/.test(scope) && /instant|sorcery/.test(t)) return false;
  return true;
}
function manaValueFits(def, scope) {
  const m = scope.match(/with mana value (\d+) or (less|greater)/);
  if (!m) return true;
  const v = Number(def?.manaValue ?? def?.cmc ?? 0);
  return m[2] === 'less' ? v <= Number(m[1]) : v >= Number(m[1]);
}


/** Descriptor words of a target phrase (build 110): "red or green creature", "nonblack creature", "non-Wall creature", "tapped creature",
 *  "snow land", "creature without flying", "creature with flying". Colour and type words used to be ignored. */
const KW_WORDS = 'flying|reach|trample|haste|vigilance|deathtouch|lifelink|menace|first strike|double strike|hexproof|shroud|indestructible|defender|flash';
function descriptorFits(game, card, def, scope) {
  const m = scope.match(/\btarget (?:another |other )?(.*?)\b(?:creature|permanent|artifact|enchantment|land|planeswalker|battle)s?\b/);
  const colors = def?.colors || [], t = String(def?.typeLine || '').toLowerCase(), pre = (m ? m[1] : '').trim();
  if (pre) {
    const words = pre.split(/\s+/).filter(w => w && w !== 'or' && w !== 'and');
    const want = words.filter(w => COLOR_WORDS[w]).map(w => COLOR_WORDS[w]);
    if (want.length && !want.some(c => colors.includes(c))) return false;
    for (const w of words) {
      const n = w.match(/^non-?(white|blue|black|red|green)$/);
      if (n && colors.includes(COLOR_WORDS[n[1]])) return false;
      const sn = w.match(/^non-?([a-z]+)$/);
      if (sn && !n && !/^(?:token|land|creature|artifact|enchantment|basic|legendary|planeswalker|commander|permanent|human)$/.test(sn[1]) && new RegExp(`\\b${sn[1]}s?\\b`).test(t.split('—')[1] || '')) return false;
      const pt = w.match(/^(\d+)\/(\d+)$/);   // "target 1/1 creature" (build 111)
      if (pt && (Number(effectivePower(card, def, game)) !== Number(pt[1]) || Number(effectiveToughness(card, def, game)) !== Number(pt[2]))) return false;
      if (w === 'tapped' && !card.tapped) return false;
      if (w === 'untapped' && card.tapped) return false;
      if (w === 'colorless' && colors.length) return false;
      if (w === 'multicolored' && colors.length < 2) return false;
      if (w === 'snow' && !/\bsnow\b/.test(t)) return false;
    }
    const subs = pre.match(/non-([a-z]+)/g);
    if (subs) for (const x of subs) { const sn = x.slice(4); if (!['token','land','creature','artifact','enchantment','basic','legendary','white','blue','black','red','green'].includes(sn) && new RegExp(`\\b${sn}s?\\b`).test(t.split('—')[1] || '')) return false; }
  }
  const wo = scope.match(new RegExp(`\\bwithout (${KW_WORDS})\\b`));
  if (wo && cardHasKeyword(card, def, wo[1], game)) return false;
  const wi = scope.match(new RegExp(`\\bwith (${KW_WORDS})\\b`));
  if (wi && !cardHasKeyword(card, def, wi[1], game)) return false;
  return true;
}


/** "with power less than or equal to this creature's power" / "with mana value less than or equal to Carmen's power": a limit set by the source's own stat (build 110). */
let LIMIT_BINDINGS = null;   // the choices and event data so far, for limits such as "less than or equal to that spell's mana value"
function sourceLimitFits(game, card, def, scope, source, player = null) {
  const at = scope.search(/\bwith (?:mana value|power|toughness) (?:less|greater) than/);
  if (at < 0) return true;
  const L = limitOf(scope.slice(at));
  if (!L) return false;
  let lim;
  if (L.expr.kind === 'b110-source-stat') {
    if (!source) return false;
    const sd = defOf(game, source);
    lim = Number(L.expr.stat === 'power' ? effectivePower(source, sd, game) : effectiveToughness(source, sd, game));
  } else {
    const who = player?.playerId || source?.controllerId || game.activePlayerId;
    lim = Number(resolveAmount(game, who, L.expr, { ...(LIMIT_BINDINGS || {}), sourceId: source?.instanceId || null }) || 0);
  }
  const v = L.stat === 'mana value' ? Number(def?.manaValue ?? def?.cmc ?? 0) : L.stat === 'power' ? Number(effectivePower(card, def, game)) : Number(effectiveToughness(card, def, game));
  return L.less ? (L.orEqual ? v <= lim : v < lim) : (L.orEqual ? v >= lim : v > lim);
}

/** Does a battlefield card match a target phrase such as "target artifact or enchantment you control"? */
function matchesPermanentScope(game, card, scope, source = null, player = null) {
  const fullScope = scope;
  scope = scope.replace(/\s*\bwith (?:mana value|power|toughness) (?:less|greater) than.*$/, '');   // the limit's own words ("Islands you control") say nothing about the target
  const def = defOf(game, card), t = String(def?.typeLine || '');
  if (!typesFit(t, scope)) return false;
  if (/nonland permanent/.test(scope) && /Land/i.test(t)) return false;
  if (!descriptorFits(game, card, def, scope)) return false;
  if (!sourceLimitFits(game, card, def, fullScope, source, player)) return false;
  if (/\bthat attacked (?:or blocked )?this turn\b/.test(scope) && card.attackedTurn !== game.turnNumber && !(/or blocked/.test(scope) && card.blockedTurn === game.turnNumber)) return false;   // Hexhaven Dueling Arena, Divine Verdict-style limits
  if (/attacking or blocking/.test(scope) && !isCombatParticipant(game, card.instanceId)) return false;
  else if (/\battacking\b/.test(scope) && !(game.combatState?.attackers || []).some(a => a.instanceId === card.instanceId)) return false;
  if (/\benchanted\b/.test(scope) && !(game.players || []).some(q => (q.deck?.battlefield || []).some(x => x.attachedTo === card.instanceId && /\bAura\b/.test(defOf(game, x)?.typeLine || '')))) return false;
  if (/with a counter on it/.test(scope) && !Object.values(card.counters || {}).some(v => Number(v) > 0)) return false;
  if (/\bnontoken\b/.test(scope) && card.token) return false;
  if (/\btoken\b/.test(scope.replace(/\bnontoken\b/g, '')) && !card.token) return false;
  if (!manaValueFits(def, scope)) return false;
  // "target Goblin creature", "target Zombie you control": a creature type in the target.
  const sub = scope.match(/target (?:another |other )?([a-z]+(?:-[a-z]+)?) (?:creature|you control|an opponent controls)/);   // build 112: Assembly-Worker
  if (sub && !/^(attacking|blocking|tapped|untapped|nontoken|token|legendary|nonlegendary|basic|nonbasic|white|blue|black|red|green|colorless|multicolored|monocolored|noncreature|nonland|nonartifact|nonblack|nonwhite|nonblue|nonred|nongreen|artifact|enchantment|land|creature|planeswalker|battle|permanent|equipped|enchanted|modified|face-down|other|another|unblocked|blocked)$/.test(sub[1])
    && !new RegExp(`\\b${sub[1]}s?\\b`, 'i').test(t.split('—')[1] || '') && !/\bChangeling\b/.test(def?.oracleText || '')) return false;
  // "target Wolf or Werewolf creature" (build 111): either creature type
  { const s2 = scope.match(/target (?:another |other )?([a-z]+) or ([a-z]+) creature/);
    if (s2 && ![s2[1], s2[2]].some(w => /^(attacking|blocking|tapped|untapped|nontoken|token|legendary|white|blue|black|red|green|colorless|multicolored|artifact|enchantment|land|creature|planeswalker|battle|permanent|nonland|noncreature|nonartifact)$/.test(w))
      && ![s2[1], s2[2]].some(w => new RegExp(`\\b${w}s?\\b`, 'i').test(t.split('—')[1] || '')) && !/\bChangeling\b/.test(def?.oracleText || '')) return false; }
  // Yasova Dragonclaw: "with power less than Yasova Dragonclaw's power" (this card's power, as it is now)
  if (/with power less than [a-z' ,-]*'s power/.test(scope)) { const sp = source ? Number(effectivePower(source, defOf(game, source), game)) : 0; if (!(Number(effectivePower(card, def, game)) < sp)) return false; }
  const pw = scope.match(/with power (\d+) or (less|greater)/);
  if (pw) { const p = Number(effectivePower(card, def, game)); if (pw[2] === 'less' ? p > Number(pw[1]) : p < Number(pw[1])) return false; }
  return true;
}

/** Is `card` blocking `source`, or blocked by it? */
function blockedPair(game, source, card) {
  if (!source) return false;
  return Object.values(game.combatState?.blocks || {}).some(b => (b?.assignments || []).some(x => (x.attackerId === source.instanceId && x.blockerId === card.instanceId) || (x.blockerId === source.instanceId && x.attackerId === card.instanceId)));
}

/** Legal choices for a single-target style requirement. */
export function candidatesFor(game, req, player, source = null) {
  const scope = String(req?.scope || '').toLowerCase();
  const out = [];
  if (req.kind === 'player') {
    const rows = scope === 'opponent' ? opponentsOf(game, player.playerId) : alivePlayers(game);
    return rows.filter(q => req.notTargeted || canTargetPlayer(game, q, player, source)).map(playerOption);   // "an opponent" (not "target") ignores hexproof
  }
  if (req.kind === 'linked-target') {
    // "target card exiled with this permanent" (607.2a): only what the source itself exiled and still holds in exile.
    const sid = req.sourceId || source?.instanceId;
    for (const c of sid ? exiledWith(game, sid) : []) {
      const d = defOf(game, c);
      if (req.filter && !cardFitsWords(d, req.filter)) continue;
      out.push(cardOption(game, c, game.players.find(q => q.playerId === c.ownerId) || player, 'Exiled with this permanent'));
    }
    return out;
  }
  if (req.kind === 'graveyard-target') {
    const owners = /your/.test(scope) ? [player] : game.players;
    for (const q of owners) for (const c of q.deck.graveyard || []) {
      const def = defOf(game, c), t = String(def?.typeLine || '');
      if (!typesFit(t, scope.replace(/\bin (?:your|a|target player'?s) graveyard\b/, '').replace(/\s*\bwith (?:mana value|power|toughness) (?:less|greater) than.*$/, '')) || !manaValueFits(def, scope)) continue;
      if (!sourceLimitFits(game, c, def, scope, source, player) || !descriptorFits(game, c, def, scope)) continue;
      if (/\banother\b/.test(scope) && c.instanceId === (LIMIT_BINDINGS?.eventCard || source?.instanceId)) continue;   // "another target card": not the card that triggered this (a creature that just died)
      out.push(cardOption(game, c, q, `${q.displayName}'s graveyard — ${t}`));
    }
    return out;
  }
  if (req.kind === 'stack-target') {
    // "target noncreature spell", "target instant or sorcery spell": spellFilter is "noncreature" or "instant|sorcery".
    const fits = x => {
      if (!req.spellFilter) return true;
      const def = defOf(game, x.card), type = String(def?.typeLine || '').toLowerCase();
      const color = { white: 'W', blue: 'U', black: 'B', red: 'R', green: 'G' };
      return req.spellFilter.split('|').some(w => w === 'notfromhand' ? !!x.fromZone && x.fromZone !== 'hand' : w.startsWith('mv>=') ? Number(def?.manaValue ?? def?.cmc ?? 0) >= Number(w.slice(4)) : w.startsWith('mv<=') ? Number(def?.manaValue ?? def?.cmc ?? 0) <= Number(w.slice(4)) : w.startsWith('mv=') ? Number(def?.manaValue ?? def?.cmc ?? 0) === (w.slice(3) === 'X' ? Number(LIMIT_BINDINGS?.X ?? 0) : Number(w.slice(3)))   // (build 111: "mana value X")
        : color[w] ? (def?.colors || []).includes(color[w]) : w.startsWith('non') ? !type.includes(w.slice(3)) : type.includes(w));
    };
    return (game.stack || [])
      .filter(x => req.scope !== 'spell' || x.kind === 'spell' || x.kind === 'spell-copy')
      .filter(x => req.scope !== 'ability' || x.kind === 'ability' || x.kind === 'trigger')
      .filter(x => !req.abilityKind || x.kind === req.abilityKind)
      .filter(x => !req.yours || x.controllerId === player.playerId)
      .filter(x => !req.notYours || x.controllerId !== player.playerId)
      // Rebuff the Wicked: "spell that targets a permanent you control" (its chosen targets include one of yours)
      .filter(x => !req.targetsYours || Object.values(x.effectBindings || {}).flat().some(id => typeof id === 'string' && (player.deck?.battlefield || []).some(c => c.instanceId === id)))
      // Build 110: "that targets you / a creature / a permanent you control" (what its chosen targets are)
      .filter(x => {
        if (!req.targetsFilter) return true;
        const ids = Object.values(x.effectBindings || {}).flat().filter(id => typeof id === 'string');
        if (req.targetsFilter === 'you') return ids.includes(player.playerId);
        if (req.targetsFilter === 'yours') return ids.some(id => (player.deck?.battlefield || []).some(c => c.instanceId === id));
        return ids.some(id => game.players.some(q => (q.deck?.battlefield || []).some(c => c.instanceId === id && /\bCreature\b/.test(defOf(game, c)?.typeLine || ''))));
      })
      .filter(x => !req.spellFilter || ((x.kind === 'spell' || x.kind === 'spell-copy') && fits(x)) || (req.orAbility && (x.kind === 'ability' || x.kind === 'trigger')))
      .map(x => ({ id: x.id, label: x.label || 'Stack object', sub: playerById(game, x.controllerId)?.displayName || x.kind, definitionId: x.sourceDefinitionId }));
  }
  if (req.kind === 'target' || req.kind === 'choose-permanent') {
    const targeted = req.kind === 'target';   // a plain choice ("a creature you control") ignores hexproof and shroud
    if (targeted && /any target|any other target|target player|target opponent/.test(scope)) {
      for (const q of alivePlayers(game)) {
        if (/opponent/.test(scope) && q.playerId === player.playerId) continue;
        if (!canTargetPlayer(game, q, player, source)) continue;
        out.push(playerOption(q));
      }
    }
    // "target spell or creature" (Unsubstantiate, Venser, Fatehold Charm): spells on the stack can be chosen too.
    if (targeted && /^target spell or /.test(scope)) for (const x of game.stack || []) if ((x.kind === 'spell' || x.kind === 'spell-copy') && x.id !== source?.stackId && x.card?.instanceId !== source?.instanceId) {
      const mvMin = scope.match(/with mana value (\d+) or greater/), sd = defOf(game, x.card);
      if (mvMin && Number(sd?.manaValue ?? sd?.cmc ?? 0) < Number(mvMin[1])) continue;   // Divide by Zero
      if (/an opponent controls|you don'?t control/.test(scope) && x.controllerId === player.playerId) continue;   // Press the Enemy
      if (/you control\b/.test(scope) && !/an opponent controls|you don'?t control/.test(scope) && x.controllerId !== player.playerId) continue;
      out.push({ id: x.id, label: x.label || 'Spell', sub: `${playerById(game, x.controllerId)?.displayName || ''} — spell on the stack`, definitionId: x.sourceDefinitionId }); }
    if (/any target|any other target|creature|permanent|artifact|enchantment|planeswalker|land|battle|equipment/.test(scope)) {
      const anyTarget = /any (?:other )?target/.test(scope);
      const defending = /defending player controls/.test(scope);   // "target creature defending player controls": the player this attacker is attacking
      const defenderId = defending && source ? (game.combatState?.attackers || []).find(a => a.instanceId === source.instanceId)?.defenderId : null;
      const ownerScope = scope.replace(/\bwith (?:mana value|power|toughness) (?:less|greater) than.*$/, '');   // "the number of Islands you control" is not who controls the target
      const dontControl = defending || /you don'?t control|an opponent controls|your opponents control/.test(ownerScope);
      const owners = defenderId && alivePlayers(game).some(q => q.playerId === defenderId) ? alivePlayers(game).filter(q => q.playerId === defenderId) : dontControl ? opponentsOf(game, player.playerId) : /you control|your /.test(ownerScope) ? [player] : alivePlayers(game);
      for (const q of owners) for (const c of q.deck.battlefield || []) {
        if (anyTarget) {
          if (!/Creature|Planeswalker|Battle/i.test(defOf(game, c)?.typeLine || '')) continue;
        } else if (!matchesPermanentScope(game, c, scope, source, player)) continue;
        if (/blocking or blocked by it/.test(scope) && !blockedPair(game, source, c)) continue;   // Steadfast Armasaur: a creature blocking it or blocked by it
        if (/\bit'?s blocking\b/.test(scope) && !Object.values(game.combatState?.blocks || {}).some(b => (b?.assignments || []).some(x => x.blockerId === source?.instanceId && x.attackerId === c.instanceId))) continue;   // Wall of Vipers: the creature this one is blocking
        if (targeted && !canTarget(game, c, player, source)) continue;
        out.push(cardOption(game, c, q));
      }
    }
  }
  return out;
}

function battlefieldRows(game, owner, filter = 'permanent') {
  const f = String(filter || 'permanent').toLowerCase();
  return (owner.deck.battlefield || [])
    .filter(c => {
      const t = String(defOf(game, c)?.typeLine || '').toLowerCase();
      if (f === 'permanent') return true;
      if (f === 'artifact or enchantment') return /artifact|enchantment/.test(t);
      if (/[|]| or /.test(f)) return cardMatchesFilter(game, c, f);
      return t.includes(f);
    })
    .map(c => cardOption(game, c, owner));
}

function requirementAmount(req, bindings) {
  if (typeof req.amount === 'number') return req.amount;
  if (String(req.amount).toUpperCase() === 'X') return Number(bindings.X || 0);
  return Number(req.amount || 1);
}

/**
 * Ask for every requirement in `reqs` and write the answers into `bindings`.
 * `ctx` = { player (the controller of the effect), sourceName, cancellable }.
 */
export function gatherRequirements(game, ctx, reqs, bindings, ask, prefix = 'req') {
  LIMIT_BINDINGS = bindings;
  // The source passed in is often only its colours/type/name; limits set by its own power or counters ("less than or equal to this creature's power") need the card itself.
  if (ctx.source && !ctx.source.instanceId && bindings.sourceId) {
    const hit = locateCardInGame(game, bindings.sourceId);
    if (hit) ctx = { ...ctx, source: { ...hit.card, colors: ctx.source.colors, typeLine: ctx.source.typeLine, name: ctx.source.name } };
  }
  const { player, sourceName = 'Effect' } = ctx;
  const cancellable = ctx.cancellable !== false;
  const base = { playerId: player.playerId, cancellable, source: sourceName };

  reqs.forEach((req, index) => {
    const key = `${prefix}:${index}:${req.kind}`;
    const title = `${sourceName} — ${req.label || 'Choose'}`;
    // A choice that belongs to one half of "If <condition>, instead …": asked only when that half runs.
    if (req.onlyIf) { const holds = conditionHolds(game, player.playerId, req.onlyIf, bindings); if (req.onlyIf.negate ? holds : !holds) return; }
    // "Scry X / up to X targets …, where X is the number of …": X is counted now, as the choice is made (it was 0);
    // it is counted again as the effect resolves.
    if (req.xExpr != null) bindings.X = Math.max(0, Number(resolveAmount(game, player.playerId, req.xExpr, { ...bindings, sourceId: bindings.sourceId || ctx.source?.instanceId || null })) || 0);

    if (gatherCatalogRequirement(game, ctx, req, bindings, ask, key, title, base, { defOf, cardOption, candidatesFor, opponentsOf, alivePlayers, playerById, plural, gather: gatherRequirements })) return;
    if (req.kind === 'number') {
      const min = Number(req.min || 0), max = Number(req.max ?? 99);
      bindings[req.bind] = ask(key, () => ({ ...base, kind: 'number', title, prompt: req.label || 'Choose a number', min, max }));
      return;
    }
    if (req.kind === 'color') {
      const colors = ['W', 'U', 'B', 'R', 'G', ...(req.includeColorless ? ['C'] : [])].filter(c => !(req.exclude || []).includes(c));
      bindings[req.bind] = ask(key, () => ({
        ...base, kind: 'choose-one', title, prompt: req.label || 'Choose a color',
        options: colors.map(c => ({ id: c, label: COLOR_NAMES[c], mana: c }))
      }));
      return;
    }
    if (req.kind === 'creature-type-choice') {
      bindings[req.bind] = ask(key, () => ({
        ...base, kind: 'text', title, prompt: 'Choose a creature type', suggestions: CREATURE_TYPES, mustMatchSuggestion: true
      }));
      return;
    }
    if (req.kind === 'choose-text') {
      bindings[req.bind] = ask(key, () => ({ ...base, kind: 'choose-one', title, prompt: req.label || 'Choose one', options: (req.options || []).map(o => ({ id: o, label: o })) }));
      return;
    }
    if (req.kind === 'text-choice') {
      bindings[req.bind] = ask(key, () => ({ ...base, kind: 'text', title, prompt: req.label || 'Enter a choice' }));
      return;
    }
    if (req.kind === 'per-opponent-up-to-one') {
      const chosen = {};
      for (const q of opponentsOf(game, player.playerId)) {
        const rows = battlefieldRows(game, q, req.filter || 'permanent');
        if (!rows.length) { chosen[q.playerId] = null; continue; }
        chosen[q.playerId] = ask(`${key}:${q.playerId}`, () => ({
          ...base, kind: 'choose-one', title: `${sourceName} — ${q.displayName}`,
          prompt: `Choose up to one ${req.filter || 'permanent'} controlled by ${q.displayName}.`,
          options: rows, allowNone: true, noneLabel: 'No target'
        }));
      }
      bindings[req.bind] = chosen;
      return;
    }
    if (req.kind === 'multi-target') {
      // "Up to X target creatures …, where X is the number of …": X is counted now, as the targets are chosen (req.xExpr).
      const xNow = req.xExpr != null ? Number(resolveAmount(game, player.playerId, req.xExpr, { ...bindings, sourceId: bindings.sourceId || ctx.source?.instanceId || null })) || 0 : Number(bindings.X || 0);
      const xv = v => (v === 'X' ? Math.max(0, xNow) : v);
      const max = Math.max(0, Number(xv(req.max) ?? 1)), min = Math.max(0, Number(xv(req.min) || 0));
      const rows = candidatesFor(game, { kind: 'target', scope: req.scope }, player, ctx.source || null).filter(r => !req.excludeBind || r.id !== bindings[req.excludeBind]);   // "other target creatures"
      bindings[req.bind] = rows.length
        ? ask(key, () => ({ ...base, kind: 'choose-many', title, prompt: req.label || `Choose up to ${max}`, options: rows, min: Math.min(min, rows.length), max: Math.min(max, rows.length) }))
        : [];
      return;
    }
    if (req.kind === 'card-selection') {
      const amount = requirementAmount(req, bindings);
      const targets = req.scope === 'each-opponent' ? opponentsOf(game, player.playerId)
        : req.scope === 'each-player' ? alivePlayers(game)
        : req.playerBind ? [playerById(game, bindings[req.playerBind])].filter(Boolean)
        : [player];
      const chosen = {};
      for (const q of targets) {
        const rows = battlefieldRows(game, q, req.filter).filter(r => !(req.notSource && r.id === bindings.sourceId));
        const need = Math.min(amount, rows.length), noun = String(req.filter || 'permanent').split('|')[0];
        // The affected player chooses what they sacrifice, on their own device.
        chosen[q.playerId] = need === 0 ? [] : need === rows.length && !req.upTo ? rows.map(r => r.id)
          : ask(`${key}:${q.playerId}`, () => ({
            ...base, playerId: q.playerId, cancellable: false, kind: 'choose-many',
            title: `${sourceName} — ${q.displayName}`,
            prompt: req.upTo ? `${q.displayName}: choose up to ${plural(need, noun)} (${req.label || 'chosen for the effect'}).` : `${q.displayName}: choose ${plural(need, noun)} (${req.label || 'required by the effect'}).`,
            options: rows, min: req.upTo ? 0 : need, max: need
          }));
      }
      bindings[req.bind] = targets.length === 1 && !['each-opponent', 'each-player'].includes(req.scope) ? (chosen[targets[0].playerId] || []) : chosen;
      return;
    }
    if (req.kind === 'discard-cards') {
      const amount = requirementAmount(req, bindings);
      const targets = req.scope === 'each-opponent' ? opponentsOf(game, player.playerId)
        : req.scope === 'each-player' ? alivePlayers(game)
        : [playerById(game, req.playerBind ? bindings[req.playerBind] : player.playerId)].filter(Boolean);
      const chosen = {};
      for (const q of targets) {
        // Cards drawn earlier in the same spell ("draw two cards, then discard a card") can be discarded too.
        const coming = (q.deck.remainingLibrary || []).slice(0, Number(req.plusDraw || 0) + Number(req.plusDrawBind ? bindings[req.plusDrawBind] || 0 : 0));
        const hand = [...(q.deck.hand || []), ...coming];
        const need = Math.min(amount, hand.length);
        chosen[q.playerId] = need === 0 ? [] : need === hand.length ? hand.map(c => c.instanceId)
          : ask(`${key}:${q.playerId}`, () => ({
            ...base, playerId: q.playerId, cancellable: false, kind: 'choose-many', private: true,
            title: `${sourceName} — Discard`,
            prompt: `${q.displayName}: choose ${plural(need, 'card')} to discard${coming.length ? ' (including the cards you are about to draw)' : ''}.`,
            options: hand.map(c => cardOption(game, c, q, coming.includes(c) ? 'You draw this' : 'Your hand')), min: need, max: need
          }));
      }
      bindings[req.bind] = ['each-opponent', 'each-player'].includes(req.scope) ? chosen : (chosen[targets[0]?.playerId] || []);
      return;
    }
    if (req.kind === 'brainstorm') {
      // Brainstorm: the cards about to be drawn are the top of the library, so the choice can be made now
      // with exactly what the player will hold: their hand plus those cards.
      const coming = (player.deck.remainingLibrary || []).slice(0, req.draw);
      const cards = [...(player.deck.hand || []).filter(c => c.instanceId !== bindings.sourceId).map(c => cardOption(game, c, player, 'In your hand')), ...coming.map(c => cardOption(game, c, player, 'You draw this'))];
      const pick = Math.min(req.put, cards.length);
      if (!pick) { bindings[req.bind] = { top: [] }; return; }
      const answer = ask(key, () => ({
        ...base, cancellable: false, kind: 'arrange', private: true, pick, otherLabel: 'Keep in hand',
        title: `${sourceName} — put ${pick} back`,
        prompt: `You draw ${plural(coming.length, 'card')}, then put ${plural(pick, 'card')} from your hand on top of your library. Choose them; the first one you choose goes on top.`,
        cards
      }));
      bindings[req.bind] = { top: answer.top || [] };
      return;
    }
    if (req.kind === 'hand-card') {
      // A card from hand, chosen as it resolves; cards about to be drawn by this effect are offered too.
      const fits = c => (!req.filter || String(req.filter).split(/,? or |, /).some(w => String(defOf(game, c)?.typeLine || '').toLowerCase().includes(w.trim()))) && (!req.fitsWords || cardFitsWords(defOf(game, c), String(req.fitsWords).replace(/\bX\b/, String(bindings.X ?? 0)).replace(/\bEVENTAMOUNT\b/, String(bindings.eventAmount ?? 0))));
      const rows = [...(player.deck.hand || []).filter(c => c.instanceId !== bindings.sourceId && fits(c)).map(c => cardOption(game, c, player, 'In your hand')),
        ...(player.deck.remainingLibrary || []).slice(0, req.plusDraw || (req.plusDrawAmount ? resolveAmount(game, player.playerId, req.plusDrawAmount, bindings) : 0)).filter(fits).map(c => cardOption(game, c, player, 'You draw this'))];
      if (!rows.length) { bindings[req.bind] = req.many ? [] : null; return; }
      if (req.many) { bindings[req.bind] = ask(key, () => ({ ...base, cancellable: false, kind: 'choose-many', private: true, title: `${sourceName} — ${req.label}`, prompt: `You may choose ${req.label}.`, options: rows, min: 0, max: rows.length })); return; }
      bindings[req.bind] = ask(key, () => ({ ...base, cancellable: false, kind: 'choose-one', private: true, title: `${sourceName} — ${req.label}`, prompt: `You may choose ${req.label}.`, options: rows, allowNone: true, noneLabel: 'None' }));
      return;
    }
    if (req.kind === 'yes-no') {
      bindings[req.bind] = ask(key, () => ({ ...base, cancellable: false, kind: 'confirm', title: `${sourceName}`, prompt: req.label, yesLabel: 'Yes', noLabel: 'No' }));
      return;
    }
    if (req.kind === 'vote') {
      // each player votes, starting with the controller, in turn order; each is asked their own vote
      const counts = Object.fromEntries(req.options.map(o => [o, 0]));
      for (const q of turnOrderFrom(game, player.playerId).filter(x => !x.eliminated)) {
        const pick = ask(`${key}:${q.playerId}`, () => ({ ...base, playerId: q.playerId, cancellable: false, kind: 'choose-one', title: `${sourceName} — vote`, prompt: `${q.displayName}: vote for ${req.options.join(' or ')}.`, options: req.options.map(o => ({ id: o, label: o[0].toUpperCase() + o.slice(1) })) }));
        if (pick in counts) counts[pick]++;
      }
      bindings[req.bind] = counts;
      return;
    }
    if (req.kind === 'scry' || req.kind === 'surveil') {
      const amount = Math.max(0, requirementAmount(req, bindings));
      const top = (player.deck.remainingLibrary || []).slice(0, amount);
      const otherZone = req.kind === 'scry' ? 'bottom' : 'graveyard';
      if (!top.length) { bindings[req.bind] = { top: [], [otherZone]: [] }; return; }
      const answer = ask(key, () => ({
        ...base, cancellable: false, kind: 'arrange', private: true,
        title: req.reorderOnly ? `${sourceName} — top ${plural(top.length, 'card')}` : `${sourceName} — ${req.kind === 'scry' ? 'Scry' : 'Surveil'} ${amount}`,
        prompt: req.reorderOnly ? `Look at the top ${plural(top.length, 'card')} of your library and put them back in any order (top first).` : `Look at the top ${plural(top.length, 'card')} of your library. Keep cards on top in the order shown, or send them to the ${otherZone === 'bottom' ? 'bottom' : 'graveyard'}.`,
        cards: top.map(c => cardOption(game, c, player, 'Top of library')),
        otherLabel: req.reorderOnly ? null : otherZone === 'bottom' ? 'Bottom of library' : 'Graveyard'
      }));
      bindings[req.bind] = { top: answer.top || [], [otherZone]: answer.other || [] };
      return;
    }
    if (req.kind === 'proliferate') {
      const rows = [];
      for (const q of alivePlayers(game)) {
        if (Number(q.poison || 0) > 0) rows.push({ id: `player|${q.playerId}|poison`, label: q.displayName, sub: `poison (${q.poison})`, pick: { kind: 'player', id: q.playerId, counter: 'poison' } });
        for (const [k, v] of Object.entries(q.counters || {})) {
          if (Number(v) > 0 && !/ThisTurn$|^damageDealt$|^failedDraws$/.test(k)) rows.push({ id: `player|${q.playerId}|${k}`, label: q.displayName, sub: `${k} (${v})`, pick: { kind: 'player', id: q.playerId, counter: k } });
        }
        for (const c of q.deck.battlefield || []) for (const [k, v] of Object.entries(c.counters || {})) {
          if (Number(v) > 0) rows.push({ id: `card|${c.instanceId}|${k}`, label: defOf(game, c)?.name || 'Permanent', sub: `${k} (${v}) — ${q.displayName}`, instanceId: c.instanceId, definitionId: c.definitionId, pick: { kind: 'card', id: c.instanceId, counter: k } });
        }
      }
      if (!rows.length) { bindings[req.bind] = []; return; }
      const ids = ask(key, () => ({ ...base, cancellable: false, kind: 'choose-many', title: `${sourceName} — Proliferate`, prompt: 'Choose any number of players and permanents with counters. Each gets one more of a counter it already has.', options: rows, min: 0, max: rows.length }));
      const seen = new Set(), picks = [];
      for (const id of ids) {
        const row = rows.find(r => r.id === id);
        if (!row) continue;
        const objectKey = `${row.pick.kind}:${row.pick.id}`;
        if (seen.has(objectKey)) continue;
        seen.add(objectKey);
        picks.push(row.pick);
      }
      bindings[req.bind] = picks;
      return;
    }

    // Single choice: target, player, graveyard-target, stack-target.
    let rows = candidatesFor(game, req.kind === 'linked-target' ? { ...req, sourceId: bindings.sourceId } : req, player, ctx.source || null);
    if (req.mvX) rows = rows.filter(r => { const d = defOf(game, locateCardInGame(game, r.id)?.card); return Number(d?.manaValue ?? d?.cmc ?? 0) === Number(bindings.X || 0); });
    if (req.excludeBind && bindings[req.excludeBind]) rows = rows.filter(r => r.id !== bindings[req.excludeBind]);
    if (req.notSource && bindings.sourceId) rows = rows.filter(r => r.id !== bindings.sourceId);   // "another"
    // "creature card with mana value equal to that spell's mana value" (Krile Baldesion): the spell the trigger is about.
    if (req.mvEqualsBind && bindings[req.mvEqualsBind] !== undefined) rows = rows.filter(r => { const card = game.players.flatMap(q => q.deck.graveyard || []).find(c => c.instanceId === r.id), d = card && defOf(game, card); return Number(d?.manaValue ?? d?.cmc ?? 0) === Number(bindings[req.mvEqualsBind]); });
    if ((req.kind === 'choose-permanent' || (req.kind === 'player' && req.notTargeted)) && rows.length === 1) { bindings[req.bind] = rows[0].id; return; }   // only one choice: no question
    if (!rows.length) {
      if (req.optional) { bindings[req.bind] = null; return; }
      throw new NoLegalChoice(`No legal choice is available for "${req.label || req.scope || 'this effect'}".`);
    }
    bindings[req.bind] = ask(key, () => ({ ...base, kind: 'choose-one', title, prompt: `Choose ${req.label || 'a target'}.`, options: rows, targeting: req.kind === 'target', allowNone: !!req.optional && req.kind === 'target', noneLabel: 'No target' }));
  });
  return bindings;
}

/** Thrown while gathering when a required target does not exist. The action is illegal. */
export class NoLegalChoice extends Error {
  constructor(message) { super(message); this.name = 'NoLegalChoice'; }
}

/** Check an answer against the decision it answers. Returns the cleaned value or throws. */
export function validateAnswer(decision, value) {
  const optionIds = new Set((decision.options || []).filter(o => !o.disabled).map(o => o.id));
  switch (decision.kind) {
    case 'choose-one':
      if ((value === null || value === undefined || value === '') && decision.allowNone) return null;
      if (!optionIds.has(value)) throw new Error('Choose one of the listed options.');
      return value;
    case 'choose-many': {
      const ids = [...new Set(Array.isArray(value) ? value : [])];
      if (ids.some(id => !optionIds.has(id))) throw new Error('A selected option is not available.');
      const min = Number(decision.min || 0), max = Number(decision.max ?? ids.length);
      if (ids.length < min || ids.length > max) throw new Error(min === max ? `Choose exactly ${min}.` : `Choose between ${min} and ${max}.`);
      return ids;
    }
    case 'number': {
      const n = Math.floor(Number(value));
      if (!Number.isFinite(n) || n < Number(decision.min || 0) || n > Number(decision.max ?? 99)) throw new Error(`Enter a number from ${decision.min || 0} to ${decision.max ?? 99}.`);
      return n;
    }
    case 'text': {
      const text = String(value || '').trim();
      if (!text) throw new Error('Enter a value.');
      if (decision.mustMatchSuggestion) {
        const hit = (decision.suggestions || []).find(s => s.toLowerCase() === text.toLowerCase());
        if (!hit) throw new Error('Choose one of the suggested values.');
        return hit;
      }
      return text.slice(0, 80);
    }
    case 'confirm':
      return value === true;
    case 'arrange': {
      const all = new Set((decision.cards || []).map(c => c.id));
      const top = Array.isArray(value?.top) ? value.top : [], other = Array.isArray(value?.other) ? value.other : [];
      const given = [...top, ...other];
      if (given.length !== all.size || new Set(given).size !== all.size || given.some(id => !all.has(id))) throw new Error('Place every card either on top or in the other pile.');
      if (decision.pick && top.length !== decision.pick) throw new Error(`Choose exactly ${decision.pick} cards to put on top.`);
      if (!decision.otherLabel && other.length) throw new Error('Put every card back on top, in the order you want.');
      return { top, other };
    }
    default:
      return value;
  }
}

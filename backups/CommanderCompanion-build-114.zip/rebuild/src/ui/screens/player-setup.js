// Player setup for Guided Play and Free Play: 2–6 seats, each with a name, deck, commander, playmat.
// When hosting a room, only the seats on this device are filled in here; the rest join remotely.

import { html, setHtml, on, $ } from '../dom.js';
import { go } from '../../app/router.js';
import { toast } from '../toast.js';
import { accountSetupDefaults, loadProfile, recordDeckSelection } from '../../data/profile.js';
import { listDecks } from '../../data/deck-store.js';
import { emptySeat } from '../../app/seat-setup.js';
import { seatFormHtml, readSeatForm, handleSeatAction } from '../seat-form.js';
import { prepareSeats, confirmSeats, chooseRules, buildGame } from '../../app/start-game.js';
import { startLocalSession } from '../../app/session.js';
import { deviceClientId } from '../../net/room.js';
import { createServerGame, onlineSeat, newSeatKey } from '../../net/online.js';
import { rememberOnlineGame } from '../../app/online-games.js';
import { PLAYER_COLORS } from '../../game/setup.js';
import { openDeckBuilder } from '../../data/deck-builder.js';

function seatFromDefaults(index, defaults) {
  const seat = emptySeat(defaults.playerNames?.[index] || '');
  // Table Defaults: each saved player's preferred deck is filled in automatically.
  const profile = loadProfile();
  const key = Object.keys(profile.players || {}).find(k => (profile.players[k].name || '').toLowerCase() === seat.name.toLowerCase());
  const row = key ? profile.players[key] : null;
  const preferredId = index === 0 && defaults.favoriteDeckId ? defaults.favoriteDeckId
    : row ? Object.values(row.decks || {}).sort((a, b) => String(b.lastSelectedAt || b.lastPlayedAt || '').localeCompare(String(a.lastSelectedAt || a.lastPlayedAt || '')))[0]?.id : '';
  const deck = preferredId ? listDecks().find(d => d.id === preferredId) : null;
  if (deck) Object.assign(seat, { deckId: deck.id, deckName: deck.name, deckList: deck.deckList || '', commander1: deck.commander1 || '', commander2: deck.commander2 || '', companion: deck.companion || '', sourceType: 'saved-deck' });
  return seat;
}

export const playerSetupScreen = {
  mount(root, params = {}) {
    const mode = params.mode === 'freeplay' ? 'freeplay' : 'fully-tracked';
    const play = params.play || 'local'; // local | host-player | online
    const defaults = accountSetupDefaults();
    const online = play === 'online';
    const hosting = play === 'host-player' || online;   // online: one seat here, the others join with the code
    const seats = params.seats || (hosting ? [seatFromDefaults(0, defaults)] : [seatFromDefaults(0, defaults), seatFromDefaults(1, defaults)]);
    let active = 0, remote = hosting ? Math.max(1, params.remoteSeats || 1) : 0, busy = false;
    const minLocal = hosting ? 1 : 2;

    function draw() {
      const title = mode === 'freeplay' ? 'Free Play' : 'Guided Play';
      setHtml(root, html`
        <main class="page page--setup">
          <header class="page__head">
            <button class="btn-back" type="button" data-act="back" aria-label="Back"><img src="assets/img/ui/back.png" alt="Back"></button>
            <h1 class="chrome-text">Player Setup — ${title}${online ? ' Online' : ''}</h1>
          </header>
          <div class="page__body setup">
            <nav class="setup__tabs">
              ${seats.map((s, i) => html`<button type="button" class="setup__tab ${i === active ? 'is-on' : ''}" data-act="tab" data-seat="${i}" style="--player:${PLAYER_COLORS[i]}">
                <b>${s.name.trim() || `Player ${i + 1}`}</b><small>${s.deckList && s.commander1 ? `✓ ${s.deckName}` : 'Needs a deck'}</small></button>`)}
              ${seats.length + remote < 6 ? html`<button type="button" class="setup__tab setup__tab--add" data-act="add">+ Add player${hosting ? ' on this device' : ''}</button>` : ''}
              ${seats.length > minLocal ? html`<button type="button" class="setup__tab setup__tab--add" data-act="remove">Remove ${seats[active].name.trim() || `Player ${active + 1}`}</button>` : ''}
              ${hosting ? html`<div class="setup__remote"><span>${online ? 'Players joining online' : 'Players joining from other devices'}</span><div class="stepper"><button type="button" class="icon-btn" data-act="remote" data-step="-1">−</button><b class="stepper__value">${remote}</b><button type="button" class="icon-btn" data-act="remote" data-step="1">+</button></div></div>` : ''}
            </nav>
            <section class="setup__form panel">${seatFormHtml(seats[active], active)}</section>
          </div>
          <footer class="page__foot">
            <span class="muted">${mode === 'freeplay' ? 'Free Play: any deck is allowed and every rule can be overridden.' : 'Guided Play checks each deck against the Commander rules.'}</span>
            <button type="button" class="btn" data-act="deck-builder">Deck Builder</button>
            <button type="button" class="btn btn--confirm" data-act="start">${online ? 'Create online game' : hosting ? 'Open room' : 'Continue'}</button>
          </footer>
        </main>`);
    }

    async function start() {
      if (busy) return;
      busy = true;
      try {
        const prepared = await prepareSeats(seats, { mode, rules: accountSetupDefaults().tableRuleDefaults || {} });
        if (!prepared) return;
        if (!(await confirmSeats(prepared))) return;
        if (online) return createOnline(prepared);
        if (hosting) return go('lobby', { mode, hostDevice: false, localSeats: prepared.map(r => r.seat), remoteSeats: remote, setupSeats: seats });
        const choice = await chooseRules({ mode, names: prepared.map(r => r.seat.name) });
        if (!choice) return;
        const game = buildGame({ mode, rules: choice.rules, firstPlayer: choice.firstPlayer, seats: prepared.map(r => r.seat) });
        startLocalSession(game);
        go('game');
      } catch (error) {
        console.error(error);
        toast(error.message || 'The game could not be started.', { bad: true });
      } finally { busy = false; }
    }

    /** Online game: only this device's seat (the first) is set up here; the rules are fixed now. */
    async function createOnline(prepared) {
      if (prepared.length !== 1) return toast('An online game has one player per device. Remove the extra players on this device.', { bad: true, ms: 4500 });
      const choice = await chooseRules({ mode, names: [prepared[0].seat.name] });
      if (!choice) return;
      toast('Creating the game…');
      const clientId = deviceClientId();
      // On the rules server (build 76): the game is dealt and run there, so no device holds another player's hand.
      const key = newSeatKey();
      let made;
      try { made = await createServerGame({ mode, rules: { ...choice.rules, priorityTimer: 0 }, firstPlayer: choice.firstPlayer, seatsWanted: 1 + remote, seats: [onlineSeat(prepared[0].seat, clientId)] }, key); }
      catch (error) { return toast(error.message || 'The online game could not be created.', { bad: true, ms: 4500 }); }
      rememberOnlineGame({ code: made.code, clientId, key, server: true, name: prepared[0].seat.name, names: [prepared[0].seat.name], mode });
      const s0 = prepared[0].seat;
      recordDeckSelection({ playerName: s0.name, deckId: s0.deckId, deckName: s0.deckName, commander1: s0.commanderNames?.[0] || '', commander2: s0.commanderNames?.[1] || '', source: s0.sourceType }).catch(() => {});
      go('online', { mode, code: made.code });
    }

    draw();
    const offInput = on(root, 'input', '[data-field]', () => {
      readSeatForm(root, seats[active]);
      const tab = $(`.setup__tab[data-seat="${active}"] b`, root);
      if (tab) tab.textContent = seats[active].name.trim() || `Player ${active + 1}`;
    });
    const offClick = on(root, 'click', '[data-act], [data-seat-act]', (event, el) => {
      readSeatForm(root, seats[active]);
      if (el.dataset.seatAct) return handleSeatAction(el.dataset.seatAct, el, seats[active], draw);
      switch (el.dataset.act) {
        case 'back': return online ? go('online', { mode }) : go('mode-select');
        case 'tab': active = Number(el.dataset.seat); return draw();
        case 'add': seats.push(seatFromDefaults(seats.length, defaults)); active = seats.length - 1; return draw();
        case 'remove': seats.splice(active, 1); active = Math.max(0, active - 1); return draw();
        case 'remote': remote = Math.max(1, Math.min(6 - seats.length, remote + Number(el.dataset.step))); return draw();
        case 'start': return start();
        case 'deck-builder': return openDeckBuilder({ screen: 'player-setup', params: { mode, play, seats, remoteSeats: remote } });
      }
    });
    return () => { offInput(); offClick(); };
  }
};

const norm0 = s =>
  String(s)
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
// The same names are normalised many thousands of times while a deck is built, so each result is kept (Build 143; same answers).
const NORM_C = new Map();
const norm = s => {
  let v = NORM_C.get(s);
  if (v === undefined) {
    if (NORM_C.size > 200000) NORM_C.clear();
    v = norm0(s);
    NORM_C.set(s, v);
  }
  return v;
};
const frontType = c => {
  const t = c.t || '';
  return t.indexOf(' // ') < 0 ? t : t.split(' // ')[0];
};
const isBasic = n => Object.prototype.hasOwnProperty.call(BASICS, n) || String(n).startsWith('Snow-Covered ');

function costFmt(s) {
  return (s || '').replace(/(\d+|[WUBRGXC])/g, '{$1}');
}
function cmcOf(m) {
  let v = 0;
  (m.match(/\{([^}]+)\}/g) || []).forEach(x => {
    const k = x.slice(1, -1);
    if (/^\d+$/.test(k)) v += +k;
    else if (k !== 'X') v += 1;
  });
  return v;
}
function identityOf(text, type) {
  const s = new Set();
  (text.match(/\{[^}]*\}/g) || []).forEach(x => {
    for (const ch of x) if ('WUBRG'.includes(ch)) s.add(ch);
  });
  for (const b in COLOR_BASIC) if (new RegExp('\\b' + COLOR_BASIC[b] + '\\b').test(type)) s.add(b);
  return 'WUBRG'.split('').filter(c => s.has(c));
}
function parseStarter(raw) {
  const out = raw
    .trim()
    .split('\n')
    .map(l => {
      const [n, cost, t, p, o, fl, pt] = l.split('|');
      const m = costFmt(cost),
        text = (o || '').replace(/~/g, n);
      return {
        n,
        m,
        t,
        o: text,
        ci: identityOf(m + text, t),
        cmc: cmcOf(m),
        p: +p,
        std: /S/.test(fl || ''),
        cmd: true,
        r: 0,
        pt: pt || '',
        src: 'starter'
      };
    });
  for (const b in BASICS)
    out.push({
      n: b,
      m: '',
      t: 'Basic Land' + (b === 'Wastes' ? '' : ' — ' + b),
      o: b === 'Wastes' ? '{T}: Add {C}.' : '({T}: Add {' + BASICS[b] + '}.)',
      ci: BASICS[b] ? [BASICS[b]] : [],
      cmc: 0,
      p: 0.1,
      std: b !== 'Wastes',
      cmd: true,
      r: 0,
      pt: '',
      src: 'starter'
    });
  return out;
}
const TWO_SIDED = new Set(['transform', 'modal_dfc', 'reversible_card']);
function twoSided(o, f) {
  return !!(f && f.length === 2 && TWO_SIDED.has(o.layout || ''));
}
function fromScryfall(o) {
  if (!o || o.object !== 'card') return null;
  if (/token|emblem|art_series|vanguard|scheme|planar/.test(o.layout || '')) return null;
  if (o.games && !o.games.includes('paper')) return null;
  const lg = o.legalities || {},
    cmd = lg.commander === 'legal',
    std = lg.standard === 'legal';
  if (!cmd && !std) return null;
  const f = o.card_faces,
    f0 = (f && f[0]) || {};
  const pr = o.prices || {},
    p = parseFloat(pr.usd || pr.usd_foil || pr.usd_etched);
  const pw = o.power != null ? o : f0;
  return {
    n: o.name,
    m: o.mana_cost || f0.mana_cost || '',
    t: o.type_line || f0.type_line || '',
    o: o.oracle_text != null ? o.oracle_text : (f || []).map(x => x.oracle_text || '').join(' // '),
    ci: o.color_identity || [],
    cmc: o.cmc || 0,
    p: isNaN(p) ? null : p,
    std,
    cmd,
    r: o.edhrec_rank || 0,
    pt: pw.power != null ? pw.power + '/' + pw.toughness : o.loyalty ? 'Loyalty ' + o.loyalty : '',
    set: o.set_name || '',
    id: o.id || '',
    sc: o.set || '',
    oid: o.oracle_id || '',
    rar: o.rarity || '',
    cn: o.collector_number || '',
    gc: !!o.game_changer,
    nw: o.reprint === false && o.released_at ? o.released_at.slice(0, 7) : '', // first printing's month, for new cards with little play data yet
    fn: o.flavor_name || f0.flavor_name || '',
    src: 'full',
    // Two-sided cards (owner, 11 Nov: no flip anywhere): the published card data keeps no pictures on the faces, so a card
    // counts as two-sided by its layout (both faces are printed sides); its back picture comes from the same printing.
    df: twoSided(o, f),
    rv: o.layout === 'reversible_card',   // reversible card: the chip says Reverse
    fc:
      twoSided(o, f)
        ? f.map(x => ({
            n: x.name || '',
            m: x.mana_cost || '',
            t: x.type_line || '',
            pt:
              x.power != null
                ? x.power + '/' + x.toughness
                : x.loyalty
                  ? 'Loyalty ' + x.loyalty
                  : x.defense
                    ? 'Defense ' + x.defense
                    : ''
          }))
        : null
  };
}
// ----- card identity -----
// Every comparison between cards uses one identity: the Scryfall Oracle ID (c._k). Display names stay as the player or the
// source wrote them. The name index resolves, in order: the exact card name; a face of a double-faced or split card (only
// if no real card has that name); then an alternate printed name (ALT_NAMES in lists.js, e.g. "Vibranium Dynamo" is Thran
// Dynamo). A printed name that is also a different real card's name is ambiguous and is never used (listed in ALT_CLASH).
let ALT_CLASH = [];
function buildIndex(cards) {
  LIB = cards;
  IDX = new Map();
  ALT_CLASH = [];
  for (const c of cards) {
    c._n = norm(c.n);
    c._k = c.oid || 'n:' + c._n;
    if (!IDX.has(c._n)) IDX.set(c._n, c);
  }
  for (const c of cards)
    if (c.n.includes(' // '))
      c.n.split(' // ').forEach(f => {
        const k = norm(f);
        if (!IDX.has(k)) IDX.set(k, c);
      });
  if (typeof ALT_NAMES !== 'undefined')
    for (const a in ALT_NAMES) {
      const k = norm(a),
        real = IDX.get(norm(ALT_NAMES[a]));
      if (!real) continue;
      if (IDX.has(k)) {
        if (IDX.get(k) !== real) ALT_CLASH.push(a);
        continue;
      }
      IDX.set(k, real);
    }
}
function mergeLibrary(starter, full) {
  const seen = new Set(full.map(c => norm(c.n)));
  return full.concat(starter.filter(c => !seen.has(norm(c.n))));
}
function find(name) {
  if (!name) return null;
  return IDX.get(norm(name)) || IDX.get(norm(String(name).split(' // ')[0])) || null;
}
// The identity key for a name: the card's Oracle identity when it resolves, otherwise the normalised text (unresolved names
// still never match a different card).
function keyOf(name) {
  const c = find(name);
  return c ? c._k : 'u:' + norm(name || '');
}
// The deck entry holding a card, whatever name or printing it was entered under.
function entryOf(d, name) {
  const k = keyOf(name);
  return (d.cards || []).find(x => keyOf(x.n) === k) || null;
}
// Printed names published after this build (owner, 8 Nov: "The search function can't find newly renamed printings"): the daily
// card-data job writes every printed (flavor) name with its real card (alt.json; storage.js loadAltNames); the ones the built-in
// list lacks are added here, to the name index too, with the same rule for a name that is also another real card's name.
function addAltNames(map) {
  if (typeof ALT_NAMES === 'undefined' || !map) return 0;
  let n = 0;
  for (const a in map) {
    if (ALT_NAMES[a] || typeof map[a] !== 'string') continue;
    ALT_NAMES[a] = map[a];
    n++;
    const k = norm(a), real = IDX && IDX.get(norm(map[a]));
    if (!real || !k) continue;
    if (IDX.has(k)) { if (IDX.get(k) !== real) ALT_CLASH.push(a); continue; }
    IDX.set(k, real);
  }
  if (n) { ALT_IDX = null; searchCards.alt = null; }
  return n;
}
// Alternate printed names (see ALT_NAMES in lists.js): the real card name for a name printed on a reskinned card, or ''.
let ALT_IDX = null;
function altName(name) {
  if (typeof ALT_NAMES === 'undefined' || !name) return '';
  if (!ALT_IDX) {
    ALT_IDX = new Map();
    for (const k in ALT_NAMES) ALT_IDX.set(norm(k), ALT_NAMES[k]);
  }
  const k = norm(name);
  return k ? ALT_IDX.get(k) || ALT_IDX.get(norm(String(name).split(' // ')[0])) || '' : '';
}

// a creature's power and toughness as numbers (a * counts as 0)
const ptOf = c =>
  String(c.pt || '0/0')
    .split('/')
    .map(x => parseInt(x, 10) || 0);
function tags(c) {
  if (c._t) return c._t;
  const o = c.o || '',
    t = frontType(c),
    land = /\bLand\b/.test(t),
    th = {},
    roles = new Set();
  // a spell with a land on its back face is judged for jobs by its front face only
  let ro = / \/\/ [^/]*\bLand\b/.test(c.t || '') ? o.split(' // ')[0] : o;
  // a planeswalker's ultimate (minus 5 or more) is not one of its jobs (UP.bs): Nissa, Vital Force is not card draw
  if (UP.bs && /Planeswalker/.test(t))
    ro = ro
      .split('\n')
      .filter(l => !/^[−-]([5-9]|\d\d|X):/.test(l))
      .join('\n');
  for (const k in THEMES) {
    const T = THEMES[k];
    if (!T.re || (T.v2 && !UP.newTh.includes(k))) continue;
    th[k] = T.re.test(o)
      ? 1
      : (T.kw && T.kw.test(o)) ||
          (T.pw && /Creature/.test(t) && parseInt(String(c.pt || '0').split('/')[0], 10) >= T.pw) ||
          // stats when the words say nothing: a wall (toughness 6+, over twice its power), a creature that costs nothing
          (T.wall && /Creature/.test(t) && ptOf(c)[1] >= 6 && ptOf(c)[1] > 2 * ptOf(c)[0]) ||
          (T.free && /Creature/.test(t) && !(c.cmc > 0) && !/\{X\}/.test(c.m || '')) ||
          (T.mv && c.cmc >= 10 && T.mv.test(o))
        ? 0.7
        : T.type && T.type.test(t)
          ? 0.5
          : 0;
  }
  if (UP.kw)
    for (const k in KW_RE)
      if (
        th[k] !== 1 &&
        KW_RE[k].test(o) &&
        !(k === 'tokens' && !/\btokens?\b|populate|amass|incubate|fabricate|investigate|treasure|food|clue/i.test(o))
      )
        th[k] = 1; // keywords (Build 139)
  if (!land) {
    if (ROLE_RE.ramp.test(ro)) roles.add('ramp');
    // A permanent that makes the spells you cast cheaper (Ruby Medallion, Dragonspeaker Shaman) gives that mana every turn: it is
    // ramp for those spells (UP.costR, Build 143). One-time reductions and taxes on opponents are not.
    if (
      UP.costR &&
      !roles.has('ramp') &&
      !/^(Instant|Sorcery)/.test(t) &&
      /\bspells? you cast\b[^.]{0,40}\bcosts? \{\d+\} less\b/i.test(ro.replace(/this spell costs[^.]*\./gi, ''))
    )
      roles.add('ramp');
    // Card draw is drawing more cards than you discard, for you: looting and conniving (draw one, discard one) only filter,
    // and a draw any player may get (Selvala) is not yours. The monarch and the initiative draw every turn.
    {
      const fx = UP.fx ? effectsOf(c).effects : null,
        real =
          fx &&
          fx.some(
            e =>
              (e.kind === 'draw' && !e.symmetric && e.who !== 'each opponent') || e.kind === 'monarch' || e.kind === 'initiative'
          ) &&
          (!UP.bs || ro === o || THEMES.draw.re.test(ro) || /you become the monarch|take the initiative/i.test(ro)),
        only = fx && !real && fx.some(e => e.kind === 'filter' || (e.kind === 'draw' && e.symmetric));
      // Rules audit (Build 141): cycling ("Discard this card: Draw a card", in its reminder text) replaces itself, so it is not card draw;
      // "target player draws" can target you (Peer into the Abyss)
      // 0.9.48: a trigger on drawing ("Whenever you draw a card, you gain 2 life" — Sheoldred, Chasm Skulker, Underworld Dreams)
      // is not card draw; only what the ability itself does counts.
      const rd = ro.replace(/\([^()]*discard this card: draw a card\.?\)/gi, '').replace(/\b(?:whenever|when|if) (?:you|an opponent|a player|each player|another player|that player|target player|an? (?:opponent|player))(?: would)? draws? (?:a|an|one or more|your first|their first|their second|a second)? ?cards?(?: [^,.]*)?,/gi, ','),
        rd2 = UP.nmh ? rd.replace(/you have no maximum hand size\.?/gi, '') : rd;
      if (
        (real && (rd === ro || THEMES.draw.re.test(rd2) || /you become the monarch|take the initiative/i.test(rd2))) ||
        (((THEMES.draw.re.test(rd2) && !/each player draws|target opponent draws/i.test(ro)) ||
          /you become the monarch|take the initiative|target player draws (cards|\w+ cards)/i.test(rd2)) &&
          !(UP.fx && only))
      )
        roles.add('draw');
    }
    // Each sentence or mode is judged on its own: a wipe clause makes a wipe, and a separate one-target clause on the same
    // card (Ugin's Binding, a planeswalker's minus) still counts as removal. Blink text ("exile ..., then return it") is not removal.
    const parts = ro
      .replace(/exile[^.]*\.?( then,?)? ?return[^.]*(to|onto) the battlefield[^.]*\./gi, '')
      .split(/(?<=\.)\s+|•|\n/);
    // 0.9.48: "exile all other cards revealed this way" (Demonic Consultation) is not a wipe; a target you own or control ("Destroy
    // target permanent you own" — Staff of Compleation) is not removal.
    const notWipe = x => /\bexile (?:all|each) other cards\b|\bcards? (?:revealed|exiled) this way\b/i.test(x),
      yoursOnly = x => /\btarget [a-z ,/-]*?(?:permanent|creature|artifact|enchantment|land)s? you (?:own|control)\b/i.test(x) && !/\byou don'?t control\b|\ban opponent controls\b/i.test(x);
    if (parts.some(x => ROLE_RE.wipe.test(x) && !notWipe(x)) || (/\bOverload\b/.test(ro) && ROLE_RE.wipe.test(ro))) roles.add('wipe'); // overload: one target, or all of them
    if (parts.some(x => ROLE_RE.removal.test(x) && !ROLE_RE.wipe.test(x) && !yoursOnly(x))) roles.add('removal');
    if (ROLE_RE.counter.test(ro)) roles.add('counter');
    if (ROLE_RE.tutor.test(ro) && !roles.has('ramp')) roles.add('tutor');
    if (ROLE_RE.protect.test(ro) || (/\bInstant\b/.test(t) && ROLE_RE.blink.test(ro))) roles.add('protect'); // an instant-speed blink saves a creature; a blink engine does not count
  }
  // The game engine's reading (lists.js ENGINE_ROLES, tools/role-compare.mjs): only for a nonland card this reader gives no role
  // (owner, 7 Nov: "use the game engine's card reading in the Deck Builder"; roadmap 5.1).
  // (and the removal, draw or ramp it reads on a card this reader reads only partly; the list holds only what this reader lacks)
  if (typeof ENGINE_ROLES !== 'undefined' && ENGINE_ROLES[c.n]) ENGINE_ROLES[c.n].forEach(r => roles.add(r));
  // engine v2: a card's jobs come from its rules reading (engine/functions.js) as well as, or instead of, the text patterns above
  // UP.v2 1: the reading's jobs replace the patterns'; 2: both; UP.v2r: the jobs taken from the reading (the rest keep the patterns')
  // (only removal, wipes and card draw are taken from the reading: a card with no removal words and no 0.9.3 removal is left unread, the same
  // result faster)
  if (
    UP.v2 &&
    !land &&
    !(
      UP.v2 === 1 &&
      UP.v2r &&
      UP.v2r.every(r => r === 'removal' || r === 'wipe+' || r === 'draw+') &&
      !roles.has('removal') &&
      !(
        UP.v2r.includes('draw+') &&
        /\bdraws?\b|\bhand\b|exile the top|look at the top|investigate|clue|connive|monarch|initiative|may (?:play|cast)/i.test(o)
      ) &&
      !/destroy|exile|damage|\/[-−]|sacrific|fights?\b|gains? control|controls enchanted|owners?'?s? (?:hand|library)|hands\b|top or bottom of|shuffles|loses all|can't attack|base power|tap target|doesn't untap|waterbend/i.test(
        o
      )
    )
  ) {
    const f = fnOf(c, new Set(roles)).roles;
    for (const [o, n] of FN_OLD) {
      // a role listed as "wipe+" is only added from the reading, never taken away
      const only = UP.v2r && UP.v2r.includes(o + '+');
      if (UP.v2r && !only && !UP.v2r.includes(o)) continue;
      if (f.has(n)) roles.add(o);
      else if (UP.v2 === 1 && !only) roles.delete(o);
    }
  }
  return (c._t = {land, th, roles});
}
// ----- Card readings kept between launches (roadmap 6.2, speed) -----
// Reading every card's text for its jobs and themes (tags, with fnOf inside it) takes about 15 s at phone speed. The result
// depends only on the card's own text and on the engine (its build and settings), so the page stores it and reuses it on the
// next launch (ui/storage.js readsLoad/readsSave). A card is reused only if a hash of the fields the reading looks at matches;
// the whole store only if the build, the settings and the theme list match. Themes are stored only when not 0 (most are 0).
function readSig(build) {
  return String(build || '') + '|' + oracleHash(JSON.stringify(UP)) + '|' + Object.keys(THEMES).join(',');
}
function readHash(c) {
  return oracleHash(c.n + '\u0001' + c.m + '\u0001' + c.t + '\u0001' + c.o + '\u0001' + c.cmc + '\u0001' + c.pt + (c.fc ? JSON.stringify(c.fc) : ''));
}
// pack every card read so far: {sig, keys (the usual theme list, in order), rows: {card key: [hash, land, themes, roles, fn]}}
function readPack(sig) {
  let keys = null;
  const rows = {};
  for (const c of LIB) {
    const t = c._t;
    if (!t || !c._k) continue;
    const tk = Object.keys(t.th);
    if (!keys) keys = tk;
    let th;
    if (tk.length === keys.length && tk.every((k, i) => k === keys[i])) {
      th = [];
      keys.forEach((k, i) => t.th[k] && th.push(i, t.th[k]));
    } else th = Object.assign({}, t.th); // an unusual theme list is kept whole
    const f = c._fn;
    rows[c._k] = [readHash(c), t.land ? 1 : 0, th, [...t.roles], f ? [[...f.makes], [...f.uses], [...f.roles]] : 0];
  }
  return {sig, keys: keys || [], rows};
}
// put stored readings back on the cards not read yet (LIB[i0] to LIB[i1], all by default); returns how many were reused.
// same: the card data is the very file the store was made from, so each card's text hash need not be checked.
function readApply(P, sig, same, i0, i1) {
  if (!P || P.sig !== sig || !P.rows) return 0;
  let n = 0;
  const end = Math.min(i1 == null ? LIB.length : i1, LIB.length);
  for (let i = i0 || 0; i < end; i++) {
    const c = LIB[i];
    if (c._t || !c._k) continue;
    const r = P.rows[c._k];
    if (!r || (!same && r[0] !== readHash(c))) continue;
    let th;
    if (Array.isArray(r[2])) {
      th = {};
      P.keys.forEach(k => (th[k] = 0));
      for (let i = 0; i < r[2].length; i += 2) th[P.keys[r[2][i]]] = r[2][i + 1];
    } else th = Object.assign({}, r[2]);
    if (r[4] && !c._fn) c._fn = {makes: new Set(r[4][0]), uses: new Set(r[4][1]), roles: new Set(r[4][2])};
    c._t = {land: !!r[1], th, roles: new Set(r[3])};
    n++;
  }
  return n;
}
// The core pieces of a plan fit its EDHREC theme whatever share of the theme's decks run them (owner, 31 Oct: "we can't miss
// critical things like a soul stone being excluded from a graveyard/reanimate deck"): the theme pages only list what many of
// its players run, and a strong card few of them own (The Soul Stone, in 7% of Teval decks) never reached them. UP.aimText.
const REANIM_PLAN =
    /return (target|up to one target|a|all|each)[^.]*creature cards? from (your|a|all|their) graveyards? (to|onto) the battlefield|put (target|a|up to one target|all)[^.]*creature cards? from (a|your|all) graveyards? onto the battlefield|return enchanted creature card to the battlefield/i,
  ENTOMB_PLAN = /search your library for (a|an|up to \w+) [^.]*?cards?[^.]*put (it|them|that card|those cards) into your graveyard/i;
const AIM_TEXT = {
  reanimator: c => isReanimEngine(c) || REANIM_PLAN.test(c.o || '') || ENTOMB_PLAN.test(c.o || ''),
  graveyard: c => isReanimEngine(c) || REANIM_PLAN.test(c.o || '') || ENTOMB_PLAN.test(c.o || '')
};
function matchAim(c, key, tribe) {
  if (isEdhAim(key)) {
    const m = EDH.tmap && EDH.tmap[key.slice(4)],
      x = m && edhOf(m, c),
      all = EDH.map && edhOf(EDH.map, c);
    if (UP.aimText && m && AIM_TEXT[key.slice(4)] && AIM_TEXT[key.slice(4)](c)) return 1;
    if (!x || x.inc < 0.2) return 0;
    // A card that is a core piece of the theme (in UP.dom of its decks or more) fits it even when it is just as common across
    // all of this commander's decks (Zombie lords for Gisa, whose players mostly build Zombies anyway).
    if (UP.dom && x.inc >= UP.dom && x.inc >= (all ? all.inc : 0)) return 1;
    return x.inc >= (all ? all.inc : 0) + 0.05 ? 1 : 0;
  }
  if (key === 'tribal') {
    if (!tribe) return 0;
    // the answer depends only on the card's text and the type, so it is kept on the card (Build 143; same answers)
    const M = c._mt || (c._mt = {}),
      h = M[tribe];
    if (h && h.t === c.t && h.o === c.o) return h.v;
    const v = tribeMatch(c, tribe);
    M[tribe] = {t: c.t, o: c.o, v};
    return v;
  }
  const tg = tags(c);
  if (key === 'combo') return UP.newTh.includes('combo') && (COMBOS.by.get(c._k) || []).some(x => x.keys.length <= 3) ? 1 : 0;
  if (key === 'control') return tg.roles.has('counter') || tg.roles.has('removal') || tg.roles.has('wipe') ? 1 : 0;
  return tg.th[key] || 0;
}
function tribeMatch(c, tribe) {
  // Creature types are capitalised in rules text; a named Role token ("Young Hero Role") is not the type.
  const re = new RegExp('\\b' + tribe.replace(/[^A-Za-z ]/g, '') + '(s|es|ves)?\\b'),
    alt = tribe === 'Elf' ? /\bElves\b/ : null;
  if (re.test(frontType(c).split('—')[1] || '')) return 1;
  const o = (c.o || '').replace(/\b(?:[A-Z][\w']* )+Role\b/g, '');
  if (re.test(o) || (alt && alt.test(o))) return 1;
  // Eldrazi decks run colourless cards that care about colourless (Ancient Stirrings for Ulalek; misread.js, 24 Oct)
  if (tribe === 'Eldrazi' && /\bcolorless (?:card|spell|creature|permanent)s?\b/i.test(o)) return 0.7;
  return /chosen type|shares a creature type|changeling/i.test(c.o || '') ? 0.7 : 0;
}
const subtypes = c => (frontType(c).split('—')[1] || '').trim().split(/\s+/).filter(Boolean);
// The creature type a deck is built around. If the commander's text names types ("Mutants, Ninjas, and/or Turtles"),
// the one the deck runs most wins. If it names none, the commander's own type counts once the deck is full of it
// (a Dinosaur commander leading a pile of Dinosaurs, a Hero leading Heroes). Human is too common to mean anything.
function deckTribe(d, cmd, named) {
  const cnt = {};
  ((d && d.cards) || []).forEach(e => {
    const c = find(e.n);
    if (c && /Creature/.test(frontType(c))) subtypes(c).forEach(t => (cnt[t] = (cnt[t] || 0) + e.q));
  });
  if (named.length) return named.slice().sort((a, b) => (cnt[b] || 0) - (cnt[a] || 0))[0];
  let best = '',
    n = 9;
  (cmd ? subtypes(cmd) : []).forEach(t => {
    if (TRIBE_SET.has(t) && t !== 'Human' && (cnt[t] || 0) > n) {
      n = cnt[t];
      best = t;
    }
  });
  return best;
}
// Every plan this commander's players build (its EDHREC themes, as the app's plans, or as the theme pages when they are loaded)
function xPlansOf(cmd) {
  if (!UP.xPlan || !cmd || EDH.key !== cmd.n || !(EDH.tags || []).length) return [];
  const rev = {};
  for (const k in TAG_OF) rev[TAG_OF[k]] = k;
  Object.assign(rev, TAG_ALIAS);
  const on = new Set(themeKeys()),
    out = [];
  EDH.tags.forEach(t => {
    if (EDH.tmap && EDH.tmap[t.slug]) out.push('edh:' + t.slug);
    else if (rev[t.slug] && on.has(rev[t.slug])) out.push(rev[t.slug]);
  });
  return [...new Set(out)];
}
function detectStrategy(cmd, d, thin) {
  if (!cmd) return {themes: [], tribe: ''};
  const tg = tags(cmd),
    o = (cmd.o || '').replace(new RegExp(cmd.n.split(',')[0], 'g'), '');
  // (Build 145, UP.cbec) what the commander turns other things into ("are 4/4 Elemental creatures") is not a creature type it rewards
  const o2 = o
    .replace(/[^.]*\bcreates?\b[^.]*tokens?[^.]*\./gi, ' ')
    // a type it only searches for is not a type it rewards (Magda finds "an artifact or Dragon card" but leads Dwarves; 21 Oct)
    .replace(/\bsearch your library for [^.]*\./gi, ' ')
    .replace(
      UP.cbec ? /\b(is|are|becomes?)\s+(an?\s+)?(\d+\/\d+\s+)?([a-z]+\s+)*?([A-Z][a-z]+\s+)+(artifact\s+)?creatures?\b/g : /$^/,
      ' '
    );
  // (UP.ctok) a commander that keeps making creature tokens of one type (Ghoulcaller Gisa's Zombies) leads that type's deck; only once its play data is known to be missing or thin:
  // with data of its own, the players' choices say whether it does (measured: the data alone matches them better)
  const tokT =
    !UP.ctok || !(thin || (EDH.key === cmd.n && EDH.state !== 'loading' && (!EDH.map || EDH.map.size < 60)))
      ? []
      : effectsOf(cmd)
          .effects.filter(x => x.kind === 'token' && x.creature && x.mine && !x.once)
          .flatMap(x => TRIBES.filter(t => t !== 'Human' && new RegExp('\\b' + t + '\\b').test(x.what || '')));
  const tribe = deckTribe(
    d,
    cmd,
    TRIBES.filter(
      t => new RegExp('\\b(' + t + '|' + t[0] + tribeSlug(t).replace(/-/g, ' ').slice(1) + ')s?\\b').test(o2) || tokT.includes(t)
    ) // irregular plurals too (Elves, Dwarves, Wolves)
  );
  // Read the plan, not the payoff: counters a commander only puts on itself are growth, not a counters deck, and
  // making Treasure-style artifact tokens is an artifact plan, not going wide.
  const self = cmd.n.split(',')[0].replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const plan = (cmd.o || '')
    .replace(new RegExp('put (a|an|one|two|three|four|x|that many) \\+1/\\+1 counters? on ' + self + '\\b', 'gi'), '')
    .replace(/\bcreates? [^.]*\b(Treasure|Clue|Food|Blood|Map|Powerstone|Vibranium|Gold|Junk|Incubator) tokens?/gi, ' artifact ');
  const order = [
    'counters',
    'tokens',
    'graveyard',
    'sacrifice',
    'spells',
    'artifacts',
    'enchantments',
    'lifegain',
    'lands',
    'voltron',
    'blink',
    'burn',
    'aggro',
    'flying',
    'defenders',
    'goad',
    'untap',
    'theft',
    'evasion',
    'stax',
    'voting',
    'clones',
    'cheat',
    'topdeck'
  ];
  const themes = order.filter(
    k =>
      !(THEMES[k].v2 && !UP.newTh.includes(k)) &&
      THEMES[k].pick !== false &&
      (THEMES[k].re ? THEMES[k].re.test(plan) : tg.th[k] === 1) &&
      (k !== 'blink' || /whenever (a|another|one or more)|then return/i.test(o))
  );
  return {themes: (tribe ? ['tribal'] : []).concat(themes), tribe};
}

// ----- deck text import -----
// Official decklists write some names differently: "and" for "&" (Bebop, Skull and Crossbones), and a deck label after a
// reprint's name ("Sol Ring Avengers", "Command Tower (Villains)"). Only tried when the name as typed is no card; a label
// must be capitalised words, so a misspelling ("Sol Rings") or a different card ("Sword of Fire and Ice") never resolves.
function labelled(name) {
  const s = String(name).trim(),
    a = s.replace(/ and /g, ' & '),
    b = s.replace(/ & /g, ' and ');
  for (const x of [a, b]) if (x !== s && find(x)) return find(x).n;
  const p = /^(.+?)\s*\(([^()]+)\)$/.exec(s);
  if (p && find(p[1])) return find(p[1]).n;
  const w = s.split(/\s+/);
  for (let k = 1; k <= 3 && k < w.length - 1; k++) {
    const rest = w.slice(-k);
    if (!rest.every(x => /^[A-Z][A-Za-z']*$/.test(x))) break;
    const c = find(w.slice(0, -k).join(' '));
    if (c) return c.n;
  }
  return '';
}
function parseDeckText(txt) {
  const out = {cards: [], commander: '', side: 0, name: ''};
  let section = 'main';
  const map = new Map();
  for (let line of String(txt).replace(/\r/g, '').split('\n')) {
    line = line.trim();
    if (!line) continue;
    let hm = line.replace(/^(\/\/|#)+\s*/, '');
    const head =
      /^(commander|commanders|deck|main|mainboard|main deck|sideboard|side|maybeboard|companion|about|lands?|creatures?|instants?|sorcer(y|ies)|artifacts?|enchantments?|planeswalkers?|spells?)\b\s*(\(\d+\))?:?$/i.exec(
        hm
      );
    if (head) {
      const h = head[1].toLowerCase();
      section = /^commander/.test(h)
        ? 'commander'
        : /^(sideboard|side|maybeboard)$/.test(h)
          ? 'side'
          : h === 'about'
            ? 'about'
            : h === 'companion'
              ? 'companion'
              : 'main';
      continue;
    }
    if (/^(\/\/|#)/.test(line)) continue;
    if (section === 'about') {
      const nm = /^name\s+(.+)/i.exec(line);
      if (nm) out.name = nm[1];
      continue;
    }
    let sb = false;
    if (/^SB:\s*/i.test(line)) {
      sb = true;
      line = line.replace(/^SB:\s*/i, '');
    }
    let q = 1,
      name = line;
    const m = /^(\d+)\s*x?\s+(.+)$/i.exec(line);
    if (m) {
      q = +m[1];
      name = m[2];
    }
    const isCmd = /\*CMDR\*/i.test(name);
    const pm = /[\(\[]([A-Za-z0-9]{2,6})[\)\]]\s*([A-Za-z0-9★-]{1,8})?/.exec(name); // "(SET) 123": the printing
    name = name
      .replace(/\*[A-Z]+\*/g, '')
      .replace(/\s+#.*$/, '')
      .replace(/\s*[\(\[][A-Za-z0-9]{2,6}[\)\]].*$/, '')
      .trim();
    if (!find(name) && !altName(name)) name = name.replace(/\s+\d+[a-z★]?$/i, '').trim(); // a trailing collector number, unless it is part of the name
    if (!name || q < 1 || q > 250) continue;
    if (sb || section === 'side') {
      out.side += q;
      continue;
    }
    const typed = name;
    let c = find(name);
    if (!c) {
      const real = altName(name) || labelled(name);
      if (real) {
        c = find(real);
        name = real;
      }
    }
    if (c) name = c.n;
    const pn = c && norm(typed) !== c._n && altName(typed) ? typed : ''; // printed under another name (Humongous Fungus is Corpsejack Menace)
    if (section === 'companion') {
      // the companion (outside the 100; Commander Companion offers it once per game for {3})
      if (!out.companion) out.companion = name;
      continue;
    }
    if ((section === 'commander' || isCmd) && !out.commander) {
      out.commander = name;
      continue;
    }
    if ((section === 'commander' || isCmd) && !out.partner) {
      out.partner = name;
      continue;
    }
    const k = norm(name);
    if (map.has(k)) map.get(k).q += q;
    else {
      const e = {n: name, q, l: false};
      if (pn) e.pn = pn;
      if (pm) {
        e.psc = pm[1].toLowerCase();
        if (pm[2]) e.pcn = pm[2];
      }
      map.set(k, e);
      out.cards.push(e);
    }
  }
  return out;
}

// ----- analysis -----
function ctxOf(d) {
  const cmd = d.format === 'commander' ? find(d.commander) : null,
    par = cmd && d.partner ? find(d.partner) : null;
  const ident =
    d.format === 'commander'
      ? cmd
        ? 'WUBRG'.split('').filter(k => cmd.ci.includes(k) || (par && par.ci.includes(k)))
        : []
      : d.colors || [];
  let focus = (d.colors || []).filter(x => ident.includes(x));
  if (!focus.length) focus = ident.slice();
  const strat = detectStrategy(cmd, d);
  if (par) {
    const ps = detectStrategy(par, d);
    strat.themes = strat.themes.concat(ps.themes.filter(t => !strat.themes.includes(t)));
    if (!strat.tribe) strat.tribe = ps.tribe;
  }
  // Bracket: a label only. It is worked out from what is in the deck (Game Changers, mass land denial) and never limits
  // what the deck may hold or what is recommended; gcCap stays unlimited so no gate downstream ever closes.
  let gcIn = (cmd && cmd.gc ? 1 : 0) + (par && par.gc ? 1 : 0);
  let mldIn = 0;
  if (d.format === 'commander')
    (d.cards || []).forEach(e => {
      const c = find(e.n);
      if (c && c.gc) gcIn += e.q;
      if (c && BTAGS.mld.has(c._n)) mldIn += e.q;
    });
  const bracket = d.format !== 'commander' ? 0 : bracketOf(gcIn, mldIn);
  return {
    engine: UP.kw ? commanderEngine([cmd, par]) : null,
    cmd,
    par,
    ident,
    focus,
    edh: cmd && EDH.map && EDH.key === cmd.n ? EDH : null,
    fall: cmd && UP.fbW && EDH.key === cmd.n && (EDH.fall || []).length && (!EDH.map || EDH.map.size < 60) ? EDH.fall : null,
    cap: TIERS[d.tier || 'budget'].cap,
    cmdThemes: strat.themes,
    xPlans: xPlansOf(cmd),
    cmdTribe: strat.tribe,
    tribe: d.tribe || strat.tribe,
    bracket,
    gcIn,
    mldIn,
    gcCap: Infinity,
    uni: universeOf(cmd) || universeOf(par)
  };
}
function isAimed(d) {
  if (!d.aims || !d.aims.length) return false;
  if (d.aims.includes('tribal') && !(d.tribe || ctxOf(d).cmdTribe)) return false;
  return d.format === 'commander' ? !!find(d.commander) : (d.colors || []).length > 0;
}
// Untouched precon copies count every precon card as "played". The least-played precon cards show roughly how many copies
// are untouched (u); taking that share out judges precon cards and outside cards by the players who built the deck.
function preDeflate(E) {
  if (!E || !E.map) return {u: 0, preK: new Set(), inc: x => x};
  if (E._pd && E._pd.m === E.map && E._pd.p === E.pre) return E._pd.v;
  const pre = E.pre && E.pre.list && E.pre.list.length ? E.pre : null,
    preK = new Set(pre ? pre.list.map(keyOf) : []);
  const vv = pre
    ? [...new Set(pre.list)]
        .map(find)
        .filter(c => c && !tags(c).land)
        .map(c => edhOf(E.map, c))
        .filter(Boolean)
        .map(x => x.inc)
        .sort((a, b) => a - b)
    : [];
  const u = vv.length >= 20 ? Math.min(0.6, vv[Math.floor(vv.length * 0.05)]) : 0;
  const v = {u, preK, inc: (c, inc) => (!u ? inc : preK.has(c._k) ? Math.max(0, inc - u) / (1 - u) : Math.min(1, inc / (1 - u)))};
  E._pd = {m: E.map, p: E.pre, v};
  return v;
}
// What this commander's players run: the sum of play rates of the ramp (draw, removal, wipe) cards on its EDHREC page, scaled
// for the cards the page leaves out (checked against ~4,000 real decks: within about one card), and its average land count.
function roleNeeds(E) {
  if (!E || !E.map || E.map.size < 60) return null;
  if (E._needs && E._needs.m === E.map && E._needs.r === UP.rdef && E._needs.p === E.pre) return E._needs.v;
  const D = UP.rdef ? preDeflate(E) : null,
    t = {ramp: 0, draw: 0, removal: 0, wipe: 0};
  E.map.forEach((x, k) => {
    const c = IDX.get(k);
    if (!c || tags(c).land) return;
    const inc = D ? D.inc(c, x.inc) : x.inc;
    tags(c).roles.forEach(r => {
      if (r in t) t[r] += inc;
    });
  });
  const F = {ramp: 1.15, draw: 1.25, removal: 1.25, wipe: 1.2},
    lim = {ramp: [5, 22], draw: [6, 22], removal: [4, 12], wipe: [1, 5]},
    v = {};
  for (const r in t) v[r] = Math.max(lim[r][0], Math.min(lim[r][1], Math.round(t[r] * F[r])));
  E._needs = {m: E.map, v, r: UP.rdef, p: E.pre};
  return v;
}
// How many finishers (cards that close a game: mass pumps, extra combats, drains, big evasive threats, "win the game") and how
// many protection pieces this commander's players run: the sum of those cards' play rates, as for roleNeeds.
function routeNeeds(E) {
  if (!E || !E.map || E.map.size < 60) return null;
  if (E._rn && E._rn.m === E.map) return E._rn.v;
  let fin = 0,
    prot = 0;
  E.map.forEach((x, k) => {
    const c = IDX.get(k);
    if (!c || tags(c).land) return;
    if (isFinisher(c)) fin += x.inc;
    const r = tags(c).roles;
    if (r.has('protect') || r.has('counter')) prot += x.inc;
  });
  const v = {fin: Math.max(2, Math.min(14, Math.round(fin * 1.1))), prot: Math.max(1, Math.min(10, Math.round(prot * 1.2)))};
  E._rn = {m: E.map, v};
  return v;
}
function targetsOf(d, ctx) {
  const a = d.aims || [];
  if (d.format === 'commander') {
    const N = UP.roleT && ctx && ctx.edh ? roleNeeds(ctx.edh) : null,
      base = {
        size: 100,
        lands: a[0] === 'lands' ? 39 : a[0] === 'aggro' ? 35 : 37,
        ramp: 10,
        draw: 10,
        removal: 8,
        wipe: a.includes('control') ? 4 : 3
      };
    return N ? Object.assign(base, N) : base;
  }
  return {
    size: 60,
    lands: a.includes('control') ? 26 : a[0] === 'aggro' || a[0] === 'burn' ? 22 : 24,
    ramp: ctx.ident.includes('G') ? 4 : 0,
    draw: 4,
    removal: 6,
    wipe: a.includes('control') ? 2 : 0
  };
}
// Copies allowed: one in Commander (singleton), four in Standard; basics and "any number of cards named" cards are unlimited.
function copyLimit(d, c) {
  if (c && (isBasic(c.n) || /a deck can have any number of cards named/i.test(c.o || ''))) return Infinity;
  const m = c && /a deck can have up to (\w+) cards named/i.exec(c.o || ''),
    W = {two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10};
  if (m) return W[m[1].toLowerCase()] || +m[1] || 1;
  return d.format === 'commander' ? 1 : 4;
}
const TYPE_ORDER = ['Creature', 'Planeswalker', 'Instant', 'Sorcery', 'Artifact', 'Enchantment', 'Land'];
function mainType(c) {
  const t = c ? frontType(c) : '';
  if (/\bLand\b/.test(t) && !/Creature/.test(t)) return 'Land';
  return TYPE_ORDER.find(k => new RegExp('\\b' + k + '\\b').test(t)) || 'Artifact';
}
// Lands = 31.5 + 1.6 × average mana value of the spells − 0.32 × cheap ramp (mana value 2 or less) + 0.72 × landfall cards,
// between 30 and 42. Commander decks with at least 40 spells; otherwise null (the starting target is used).
function landTarget(A, d) {
  if (!d || d.format !== 'commander') return null;
  // A deck with most of its spells: its own mana needs, from our formula (owner, 10 Nov: "if our deck needs mana to swing
  // because of its current state we need to adapt to the deck's mana needs"). A deck still being built has too few spells to
  // judge: it starts from the commander's EDHREC average when its page is loaded, else the starting target.
  if (A.nonland < 40) {
    const E = A.ctx && A.ctx.edh;
    return UP.edhLands && E && E.lands >= 25 && E.lands <= 45 ? Math.round(E.lands) : null;
  }
  return Math.max(30, Math.min(42, Math.round(31.5 + 1.6 * A.avg - 0.32 * A.cheapRamp + 0.72 * A.landfall)));
}
function legalIn(c, fmt) {
  return fmt === 'commander' ? c.cmd : c.std;
}
// Jobs shown to the player (Phase 3, owner's choice A, 24 Oct): the jobs scoring uses, plus counterspells and protection the
// rules reading finds (against Scryfall's tags: counterspells 90% -> 95% of cards found, protection 61% -> 69%, nearly as
// precise). Display only: scoring keeps tags(), and the reading done here is not kept on the card, so it never changes a score.
function jobsShown(c) {
  const tg = tags(c);
  if (c._js && c._js.t === tg) return c._js.v;
  const out = new Set(tg.roles);
  c._js = {t: tg, v: out};
  if (tg.land || typeof fnOf !== 'function') return out;
  try {
    const had = c._fn,
      f = fnOf(c, new Set(tg.roles)).roles;
    if (!had) delete c._fn;
    if (f.has('counterspell')) out.add('counter');
    if (f.has('protection')) out.add('protect');
  } catch (e) {}
  return out;
}
function analyze(d) {
  const ctx = ctxOf(d),
    T = targetsOf(d, ctx);
  const A = {
    ctx,
    T,
    size: (ctx.cmd || (d.format === 'commander' && d.commander) ? 1 : 0) + (ctx.par ? 1 : 0),
    lands: 0,
    nonland: 0,
    cmcSum: 0,
    curve: [0, 0, 0, 0, 0, 0, 0],
    roles: {ramp: 0, draw: 0, removal: 0, wipe: 0},
    unknown: [],
    over: [],
    offColor: [],
    illegal: [],
    dupes: [],
    gc: [],
    mld: [],
    turns: [],
    types: {},
    aim: (d.aims || []).map(() => 0),
    price: 0,
    priced: true,
    cheapRamp: 0,
    landfall: 0
  };
  if (ctx.cmd && ctx.cmd.p != null) A.price += ctx.cmd.p;
  if (ctx.par && ctx.par.p != null) A.price += ctx.par.p;
  [ctx.cmd, ctx.par].forEach(c => {
    if (c && c.gc) A.gc.push(c.n);
  });
  for (const e of d.cards) {
    A.size += e.q;
    const c = find(e.n);
    if (!c) {
      A.unknown.push(e.n);
      continue;
    }
    const tg = tags(c),
      pp = e.pp != null ? e.pp : c.p;
    if (pp != null) A.price += pp * e.q;
    else A.priced = false; // the chosen printing's price when one is set
    const mt = mainType(c);
    A.types[mt] = (A.types[mt] || 0) + e.q;
    if (tg.land) A.lands += e.q;
    else {
      A.nonland += e.q;
      A.cmcSum += c.cmc * e.q;
      A.curve[Math.min(6, Math.floor(c.cmc))] += e.q;
      for (const r in A.roles) if (tg.roles.has(r)) A.roles[r] += e.q;
      if (tg.roles.has('ramp') && (c.cmc || 0) <= 2) A.cheapRamp += e.q;
      if (THEMES.lands.re.test(c.o || '')) A.landfall += e.q;
      (d.aims || []).forEach((a, i) => {
        if (matchAim(c, a, ctx.tribe)) A.aim[i] += e.q;
      });
    }
    if (c.gc) A.gc.push(c.n);
    if (BTAGS.mld.has(c._n)) A.mld.push(c.n);
    if (BTAGS.turns.has(c._n)) A.turns.push(c.n);
    if (!isBasic(c.n)) {
      if (c.p != null && c.p > ctx.cap) A.over.push(c.n);
      if (ctx.ident.length || ctx.cmd) {
        if (!c.ci.every(x => ctx.ident.includes(x))) A.offColor.push(c.n);
      }
      if (!legalIn(c, d.format)) A.illegal.push(c.n);
      if (e.q > copyLimit(d, c)) A.dupes.push(c.n);
    }
  }
  A.avg = A.nonland ? A.cmcSum / A.nonland : 0;
  // The land target comes from the deck's own spells (owner's decision, Build 114): our formula, fitted to how many lands
  // players run with 52 commanders (EDHREC averages; misses by about 1.5 lands on commanders it was not fitted to, against
  // 2.2 for a flat 37). Until the deck has most of its spells, the starting target stands.
  {
    const t = landTarget(A, d);
    if (t != null) T.lands = t;
    else if (d.format === 'commander' && (d.aims || [])[0] === 'aggro' && A.avg > 3.2) T.lands = 37;
  }
  return A;
}

// ----- scoring & recommendations -----
// Tuning weights: how much what the commander's players actually run counts against theme-word matching.
// EDHREC lists a double-faced, adventure or split card under its front face; the card data uses the full name. Look up both.
function edhOf(map, c) {
  if (!map || !c) return undefined;
  const v = map.get(c._n);
  if (v !== undefined) return v;
  if (c._f === undefined) c._f = String(c.n).includes(' // ') ? norm(String(c.n).split(' // ')[0]) : c._n || norm(c.n);
  return c._f === c._n ? undefined : map.get(c._f);
}
let EDH_MISS = 3,
  W_INC = 10,
  W_SYN = 4,
  AIM_K = 1,
  STAPLE_K = 1,
  POP_K = 1;
const AIM_W = [5, 3.6, 2.6, 1.9, 1.4, 1];
const CORE = new Set(['sol ring', 'arcane signet', 'command tower']);
const TRIBE_SET = new Set(TRIBES);
function foreignTribe(c) {
  if (c._ft !== undefined) return c._ft;
  // "Non-Human creatures" is not a Human card, and a card that makes its own tokens of a type (Myr Battlesphere) brings its tribe with it.
  const re =
      /(?<![Nn]on-)\b([A-Z][a-z]+?)(?:s|es)? (?:creatures? you control|creatures? get|spells?|you control|cards? in|on the battlefield|gain|creature spell)/g,
    o = c.o || '';
  let m,
    r = '';
  while ((m = re.exec(o))) {
    const w = m[1] === 'Elv' ? 'Elf' : m[1];
    if (TRIBE_SET.has(w) && !new RegExp('\\b[Cc]reates? [^.]*\\b' + w + '\\b').test(o)) {
      r = w;
      break;
    }
  }
  return (c._ft = r);
}
// ----- build filters: creature types and keywords -----
// A filter is either a preference (matching cards score higher) or a rule. A creature-type rule applies to creature slots
// only; a keyword rule applies to theme slots only, so the deck still gets its lands, ramp, card draw and removal.
const KEYWORDS = {
  stun: {label: 'Stun', re: /stun counter/i},
  tap: {label: 'Tap / freeze', re: /\btap (?:target|up to|all)|doesn.t untap/i},
  flying: {label: 'Flying', re: /\bflying\b/i},
  trample: {label: 'Trample', re: /\btrample\b/i},
  haste: {label: 'Haste', re: /\bhaste\b/i},
  deathtouch: {label: 'Deathtouch', re: /\bdeathtouch\b/i},
  lifelink: {label: 'Lifelink', re: /\blifelink\b/i},
  vigilance: {label: 'Vigilance', re: /\bvigilance\b/i},
  menace: {label: 'Menace', re: /\bmenace\b/i},
  strike: {label: 'First / double strike', re: /\b(?:first|double) strike\b/i},
  hexproof: {label: 'Hexproof / ward', re: /\bhexproof\b|\bward\b/i},
  indestructible: {label: 'Indestructible', re: /\bindestructible\b/i},
  flash: {label: 'Flash', re: /\bflash\b/i},
  proliferate: {label: 'Proliferate', re: /\bproliferate/i},
  goad: {label: 'Goad', re: /\bgoad/i},
  mill: {label: 'Mill', re: /\bmills?\b/i},
  treasure: {label: 'Treasure', re: /\bTreasure token/},
  food: {label: 'Food', re: /\bFood token/},
  clue: {label: 'Clues / investigate', re: /\binvestigate|\bClue token/i},
  scry: {label: 'Scry / surveil', re: /\bscry \d|\bsurveil \d/i},
  bounce: {label: 'Bounce', re: /return (?:target|up to|each|all)[^.]*to (?:its|their) owner(?:'|’)s? hands?/i},
  exile: {label: 'Exile effects', re: /\bexile (?:target|up to|each|all)/i},
  copy: {label: 'Copy effects', re: /\bcopy (?:target|that|it|of)\b|create a token that.s a copy/i},
  sneak: {label: 'Ninjutsu / unblockable', re: /\bninjutsu\b|can.t be blocked/i}
};
function creatureTypes() {
  if (creatureTypes.n === LIB.length && creatureTypes.v) return creatureTypes.v;
  const m = new Map();
  for (const c of LIB) {
    if (!/\bCreature\b/.test(c.t)) continue;
    c.t.split(' // ').forEach(f => {
      if (!/\bCreature\b/.test(f)) return;
      (f.split('—')[1] || '')
        .trim()
        .split(/\s+/)
        .forEach(w => {
          if (/^[A-Z][A-Za-z'’-]+$/.test(w)) m.set(w, (m.get(w) || 0) + 1);
        });
    });
  }
  creatureTypes.n = LIB.length;
  return (creatureTypes.v = [...m.entries()]
    .filter(x => x[1] >= 2)
    .map(x => x[0])
    .sort());
}
function hasCType(c, t) {
  if (!/\bCreature\b/.test(c.t)) return false;
  if (/\bChangeling\b/.test(c.o || '')) return true;
  return c.t.split(' // ').some(f => new RegExp('\\b' + t + '\\b').test(f.split('—')[1] || ''));
}
function hasKey(c, k) {
  const K = KEYWORDS[k];
  return !!K && K.re.test(c.o || '');
}
// Card sets as a filter: SETCARDS holds, per set code, the cards printed in that set (every printing, read from Scryfall by
// the app). A set is a preference (matching cards score higher) or a rule (only cards printed in the chosen sets; basic
// lands always allowed). A set whose card list has not loaded yet matches only by each card's own shown printing.
let SETCARDS = new Map();
function inSets(c, d) {
  const ss = d.sets || [];
  return ss.some(code => c.sc === code || (SETCARDS.has(code) && SETCARDS.get(code).has(c._n)));
}
function mustOk(c, d) {
  if (d.setsMust && (d.sets || []).length && !isBasic(c.n) && !inSets(c, d)) return false;
  if (d.typesMust && d.types && d.types.length && /\bCreature\b/.test(frontType(c)) && !d.types.some(t => hasCType(c, t)))
    return false;
  if (d.keysMust && d.keys && d.keys.length && !tags(c).land) {
    const r = tags(c).roles;
    if (!['ramp', 'draw', 'removal', 'wipe'].some(j => r.has(j)) && !d.keys.some(k => hasKey(c, k))) return false;
  }
  return true;
}
let FILT_W = 6,
  FILT_MUST = 10;
function filtBonus(c, d) {
  let s = 0;
  const why = [],
    wt = 4,
    wk = d.keysMust ? FILT_MUST : FILT_W; // a type rule already narrows the creatures, so it needs no extra push
  (d.types || []).forEach(t => {
    if (hasCType(c, t)) {
      s += wt;
      why.push(t);
    } else if (new RegExp('\\b' + t + 's?\\b').test(c.o || '')) s += wt / 2;
  });
  (d.keys || []).forEach(k => {
    if (hasKey(c, k)) {
      s += wk;
      why.push(KEYWORDS[k].label);
    }
  });
  if ((d.sets || []).length && !d.setsMust && inSets(c, d)) {
    s += FILT_W;
    why.push('From your chosen set');
  }
  // Theme first (a generation choice): cards from the commander's own set family or of its creature types are pushed up
  // like a preferred set, so the deck is built from the theme and the rest of the card pool tops it up.
  if (d.themeFirst && d.format === 'commander' && !isBasic(c.n) && themeOf(c, themeCtxC(d))) s += UP.tf;
  return {s, why};
}
const FAST_MANA = new Set(
  [
    'Sol Ring',
    'Mana Crypt',
    'Mana Vault',
    'Chrome Mox',
    'Mox Diamond',
    'Jeweled Lotus',
    'Lotus Petal',
    'Mox Opal',
    'Mox Amber',
    'Grim Monolith',
    'Ancient Tomb',
    'Arcane Signet',
    'Fellwar Stone',
    'Mind Stone',
    'Simian Spirit Guide',
    'Elvish Spirit Guide',
    'Dark Ritual',
    'Cabal Ritual',
    'Culling the Weak',
    "Jeska's Will",
    'Gemstone Caverns'
  ].map(n => norm(n))
);

// ----- card interactions (owner, 7 Nov; roadmap 5.2): what a card's effects produce and what its triggers wait for -----
// A pair "works together" when one card produces what the other's trigger waits for (a sacrifice outlet and a death trigger,
// a token maker and "whenever a creature enters", lifelink and "whenever you gain life"). Shown in the card window; it does not
// change any score.
const IX = [
  {k: 'dies', label: 'creatures dying',
    gives: /\bsacrifices? (?:a|another|one|two|three|X|any number of)\b[^.]*\bcreatures?\b|\bdestroy (?:target|all|each)\b[^.]*\bcreatures?\b|\bdeals? (?:\d+|X) damage to (?:each|target|any)\b/i,
    wants: /\bwhenever\b[^.]*?\bcreatures?\b[^.,]*?\b(?:die|dies|is put into a graveyard from the battlefield)\b/i},
  {k: 'enters', label: 'creatures entering',
    gives: /\bcreates? [^.]*\b(?:creature )?tokens?\b|\breturn[^.]*creature cards?[^.]* to the battlefield\b|\bput[^.]*creature cards?[^.]* onto the battlefield\b/i,
    wants: /\bwhenever (?:a|another|one or more)(?: nontoken)? creatures?(?: tokens?)?(?: you control)? enters?\b|\bwhenever (?:a|one or more) tokens? (?:you control )?enters?\b/i},
  {k: 'life', label: 'life gain',
    gives: /\byou gain (?:\d+|X|that much) life\b|\bgains? (?:\d+|X) life\b|\blifelink\b/i,
    wants: /\bwhenever you gain life\b|\bwhenever you gain \d+ or more life\b/i},
  {k: 'draw', label: 'card draw',
    gives: /\bdraws? (?:a|an|one|two|three|four|X|\d+) (?:additional )?cards?\b/i,
    wants: /\bwhenever you draw (?:a|your second) card\b|\bwhenever a player draws a card\b/i},
  {k: 'counters', label: '+1/+1 counters',
    gives: /\bput (?:a|an|one|two|three|X|\d+|that many) \+1\/\+1 counters?\b/i,
    wants: /\bwhenever (?:one or more )?\+1\/\+1 counters? (?:are|is) put\b/i},
  {k: 'lands', label: 'lands entering',
    gives: /\bsearch your library for [^.]*\bland cards?[^.]* onto the battlefield\b|\bput (?:a|up to \w+) land cards?[^.]* onto the battlefield\b|\bplay an additional land\b/i,
    wants: /\bwhenever a land (?:you control )?enters\b|\blandfall\b/i},
  {k: 'spells', label: 'instants and sorceries',
    type: /\b(?:Instant|Sorcery)\b/,
    wants: /\bwhenever you cast (?:an? )?(?:instant|sorcery|noncreature)\b|\bmagecraft\b|\bprowess\b/i},
  {k: 'graveyard', label: 'cards going to the graveyard',
    gives: /\bmills? (?:a|one|two|three|four|X|\d+)\b|\bdiscards? (?:a|one|two|X|\d+|that) cards?\b|\bput the top [^.]* into (?:your|their) graveyard\b/i,
    wants: /\bwhenever (?:one or more )?(?:cards?|creature cards?)[^.]* (?:is|are) put into your graveyard\b|\bwhenever you discard\b/i},
  {k: 'sacrifice', label: 'sacrifices',
    gives: /\bsacrifice (?:a|another|one or more)\b/i,
    wants: /\bwhenever you sacrifice\b/i}
];
function ixOf(c) {
  if (c._ix) return c._ix;
  const o = String(c.o || '').replace(/\([^)]*\)/g, ''),
    t = frontType(c),
    gives = new Set(),
    wants = new Set();
  for (const x of IX) {
    if ((x.gives && x.gives.test(o)) || (x.type && x.type.test(t))) gives.add(x.k);
    if (x.wants.test(o)) wants.add(x.k);
  }
  return (c._ix = {gives, wants});
}
/** Cards in deck d that work with card c: c feeds their triggers or they feed c's. [{n, why}], at most `max`. */
// Tokens a deck needs (owner, 8 Nov: "If tokens are required for a deck they should be added to the deck list but not counted
// against the deck's 100. Each card that mentions creating a token should add 1 token to the deck list of the required type.
// Tokens should show at the very bottom of a deck"). Read from the rules text: "create two 1/1 green Saproling creature tokens"
// is a 1/1 green Saproling; Treasure, Food, Clue …; the keywords that make tokens (investigate a Clue, afterlife a Spirit,
// fabricate a Servo …); "a token that's a copy" is a Copy. Each card adds one of each kind it makes.
const TOKEN_KW = [
  [/\binvestigates?\b/i, 'Clue'],
  [/\bAfterlife \d/i, '1/1 white and black Spirit with flying'],
  [/\bFabricate \d/i, '1/1 colorless Servo artifact'],
  [/\bamass (?:\w+ )?(\d+|X)\b/i, '0/0 black Army'],
  [/\bincubate\b/i, 'Incubator'],
  [/\bLiving weapon\b/i, '0/0 black Phyrexian Germ'],
  [/\b(?:Embalm|Eternalize|Encore|Myriad|Offspring|populate|Squad)\b/i, 'Copy'],
  [/\bMobilize \d/i, '1/1 red Warrior'],
  [/\bthe Ring tempts you\b/i, ''],
  [/\bExplores?\b.*\bMap token\b/i, 'Map']
];
function tokenKindsOf(c) {
  if (!c) return [];
  const o = String(c.o || '').replace(/\([^)]*\)/g, ' '),
    out = new Set();
  const COUNT = '(?:a number of|twice that many|three times that many|any number of|one or more|that many|an|a|one|two|three|four|five|six|seven|eight|nine|ten|x|\\d+)';
  const re = new RegExp(`\\bcreates? (?:${COUNT}\\s+)?(?:(?:tapped|untapped)\\s+)?(?:(?:and\\s+)?attacking\\s+)?(.{1,90}?)\\s+tokens?\\b`, 'gi');
  for (const m of o.matchAll(re)) {
    // "If an effect would create one or more tokens" (Doubling Season), "Whenever you create or sacrifice a token": none made here
    if (/\bwould\s*$/i.test(o.slice(Math.max(0, m.index - 8), m.index)) || /^or\b/i.test(m[1].trim())) continue;
    let desc = m[1].trim();
    if (new RegExp(`^${COUNT}$`, 'i').test(desc)) { if (/\bcop(?:y|ies)\b/i.test(o.slice(m.index, m.index + m[0].length + 40))) out.add('Copy'); continue; }   // "create two tokens that are copies" (Saw in Half)
    if (/^(?:a|an)?\s*$/i.test(desc) || /\bcopy\b/i.test(desc) || /^token that'?s a copy/i.test(m[0].slice(m[0].indexOf(desc)))) { out.add('Copy'); continue; }
    if (/that'?s a copy|copy of/i.test(o.slice(m.index, m.index + m[0].length + 30)) && /^(?:a|an|the)?\s*$/i.test(desc)) { out.add('Copy'); continue; }
    const named = desc.match(/^([A-Z][^,]+?),\s+(?:a|an)\s+/);   // "Marit Lage, a legendary 20/20 black Avatar"
    if (named) { out.add(named[1]); continue; }
    desc = desc.replace(/^(?:twice|three times)\s+x\s+/i, '').replace(/^(?:legendary|snow)\s+/i, '').replace(/\s*\bcreature\b/i, '').replace(/\s+/g, ' ').trim();
    if (!desc || desc.length > 60 || /^(?:tapped|untapped|attacking|token)$/i.test(desc) || /\b(?:your|their|its|that|those|this|each|for)\b/i.test(desc)) continue;
    const after = (o.slice(m.index + m[0].length).match(/^\s+with\s+([a-z ,]+?)(?=[.;"]|\s+(?:and (?:a|an|that|they|it|put|attach|gain|you)|for|that|where|until|under|attached|tapped|equal)\b|$)/i) || [])[1];
    const kw = (after || '').split(/,\s*|\s+and\s+/).map(x => x.trim()).filter(x => /^(?:flying|haste|vigilance|trample|lifelink|deathtouch|menace|reach|first strike|double strike|indestructible|hexproof|defender|decayed|ward \d|prowess)$/i.test(x));
    out.add(desc + (kw.length ? ' with ' + kw.join(', ') : ''));
  }
  // a second kind in the same sentence: "… token with deathtouch and a 3/3 colorless Phyrexian Wurm artifact creature token with
  // lifelink" (Wurmcoil Engine)
  for (const sen of o.split(/(?<=\.)\s+/).filter(x => /\bcreates?\b/i.test(x)))
    for (const m of sen.matchAll(/\band (?:a|an|one|two) (\d+\/\d+ [^.]*?) tokens?\b(?:\s+with\s+([a-z ,]+?))?(?=[.;,]|\s+and\b|$)/gi)) {
      const desc = m[1].replace(/\s*\bcreature\b/i, '').replace(/\s+/g, ' ').trim();
      const kw = (m[2] || '').split(/,\s*|\s+and\s+/).map(x => x.trim()).filter(Boolean);
      if (desc.length <= 60) out.add(desc + (kw.length ? ' with ' + kw.join(', ') : ''));
    }
  for (const [rx, name] of TOKEN_KW) if (name && rx.test(o)) out.add(name);
  return [...out];
}
function deckTokens(d) {
  const by = new Map(),
    add = (n, q, from) => tokenKindsOf(find(n)).forEach(k => { const x = by.get(k) || {n: k, q: 0, from: []}; x.q += q; if (!x.from.includes(from)) x.from.push(from); by.set(k, x); });
  [d.commander, d.partner].filter(Boolean).forEach(n => add(n, 1, n));
  (d.cards || []).forEach(e => add(e.n, e.q || 1, e.n));
  return [...by.values()].sort((a, b) => b.q - a.q || a.n.localeCompare(b.n));
}
// How many cards in the deck this card works with (feeds, or is fed by), counted from the deck's totals per interaction (kept
// until the deck's list changes), so each candidate costs a few set lookups, not a pass over the deck.
const IXD = new Map();
function ixDeckMatches(d, c) {
  // the deck's list is compared name by name with the one the totals were counted from (owner, 10 Nov, speed: joining the 100
  // names into a string on each of thousands of calls cost about 1 s per deck opened; same answers)
  const cards = d.cards || [];
  let t = IXD.get(d.id || '');
  const same = t && t.names.length === cards.length && cards.every((e, i) => e.n === t.names[i]);
  if (!same) t = null;
  const sig = t ? t.sig : cards.map(e => e.n).join('|'), k = d.id || sig;
  if (!t) t = IXD.get(k);
  if (!t || t.sig !== sig) {
    const gives = {}, wants = {};
    for (const e of d.cards || []) {
      const x = find(e.n);
      if (!x) continue;
      const ix = ixOf(x);
      for (const r of IX) { if (ix.gives.has(r.k)) gives[r.k] = (gives[r.k] || 0) + 1; if (ix.wants.has(r.k)) wants[r.k] = (wants[r.k] || 0) + 1; }
    }
    t = {sig, gives, wants, names: cards.map(e => e.n), set: new Set(cards.map(e => e.n))};
    IXD.set(k, t);
  }
  const me = ixOf(c), inDeck = t.set.has(c.n);
  let n = 0;
  // matches per interaction (a card that both feeds and wants the same thing counts on each side); a card already in the deck
  // leaves itself out of the totals
  for (const r of IX) {
    const g = me.gives.has(r.k), w = me.wants.has(r.k);
    if (g) n += Math.max(0, (t.wants[r.k] || 0) - (inDeck && w ? 1 : 0));
    if (w) n += Math.max(0, (t.gives[r.k] || 0) - (inDeck && g ? 1 : 0));
  }
  return n;
}
function worksWith(d, c, max) {
  if (!d || !c) return [];
  const me = ixOf(c),
    out = [];
  for (const e of d.cards || []) {
    const x = find(e.n);
    if (!x || x._n === c._n) continue;
    const ix = ixOf(x),
      why = IX.filter(r => (me.gives.has(r.k) && ix.wants.has(r.k)) || (ix.gives.has(r.k) && me.wants.has(r.k))).map(r => r.label);
    if (why.length) out.push({n: x.n, why});
    if (out.length >= (max || 8)) break;
  }
  return out;
}

// Rules audit: which cards Guided Play cannot fully run by itself.
//   node tools/rules-audit.mjs cards.json [report.json]
// cards.json is a list of Scryfall card objects (for example a search ordered by EDHREC rank).
// For each card it reports what players would have to do by hand: triggers the game never fires,
// effects it cannot apply, and static rules text it does not enforce. Prints a summary grouped by
// the kind of gap, most common first, so the next rules work goes where real decks need it.

import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { scryfallToDefinition } from '../src/data/card-api.js';
import { analyzeDefinitionSupport } from '../src/engine/abilities.js';
import { MECHANICS } from '../src/data/mechanics.js';
import { castText, effectRunsByItself, giftSpec } from '../src/game/ops.js';
import { enchantSupported } from '../src/game/attachments.js';
import { upkeepActionCost } from '../src/engine/keyword-triggers-b49.js';

const [input, output] = process.argv.slice(2);
if (!input) { console.error('usage: node tools/rules-audit.mjs cards.json [report.json]'); process.exit(1); }
const raw = readFileSync(input);
const parsed = JSON.parse(input.endsWith('.gz') ? gunzipSync(raw) : raw);
const cards = Array.isArray(parsed) ? parsed : parsed.cards;   // a Scryfall list, or tests/fixtures/top-commander-cards.json.gz

// Static lines are not run through one checker in the game (keywords, anthems and restrictions are
// each handled in their own place), so they are judged here: an instant's or sorcery's text is the
// spell itself (checked above), a keyword uses the terms key's automation rating, and anything else
// is listed as "not verified" rather than counted as a gap.
const KEYWORDS = MECHANICS.filter(x => x.kind !== 'concept').sort((a, b) => b.name.length - a.name.length);
function staticVerdict(line, def) {
  const text = line.replace(/^Static: /, '').trim();
  if (/Instant|Sorcery/i.test(def.typeLine || '')) return 'spell-text';
  // Auras: the game asks what it enchants and keeps it attached (creature, land, permanent, player, a graveyard card …).
  const enchant = text.match(/^Enchant ([^(\n]+?)\s*(?:\(|$)/i);
  if (enchant && enchantSupported(enchant[1])) return 'auto';
  // "Threshold — This creature gets +1/+1 and has deathtouch as long as there are seven or more cards in your graveyard.":
  // read by combat.js conditionalSelf for these conditions.
  const cond = text.replace(/\([^()]*\)/g, '').trim().match(/^(?:[A-Z][a-z]+(?: [a-z]+)? — )?(?:This creature|~|[A-Z][^ ]*(?: [A-Z][^ ]*)*) (?:gets [+-]\d+\/[+-]\d+(?: and has [a-z ,]+?)?|has [a-z ,]+?) as long as (.+?)\.?$/);
  if (cond && /^(there are \w+ or more cards in your graveyard|there are \w+ or more card types among cards in your graveyard|you control \w+ or more (?:artifacts|creatures|enchantments|lands)|you have no cards in hand)$/i.test(cond[1])) return 'auto';
  // Reminder text is not rules text: "Encore {3}{R} (… create a token copy …)" is the keyword Encore, not "create".
  const words = text.replace(/\([^()]*\)/g, '').trim().split(/\s*,\s*/);
  const terms = words.map(w => KEYWORDS.find(k => new RegExp(`^${k.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(w)));
  // Static lines the game applies elsewhere (cost changes in casting.js and rules.js activationReduction).
  const STATIC_AUTO = [/^Domain — This spell costs \{\d+\} less to cast for each basic land type among lands you control\.?$/i, /^Domain — [^.]*?(?:power and toughness are each|power is|toughness is) equal to (?:twice )?the number of basic land types among lands you control\.?$/i, /^(?:[A-Z][a-z]+ — )?Equipment you control have equip \{0\}(?: as long as you control three or more artifacts)?\.?$/i, /^[A-Za-z ,]*spells you cast cost \{\d+\} less to cast\.?$/i, /^Equip abilities you activate cost \{\d+\} less to activate\.?$/i, /^(?:[A-Z][A-Za-z ]+ — )?You may play lands and cast spells from among cards exiled with this [a-z]+\.?$/];   // read by exilePlayPermission (effects-catalog.js)
  const sentences = text.replace(/\([^()]*\)/g, '').split(/(?<=\.)\s+/).map(x => x.trim()).filter(Boolean);
  if (sentences.length && sentences.every(x => STATIC_AUTO.some(r => r.test(x)))) return 'auto';
  // Echo and cumulative upkeep are automatic only for a mana cost (or "Pay N life" upkeep).
  // Build 79: an action cost the game can do (keyword-triggers-b49 upkeepActionCost) counts as automatic, choices included.
  if (/^Cumulative upkeep/i.test(text) && !/^Cumulative upkeep(?:\s*[—-]\s*|\s+)(?:(?:\{[^}]+\})+|Pay \d+ life\.?|Pay (?:\{[^}]+\})+ and \d+ life\.?)\s*(?:\(|$)/i.test(text) && !(upkeepActionCost(text, 'Cumulative upkeep', 1) && upkeepActionCost(text, 'Cumulative upkeep', 2))) return 'manual:Cumulative upkeep';
  if (/^Echo\b/i.test(text) && !/^Echo\s+(?:\{[^}]+\})+\s*(?:\(|$)/i.test(text) && !upkeepActionCost(text, 'Echo')) return 'manual:Echo';
  if (terms.every(Boolean)) {
    const worst = terms.some(t => t.automation === 'manual') ? 'manual' : terms.some(t => t.automation === 'partial') ? 'partial' : 'auto';
    return worst === 'auto' ? 'auto' : `${worst}:${terms.find(t => t.automation === worst).name}`;
  }
  return 'unverified';
}

// One short label per gap, so similar gaps group together.
function gapKind(line) {
  const t = line.replace(/^(Activated|Trigger|Spell|Static): /, '');
  if (/^Trigger: The game never fires/.test(line) || /never fires/.test(t)) {
    const m = t.match(/"(.+?)"/);
    const when = (m?.[1] || '').replace(/\b[A-Z][a-z]+(?:,? [A-Z][a-z']+)*\b/g, w => w).toLowerCase();
    if (/becomes? the target/.test(when)) return 'Trigger never fires: becomes the target';
    if (/search/.test(when)) return 'Trigger never fires: searching a library';
    if (/\bcycle|cycling/.test(when)) return 'Trigger never fires: cycling';
    if (/\bmill|put into .* graveyard from (?:your library|anywhere)|cards? (?:are|is) put into/.test(when)) return 'Trigger never fires: cards put into graveyard';
    if (/\bactivate/.test(when)) return 'Trigger never fires: activating abilities';
    if (/\bcounter(?:ed)?\b/.test(when) && /spell/.test(when)) return 'Trigger never fires: spells countered';
    if (/\bexile|exiled/.test(when)) return 'Trigger never fires: exiling';
    if (/\buntap/.test(when)) return 'Trigger never fires: untapping';
    if (/\bdealt damage|is dealt|deals damage/.test(when)) return 'Trigger never fires: noncombat damage';
    if (/\bcopy|copied/.test(when)) return 'Trigger never fires: copying';
    if (/\btransform|turned face up|face up/.test(when)) return 'Trigger never fires: transform / face up';
    if (/\bcombat|attack|block/.test(when)) return 'Trigger never fires: other combat wording';
    if (/\benter|leaves|dies|sacrifice/.test(when)) return 'Trigger never fires: other enter/leave/die wording';
    if (/\bcast/.test(when)) return 'Trigger never fires: other cast wording';
    if (/\bbeginning of|end of/.test(when)) return 'Trigger never fires: other step/phase wording';
    if (/\bgain life|lose life|loses life/.test(when)) return 'Trigger never fires: other life wording';
    if (/\bdraw/.test(when)) return 'Trigger never fires: other draw wording';
    if (/\bcounter/.test(when)) return 'Trigger never fires: counters placed/removed';
    return 'Trigger never fires: other';
  }
  if (/^Static:/.test(line)) {
    if (/can't|cannot/i.test(t)) return 'Static: restriction ("can\'t …") not enforced';
    if (/\bcost(?:s)? \{?\d|cost .* less|cost .* more/i.test(t)) return 'Static: cost change';
    if (/\bif .* would|instead/i.test(t)) return 'Static: replacement effect ("would … instead")';
    if (/you may (?:play|cast)|from (?:your graveyard|the top of your library|exile)/i.test(t)) return 'Static: play/cast from another zone';
    if (/\bget [+-]|have |gains? /i.test(t)) return 'Static: other continuous effect';
    if (/^(Equip|Enchant|Crew|Ward|Protection|Landwalk|\w+walk|Cascade|Convoke|Affinity|Storm|Partner|Annihilator|Myriad|Prowess|Undying|Persist|Flanking|Bushido|Exalted|Extort|Evolve|Changeling|Devoid|Delve|Improvise|Embalm|Eternalize|Unearth|Ninjutsu|Madness|Suspend|Mutate|Companion|Hexproof from|Split second|Shroud|Horsemanship|Banding|Phasing|Rampage|Bloodthirst|Fabricate|Afterlife|Riot|Training|Disturb|Daybound|Decayed|Boast|Foretell|Casualty|Blitz|Backup|Bargain|Craft|Disguise|Offspring|Gift)\b/i.test(t)) return `Static: keyword ${t.split(/[\s—(]/)[0]}`;
    return 'Static: other rules text';
  }
  if (/^Spell:/.test(line)) {
    const alt = t.match(/^(\w+) is not fully automated/);
    return alt ? `Spell: ${alt[1]}` : 'Spell: effect not applied automatically';
  }
  if (/^Keyword:/.test(line)) return line;
  if (/^Activated:/.test(line)) return 'Activated ability: effect not applied automatically';
  if (/^Trigger:/.test(line)) return 'Trigger fires, but its effect is resolved by hand';
  return 'Other';
}

const rows = [];
for (const [rank, card] of cards.entries()) {
  if (!card.oracle_text && !card.card_faces) continue;
  const printed = scryfallToDefinition(card);
  // Spells are checked as the game casts them: castText drops keyword lines (Overload {6}{U}, Flashback …),
  // casting permissions and additional costs, which are handled when casting, not on resolution.
  const def = /Instant|Sorcery/i.test(printed.typeLine || '') ? { ...printed, oracleText: castText(printed.oracleText) } : printed;
  let report;
  try { report = analyzeDefinitionSupport(def); } catch (error) { report = { unsupported: [`Other: audit failed (${error.message})`] }; }
  // Gift: the spell must also run with the gift promised (its "if the gift was promised" sentences kept).
  if (giftSpec(printed) && /Instant|Sorcery/i.test(printed.typeLine || '')) {
    try { const g = analyzeDefinitionSupport({ ...printed, oracleText: castText(printed.oracleText, { gift: true }) }); report.unsupported = [...new Set([...report.unsupported, ...g.unsupported.filter(u => u.startsWith('Spell'))])]; } catch {}
  }
  // Cleave: the spell must also run with the words in square brackets removed (cast for its cleave cost).
  if (/(?:^|\n)\s*Cleave \{/i.test(printed.oracleText || '') && /Instant|Sorcery/i.test(printed.typeLine || '')) {
    try { const g = analyzeDefinitionSupport({ ...printed, oracleText: castText(printed.oracleText, { cleave: true }) }); report.unsupported = [...new Set([...report.unsupported, ...g.unsupported.filter(u => u.startsWith('Spell'))])]; } catch {}
  }
  const gaps = [], unverified = [];
  // Triggered and activated effects: the game's own fallbacks decide (see effectRunsByItself).
  const runs = new Set([...(report.triggers || []).filter(t => t.fires !== false && effectRunsByItself(t.effect, def.name)).map(t => `Trigger: ${t.text}`),
    ...(report.activated || []).filter(a => effectRunsByItself(a.ability?.effect, def.name)).map(a => `Activated: ${a.ability.text}`)]);
  for (const u of report.unsupported.filter(x => !runs.has(x))) {
    if (u.startsWith('Static: ')) {
      const v = staticVerdict(u, def);
      if (v === 'spell-text' || v === 'auto') continue;
      if (v === 'unverified') { unverified.push(u.slice(8)); continue; }
      gaps.push(`Keyword: ${v.split(':')[1]} (${v.startsWith('manual') ? 'by hand' : 'common cases only'})`);
      continue;
    }
    gaps.push(u.startsWith('Trigger: ') && (report.triggers || []).some(t => !t.fires && u.includes(t.text)) ? `Trigger: The game never fires "${(report.triggers.find(t => !t.fires && u.includes(t.text)) || {}).trigger}"` : u);
  }
  // "Pay 2 life or {2}" (Tidal Control): the game would charge both costs, so the card is not automatic.
  for (const a of report.activated || []) if (!a.ability?.costChoice && /\bPay \d+ life or \{|\{[^}]+\} or pay \d+ life/i.test(a.ability?.cost || '')) gaps.push(`Activated: ${a.ability.text} (a choice between two costs)`);
  rows.push({ rank: rank + 1, name: card.name, type: def.typeLine, automated: !gaps.length, gaps, unverified, kinds: [...new Set(gaps.map(gapKind))] });
}

const auto = rows.filter(r => r.automated).length;
const byKind = new Map();
for (const r of rows) for (const k of r.kinds) byKind.set(k, [...(byKind.get(k) || []), r]);
const kinds = [...byKind.entries()].sort((a, b) => b[1].length - a[1].length);
const unverified = rows.filter(r => r.automated && r.unverified.length).length;
console.log(`${rows.length} cards: ${auto} with nothing to do by hand (${Math.round(100 * auto / rows.length)}%; ${unverified} of them have other rules text this audit cannot verify), ${rows.length - auto} need something by hand.\n`);
for (const [kind, list] of kinds) console.log(`${String(list.length).padStart(4)}  ${kind}  — e.g. ${list.slice(0, 4).map(r => r.name).join(', ')}`);
if (output) writeFileSync(output, JSON.stringify({ total: rows.length, automated: auto, unverified, kinds: kinds.map(([kind, list]) => ({ kind, count: list.length, cards: list.map(r => r.name) })), cards: rows }, null, 1));

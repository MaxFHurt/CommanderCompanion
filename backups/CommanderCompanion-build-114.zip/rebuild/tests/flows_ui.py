"""More Guided/Free Play flows on one device: mulligan, search, scry, by-hand cards, discard, win, Free Play, Deck Builder link."""
import asyncio, os, sys
from playwright.async_api import async_playwright
sys.path.insert(0, os.path.dirname(__file__))
from shots import PHONE, IPAD, OUT, URL
from game_ui import new_page, start_guided, continue_to_game, tap_curtain, pass_all, check, results, FIX, full_log

HOST = "{ playerId: null, isHost: true }"
SETUP = """async (rows) => {
  const { getSession } = await import('./src/app/session.js');
  const s = getSession(), g = s.game;
  // Test setup only: act as a room host for the edits, then return to one shared device.
  const deviceMode = g.deviceMode; g.deviceMode = 'multi-device';
  for (const [i, name, to] of rows) {
    const p = g.players[i];
    const c = [...p.deck.remainingLibrary, ...p.deck.hand].find(c => g.cardDefinitions[c.definitionId].name === name && !c.__used);
    if (!c) throw new Error('missing ' + name);
    c.__used = true;
    s.controller.dispatch({ type: 'edit', edit: { kind: 'move', instanceId: c.instanceId, to } }, { playerId: null, isHost: true });
  }
  for (const p of g.players) for (const c of p.deck.battlefield) { c.enteredTurn = 0; c.controlSinceTurn = 0; }
  s.controller.dispatch({ type: 'edit', edit: { kind: 'note', text: 'ready' } }, { playerId: null, isHost: true });
  g.deviceMode = deviceMode; s.actAs(s.actingAs());
}"""

async def keep_both(page, mulligan_first=False):
    await page.wait_for_selector('text=opening hand')
    if mulligan_first:
        await page.click('.modal .btn--cancel')           # mulligan (free)
        await page.wait_for_timeout(200)
        await page.click('.modal .btn--cancel')           # second mulligan → bottom 1
        await page.wait_for_selector('text=put on the bottom')
        check('keep is disabled until a card is chosen for the bottom', await page.locator('#keepHand').is_disabled())
        await page.locator('.modal .card').first.click()
        await page.screenshot(path=f'{OUT}phone-mulligan.png')
    await page.click('#keepHand')
    await page.wait_for_selector('.curtain'); await tap_curtain(page)
    await page.wait_for_selector('text=opening hand')
    await page.click('#keepHand')
    await page.wait_for_selector('.curtain'); await tap_curtain(page)
    await page.wait_for_selector('.zone--hand')

async def card(page, zone, name):
    await page.click(f'.zone--{zone} .card[aria-label="{name}"]')

async def guided(browser):
    page = await new_page(browser, PHONE)
    await start_guided(page, ('simic', 'rakdos'))
    await continue_to_game(page)
    await keep_both(page, mulligan_first=True)
    check('hand is 7 after mulligan to 6 + draw', await page.locator('.zone--hand .card').count() == 7, str(await page.locator('.zone--hand .card').count()))
    await page.evaluate(SETUP, [[0, 'Forest', 'battlefield'], [0, 'Forest', 'battlefield'], [0, 'Island', 'battlefield'], [0, 'Island', 'battlefield'], [0, 'Rampant Growth', 'hand'], [0, 'Opt', 'hand'], [0, 'Colossal Dreadmaw', 'hand'], [0, 'Grizzly Bears', 'battlefield'],
                                [1, 'Swamp', 'battlefield'], [1, 'Mountain', 'battlefield'], [1, 'Mountain', 'battlefield'], [1, 'Storm the Vault Oddity', 'hand']])
    await page.wait_for_timeout(200)
    # Library search
    await card(page, 'hand', 'Rampant Growth'); await page.click('.modal .btn--confirm'); await pass_all(page)
    await page.wait_for_selector('text=search your library')
    await page.screenshot(path=f'{OUT}phone-search.png')
    await page.locator('.pick').first.click(); await page.click('#decisionConfirm')
    await pass_all(page)
    check('searched land arrived', await page.locator('.zone--lands .card').count() == 5, str(await page.locator('.zone--lands .card').count()))
    # Scry (arrange)
    await card(page, 'hand', 'Opt'); await page.click('.modal .btn--confirm'); await pass_all(page)
    await page.wait_for_selector('.arrange')
    await page.screenshot(path=f'{OUT}phone-scry.png')
    await page.click('[data-move="other"]'); await page.click('.modal .btn--confirm')
    await pass_all(page)
    check('Opt resolved', 'Opt resolves' in await full_log(page))
    # Card detail explains why something cannot be played
    await card(page, 'hand', 'Colossal Dreadmaw')
    why = await page.locator('.card-detail__why').count()
    check('unplayable card explains why', why == 1)
    await page.click('.modal .btn--cancel')
    # End turn → Lex (rakdos) → by-hand card
    for _ in range(5):
        if await page.locator('.curtain').count() or await page.locator('.modal').count(): break
        btn = page.locator('.play-btn[data-act="next-phase"], .play-btn[data-act="end-turn"]')
        if await btn.count(): await btn.first.click()
        await page.wait_for_timeout(250)
    await pass_all(page)
    if await page.locator('#discardConfirm').count():
        for c in await page.locator('.modal .card').all():
            if await page.locator('#discardConfirm').is_enabled(): break
            await c.click()
        await page.screenshot(path=f'{OUT}phone-discard.png')
        await page.click('#discardConfirm'); await pass_all(page)
    name = (await page.locator('.rail-name strong').text_content()).strip()
    check('turn passed to Lex', name == 'Lex', name)
    await card(page, 'hand', 'Storm the Vault Oddity'); await page.click('.modal .btn--confirm')
    await pass_all(page)
    if not await page.locator('.guided__steps').count():
        labels = await page.eval_on_selector_all('.play-btn', 'els => els.map(e => e.dataset.label)')
        check('unsupported card asks to Resolve by hand', labels == ['Resolve'], str(labels))
        await page.click('.play-btn[data-act="prompt"]')
    await page.wait_for_selector('.guided__steps')
    await page.screenshot(path=f'{OUT}phone-guided.png')
    # the toolbox: stage "gain 2 life" for you, then Done; on one device the table is asked to agree
    life0 = await page.evaluate("window.__cc?.session?.view?.()?.players?.find(p => p.isYou)?.life ?? null")
    await page.click('[data-tb-tool="life-gain"][data-tb-ref="you"]')
    await page.wait_for_selector('.stepper [data-step="1"]')
    await page.locator('.stepper [data-step="1"]').last.click()   # 1 → 2
    await page.locator('.modal .btn--confirm').last.click(); await page.wait_for_timeout(200)
    check('toolbox: the step is staged and listed', await page.locator('.toolbox__steps li').count() == 1, await page.locator('.toolbox__steps').text_content())
    await page.screenshot(path=f'{OUT}phone-toolbox.png')
    await page.locator('.modal .btn--confirm').last.click(); await page.wait_for_timeout(300)
    if await page.locator('text=Does everyone agree?').count():
        await page.locator('.modal .btn--confirm').last.click(); await page.wait_for_timeout(300)
    log = await full_log(page)
    check('by-hand card finished with the toolbox step (gains 2 life, applied by hand)', 'gains 2 life' in log and 'applied by hand' in log, log[:200])
    # Stack / log / card id / chat popups open
    for act, sel in (('log', '.glog__list--full'), ('stack', 'text=The stack is empty'), ('card-id', '[data-q]'), ('help', '#judgeSearch'), ('profile', 'text=Commander damage taken')):
        await page.click(f'[data-act="{act}"]'); await page.wait_for_selector(sel); await page.click('.modal [data-modal-back]')
    await page.click('[data-act="card-id"]'); await page.fill('[data-q]', 'Sol Ring'); await page.click('[data-go]'); await page.wait_for_selector('.card-detail')
    await page.screenshot(path=f'{OUT}phone-card-id.png'); await page.click('.modal .btn--cancel')
    # Concede → game over → profile records it
    await page.click('[data-act="settings"]'); await page.click('[data-do="concede"]'); await page.click('.modal .btn--danger')
    await page.wait_for_selector('text=Game complete')
    await page.screenshot(path=f'{OUT}phone-postgame.png')
    check('winner announced', 'Aaron' in await page.locator('.postgame__winner').text_content())
    await page.click('.modal .btn--confirm')
    await page.wait_for_selector('.landing')
    games = await page.evaluate("import('./src/data/profile.js').then(m => m.loadProfile().games)")
    check('game recorded in profile', games == 1, str(games))
    check('continue is disabled after a finished game', await page.locator('[data-act="continue"]').is_disabled())
    check('no console errors (guided)', not page.errors, str(page.errors[:3]))
    await page.context.close()

async def freeplay(browser):
    page = await new_page(browser, PHONE)
    await start_guided(page, ('white', 'red', 'rakdos'), mode='freeplay')
    await page.screenshot(path=f'{OUT}phone-setup3.png')
    await continue_to_game(page)
    for _ in range(3):
        await page.wait_for_selector('text=opening hand'); await page.click('#keepHand'); await page.wait_for_selector('.curtain'); await tap_curtain(page)
    await page.wait_for_selector('.zone--hand .card')
    check('free play label and Edit Game button', await page.locator('text=FREE PLAY').count() == 1 and 'Edit' in await page.locator('[data-act="tools"]').text_content())
    check('three players: two opponent seats (centre + one side)', await page.locator('.seat--centre').count() == 1 and await page.locator('.seat--side').count() == 1)
    centre = await page.locator('.seat--centre').get_attribute('data-id')
    side = await page.locator('.seat--side').get_attribute('data-id')
    await page.click('.seat--side [data-act="seat"]'); await page.wait_for_timeout(200)
    check('tapping a side seat centres it and the old centre moves to the side', await page.locator('.seat--centre').get_attribute('data-id') == side and await page.locator('.seat--side').get_attribute('data-id') == centre)
    check('seat buttons rebound to the new players', await page.locator('.seat--centre [data-act="opponent"]').get_attribute('data-id') == side and await page.locator('.seat--side [data-act="seat"]').get_attribute('data-id') == centre)
    check('no dialog opened by the rotation; own board and hand stay', await page.locator('.modal').count() == 0 and await page.locator('.zone--hand .card').count() > 0 and await page.locator('.zone--battle').count() == 1)
    check('opponents show hand counts only', await page.locator('.seat--centre .card[data-zone="hand"]').count() == 0)
    await page.click('.seat--side .life-light'); await page.wait_for_selector('text=Commander damage taken')
    check('side seat status light opens details without rotating', await page.locator('.seat--centre').get_attribute('data-id') == side)
    await page.click('.modal [data-modal-back]')
    await page.evaluate(SETUP, [[0, 'Serra Angel', 'hand']])
    await page.wait_for_timeout(200)
    await card(page, 'hand', 'Serra Angel')
    check('free play offers Play anyway', 'Play anyway' in await page.locator('.modal__foot').text_content())
    await page.click('.modal .btn--danger'); await page.wait_for_timeout(300); await pass_all(page)
    check('forced card reached the battlefield', await page.locator('.zone--battle .card[aria-label="Serra Angel"]').count() == 1)
    await card(page, 'battle', 'Serra Angel')
    await page.click('[data-edit="counter"][data-delta="1"]'); await page.wait_for_selector('.card-detail')
    check('counter edit shows on the card', '1 +1/+1 counter' in await page.locator('.card-detail__status').text_content())
    await page.click('.modal .btn--cancel')
    await page.click('[data-act="tools"]'); await page.click('[data-tool="token"]'); await page.locator('[data-choice]').first.click(); await page.click('[data-token="1"]'); await page.click('.modal .btn--confirm')
    await page.wait_for_timeout(300)
    check('token created', await page.locator('.zone--battle .card.is-token').count() == 1)
    await page.click('[data-act="undo"]'); await page.click('.modal .btn--confirm'); await page.wait_for_timeout(300)
    check('undo removed the token', await page.locator('.zone--battle .card.is-token').count() == 0)
    await page.screenshot(path=f'{OUT}phone-freeplay.png')
    check('no console errors (free play)', not page.errors, str(page.errors[:3]))
    await page.context.close()

async def deck_builder(browser):
    """The Deck Builder (deck/) owns the decks: old editor decks move into it once, player setup lists its decks,
    and Deck Builder ↔ game side keep the calling screen and the seats."""
    page = await new_page(browser, PHONE)
    white = FIX['decks']['white']
    await page.evaluate("""(w) => {
      localStorage.setItem('ccv07-decks', JSON.stringify([{ id: 'old1', name: 'Mono White', commander1: w.commander, commander2: '', deckList: w.list }]));
      localStorage.removeItem('dc.profile'); localStorage.removeItem('cc.deckProfile'); localStorage.removeItem('cc.decksMoved');
    }""", white)
    await page.reload(); await page.wait_for_function('window.__ccReady === true', timeout=15000)
    moved = await page.evaluate("JSON.parse(localStorage.getItem('cc.deckProfile') || 'null')")
    check('old editor deck moved into the Deck Builder', bool(moved) and any(d['id'] == 'cc-old1' and d['commander'] == white['commander'] for d in moved['decks']), str(moved)[:200])
    await page.reload(); await page.wait_for_function('window.__ccReady === true', timeout=15000)
    count = await page.evaluate("JSON.parse(localStorage.getItem('cc.deckProfile')).decks.filter(d => d.id === 'cc-old1').length")
    check('a deck moves only once', count == 1, str(count))
    await page.click('[data-act="start"]'); await page.click('[data-mode="fully-tracked"]'); await page.click('[data-play="local"]')
    await page.click('[data-seat-act="saved"]'); await page.locator('.modal [data-deck]').first.click()
    check('saved deck fills the commander', await page.input_value('[data-field="commander1"]') == white['commander'])
    deck_ids = await page.evaluate("import('./src/data/deck-store.js').then(m => m.listDecks().map(d => d.id))")
    check('a moved deck keeps its old id on the game side', 'old1' in deck_ids, str(deck_ids))
    check('no console errors (decks)', not page.errors, str(page.errors[:3]))
    await page.click('[data-act="deck-builder"]')
    await page.wait_for_url('**/deck/'); await page.wait_for_selector('.top [data-act="cc-home"]')
    check('Deck Builder opens with the Commander Companion header', 'DECK BUILDER' in (await page.locator('.brand').text_content()).upper())
    await page.click('[data-act="cc-home"]')
    await page.wait_for_function('window.__ccReady === true', timeout=15000)
    check('Home returns to player setup', await page.evaluate("document.getElementById('app').dataset.screen") == 'player-setup')
    check('the seat keeps its deck after the round trip', await page.input_value('[data-field="commander1"]') == white['commander'])
    await page.context.close()

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        which = sys.argv[1] if len(sys.argv) > 1 else 'all'
        if which in ('all', 'guided'): await guided(browser)
        if which in ('all', 'freeplay'): await freeplay(browser)
        if which in ('all', 'decks'): await deck_builder(browser)
        await browser.close()
    print(f'{sum(results)}/{len(results)} passed')
    sys.exit(0 if all(results) else 1)

asyncio.run(main())

# Commander Companion V3 · Corrected Deck Builder masters

The reference is the Deck Builder embedded in Commander Companion. It reports **0.9.71, build 216**. Source files were pulled from [Commander Companion commit c7d5d08](https://github.com/MaxFHurt/CommanderCompanion/tree/c7d5d0809ff806a3d102230ce9cc39bae258ef7d/rebuild/deck).

## Review the masters

Open `preview/index.html` in a desktop browser to switch among screens, iPhone landscape (844 × 390), and iPad landscape (1180 × 760). **Appearance** switches between the current skin and V3 amethyst. The embedded app uses the current Deck Builder’s renderers, starting with its example deck or a deck created in the local preview session. The iPhone view scrolls as a page. The iPad view uses the Build column alongside the active deck tab. Select the iPhone layout and **Build settings** to review the phone’s dedicated Build tab.

For local worker and fetch support, serve the extracted preview directory over HTTP. From the extracted folder, run `python3 -m http.server 8765 --directory preview`, then open `http://localhost:8765/`. Network-dependent card art, database updates, printings, prices, and external services use the app’s usual endpoints. Commander Companion game and online-profile integration are available in the production host.

## Install the skin

Copy `skin/cc-v3-deck.css` and the entire `skin/v3-deck-art/` directory into `rebuild/deck/`. Add the following immediately after the existing `cc-theme.css` link in `rebuild/deck/index.html`.

```html
<link rel="stylesheet" href="cc-v3-deck.css">
```

The skin uses the existing Commander Companion backdrop, header crest and home artwork. Transparent SVGs provide the cut-steel frames and steel and amethyst controls. The CSS uses existing classes and semantics across the app, including sheets, dialogs and generated rows. Controls, card artwork, copy, responsive breakpoints, touch targets, scroll containers, app data and navigation come from the application.

## Coverage

| Current surface | Review in the preview |
| --- | --- |
| Build a new deck | Generate from a commander, Decks you can build, Generate from cards, Load a precon, Import a text list, Empty Commander deck, Empty Standard deck. Open each entry to see its live setup. |
| Saved decks | New deck, open saved deck, name and card preview, player/folder/tag filters when applicable. |
| Open deck | All decks, Duplicate, Share link, Compare, History, Delete deck. Drafts surface Save deck and Discard. Undo appears after an eligible edit. |
| Build settings | Commander and available partner choices, format/color selection, priorities and mechanics, theme and budget controls, regenerate upgrades. Settings adapt to deck format. |
| Decklist | Count, grouped card rows, sort and role filters, card detail and printings, export, buy-list actions and applicable deck metadata. |
| Build stats and Upgrades | Deck Power and Apex Progress, deck health and details, recommendations and filters, Current/Budget/Mid/Apex, regenerate, swap, dismiss and buy actions as available. |
| Deck and global Buy List and Library | Deck-scoped tabs, overall navigation, item and import controls that depend on collection and buy-list contents. |
| Card Search and Profile | Existing search filters and print views, card inspection, profile and backup actions. |

The previous visual handoff's open-deck treatment omitted Compare, History, Share link and Regenerate from its visual coverage. Review the real workspace buttons and their sheets through the preview before installing.

## Verification

The preview uses the byte-identical build 216 app and worker bundles. The source's renderers were exercised for the seven new-deck choices, top-level destinations, and the saved-deck views at both reference viewport sizes. Compare, History, Share link, Regenerate, Import, Commander generation, card-based generation, and precon dialogs were also rendered in the source smoke check. The deployed Builder was checked directly for its seven entry points. Physical iPhone/iPad rendering, live account integration, and the new skin’s visual appearance in the review browser still need device verification.

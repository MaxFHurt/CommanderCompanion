// Preview harness. The integration stylesheet requires no JavaScript.
const reviewParams = new URLSearchParams(location.search);
if (reviewParams.get('skin') === 'current') {
  document.querySelector('link[href="cc-v3-deck.css"]').disabled = true;
}
const reviewMaster = reviewParams.get('master');
const reviewRoutes = {
  builder: 'deck', home: 'home', decks: 'decks', search: 'search',
  buy: 'buy', library: 'library', profile: 'profile'
};
const reviewTabs = {
  list: 'list', build: 'build', stats: 'stats', up: 'up',
  'deck-buy': 'buy', 'deck-library': 'lib'
};
window.addEventListener('load', () => {
  // Exit the isolated Deck Builder preview to the real game host.
  CC.url = 'https://maxfhurt.github.io/CommanderCompanion/rebuild/';
  if (Object.hasOwn(reviewRoutes, reviewMaster)) {
    S.view = reviewRoutes[reviewMaster];
    S.open = false;
  } else if (Object.hasOwn(reviewTabs, reviewMaster)) {
    const deck = S.profile.decks.find(item => item.example) || S.profile.decks[0];
    if (!deck) return;
    S.view = 'decks';
    S.deckId = deck.id;
    S.open = true;
    S.tab = reviewTabs[reviewMaster];
  } else {
    return;
  }
  render();
});
